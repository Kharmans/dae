import { applyActiveEffects, socketlibSocket } from "./GMAction.js";
import { warn, error, debug, setDebugLevel, i18n, debugEnabled } from "../dae.js";
import { ActiveEffects } from "./apps/ActiveEffects.js";
import { macroActorUpdate } from "./daeMacros.js";
import { ValidSpec } from "./Systems/DAESystem.js";
import { DAESystemDND5E } from "./Systems/DAEdnd5e.js";
import { DIMEditor } from "./apps/DIMEditor.js";
import { isEnchantment } from "./apps/DAEActiveEffectConfig.js";
import { setupSpecialDurationHooks, fetchDurationParams } from "./specialDurations.js";
const { SchemaField } = foundry.data.fields;
let templates = {};
export let aboutTimeInstalled = false;
export let timesUpActive = false;
export let simpleCalendarInstalled = false;
export let atlActive = false;
export let midiActive = false;
export let useDetermineSuppression = false;
export let ceInterface;
export let localizationMap = {};
// export let useAbilitySave;
export let noDupDamageMacro;
export let disableEffects;
export let daeTitleBar;
export let DIMETitleBar;
export let daeColorTitleBar;
export let daeNoTitleText;
export let libWrapper;
export let actionQueue;
// export let linkedTokens;
// export let DAESetupComplete;
export let DAEReadyComplete;
export let dependentConditions;
export let specialDurationExpiryAction = "default";
/**
 * Resolve the effective expiry action for special durations.
 * "default" falls through to core's CONFIG.ActiveEffect.expiryAction.
 */
export function resolveSpecialDurationExpiryAction() {
    if (specialDurationExpiryAction === "delete" || specialDurationExpiryAction === "update") {
        return specialDurationExpiryAction;
    }
    // "default" (or legacy "none") — use core's setting
    // @ts-expect-error v14 CONFIG.ActiveEffect.expiryAction
    return CONFIG.ActiveEffect.expiryAction ?? "update";
}
/**
 * Resolve the expiry action for a specific effect, checking per-effect flag first.
 * Per-effect flags.dae.expiryMode overrides the global setting.
 */
export function resolveEffectExpiryAction(effect) {
    const mode = effect.getFlag("dae", "expiryMode");
    if (mode === "delete")
        return "delete";
    if (mode === "suppress")
        return "update";
    // "default" or unset — use global setting
    return resolveSpecialDurationExpiryAction() === "delete" ? "delete" : "update";
}
// Track actors with pending status reconciliation to avoid duplicate reconciliations
const reconciliationPending = new Set();
// Track actor UUIDs that have had init macros fired (reset on world load)
export const daeInitMacroActors = new Set();
// Effects pending init macro calls (queued before game.ready, processed in daeReadyActions)
export const pendingInitMacroEffects = [];
/** Return CONFIG.statusEffects as an array, handling systems (e.g. Crucible) that replace it with a plain object. */
export function getStatusEffectsArray() {
    return Array.isArray(CONFIG.statusEffects) ? CONFIG.statusEffects : Object.values(CONFIG.statusEffects);
}
export let allMacroEffects = ["macro.execute", "macro.execute.local", "macro.execute.GM", "macro.itemMacro", "macro.itemMacro.local", "macro.itemMacro.GM", "macro.actorUpdate", "macro.activityMacro"];
export let macroDestination = {
    "macro.execute": "mixed",
    "macro.execute.local": "local",
    "macro.execute.GM": "GM",
    "macro.itemMacro": "mixed",
    "macro.itemMacro.local": "local",
    "macro.itemMacro.GM": "GM",
    "macro.actorUpdate": "mixed",
    "macro.activityMacro": "mixed"
};
export let daeSystemClass;
if (!globalThis.daeSystems)
    globalThis.daeSystems = {};
// export let showDeprecation = true;
export let showInline = false;
const deprecatedKeyPatterns = [
    { pattern: /^data\.abilities\.(\w{3})\.save$/, replacement: id => `system.abilities.${id}.bonuses.save` },
    { pattern: /^data\.abilities\.(\w{3})\.mod$/, replacement: id => `system.abilities.${id}.bonuses.check` },
    { pattern: /^data\.skills\.(\w{3})\.mod$/, replacement: id => `system.skills.${id}.bonuses.check` },
    { pattern: /^data\.skills\.(\w{3})\.passive$/, replacement: id => `system.skills.${id}.bonuses.passive` },
];
function flagChangeKeys(actor, change) {
    if (!(["dnd5e"].includes(game.system.id ?? "")))
        return;
    for (const { pattern, replacement } of deprecatedKeyPatterns) {
        const match = change.key.match(pattern);
        if (match) {
            console.error(`dae | deprecated change key ${change.key} found in ${actor.name} use ${replacement(match[1])} instead`);
            return;
        }
    }
}
/*
 * v14 phase-based OVERRIDE for Actor.applyActiveEffects(phase)
 * Replaces both the old applyBaseActiveEffects and applyDaeEffects.
 * Handles: field mappings, dae.eval(), stacks, CI priority, expandEffectChanges,
 * ATL exclusion, flagChangeKeys, and delegates to v14's ActiveEffect.applyChange().
 */
export function daeApplyActiveEffects(phase) {
    if (disableEffects)
        return;
    const ActiveEffectDoc = CONFIG.ActiveEffect.documentClass;
    // Validate the phase
    if (typeof phase !== "string") {
        // @ts-expect-error v14 _completedActiveEffectPhases
        phase = this._completedActiveEffectPhases?.has("initial") ? "final" : "initial";
        foundry.utils.logCompatibilityWarning('Actor#applyActiveEffects must be called with a string phase identifier.', { since: 14, until: 16, once: true });
    }
    // @ts-expect-error v14 _completedActiveEffectPhases
    if (this._completedActiveEffectPhases?.has(phase)) {
        console.error(`dae | ActiveEffect application phase "${phase}" has already completed for ${this.name}`);
        return;
    }
    // @ts-expect-error v14 _completedActiveEffectPhases
    this._completedActiveEffectPhases?.add(phase);
    // Call dnd5e's prepareEmbeddedData directly — this is the only useful work that
    // dnd5e's applyActiveEffects() did before delegating to core.
    // @ts-expect-error no dnd5e-types
    if (this.system?.prepareEmbeddedData instanceof Function)
        this.system.prepareEmbeddedData();
    const overrides = {};
    debug("daeApplyActiveEffects: phase", phase, this.name);
    for (let effect of this.allApplicableEffects()) {
        // @ts-expect-error no dnd5e-types
        if (useDetermineSuppression)
            effect.determineSuppression();
        // Migrate deprecated flags.dae.showIcon to native showIcon field
        if (effect.flags?.dae?.showIcon) {
            foundry.utils.logCompatibilityWarning(`dae | Effect "${effect.name}" on actor "${this.name}" uses deprecated flags.dae.showIcon. Edit the effect to migrate to the native showIcon field.`, { once: true, stack: false });
        }
    }
    const effects = this.appliedEffects.filter(ef => !ef.disabled && !ef.isSuppressed);
    if (!effects || effects.length === 0)
        return this.overrides ?? {};
    const changes = effects.reduce((changes, effect) => {
        // Status effects: handled in "initial" phase
        if (phase === "initial") {
            for (const statusId of effect.statuses) {
                this.statuses.add(statusId);
            }
        }
        // @ts-expect-error v14 effect.system.changes
        return changes.concat(expandEffectChanges(foundry.utils.duplicate(effect.system.changes))
            .filter(c => {
            if (!c.key)
                return false;
            // Correct the phase from the ValidSpec lookup — the schema defaults to "initial"
            // but specials/derived fields (e.g. system.attributes.ac.value) need "final".
            const spec = ValidSpec.actorSpecs?.["union"]?.allSpecsObj?.[c.key];
            if (spec)
                c.phase = spec.phase;
            // Phase filtering — the sole timing filter in v14
            if (c.phase !== phase)
                return false;
            // ATL keys still excluded from DAE processing
            if (c.key.startsWith("ATL."))
                return false;
            // Field mappings (deprecated key migration)
            if (daeSystemClass.fieldMappings[c.key]) {
                const mapping = daeSystemClass.fieldMappings[c.key];
                const displayMapping = typeof mapping === "string" ? mapping : `${mapping.key}${mapping.value !== undefined ? ` ${mapping.value}` : ""}`;
                foundry.utils.logCompatibilityWarning(`dae | Actor ${this.name} ${c.key} deprecated use ${displayMapping} instead.`, { once: true, stack: false });
                if (typeof mapping !== "string") {
                    c.key = mapping.key;
                    if (mapping.value !== undefined)
                        c.value = mapping.value;
                    if (mapping.type !== undefined)
                        c.type = mapping.type;
                    else if (mapping.mode !== undefined) {
                        // Legacy field mapping with numeric mode -- convert to v14 string type
                        const modeToType = { 0: "custom", 1: "multiply", 2: "add", 3: "downgrade", 4: "upgrade", 5: "override" };
                        c.type = modeToType[mapping.mode] ?? "custom";
                    }
                }
                else if (mapping.startsWith("system.traits.da") && mapping.endsWith(".value")) {
                    const damageType = c.key.split(".").slice(-1)[0];
                    c.key = mapping;
                    c.value = damageType;
                    if (c.type === "custom")
                        c.type = "add";
                }
                else {
                    if (c.key.includes("DR") && c.value?.length > 0)
                        c.value = `-(${c.value})`;
                    if (debugEnabled > 0)
                        warn("Doing field mapping mapping ", c.key, mapping);
                    c.key = mapping;
                }
            }
            return true;
        })
            .map(c => {
            c = foundry.utils.duplicate(c);
            c.count = effect.flags?.dae?.stacks || 1;
            flagChangeKeys(this, c);
            if (c.key.startsWith("flags.midi-qol.optional")) { // patch for optional effects
                const parts = c.key.split(".");
                // Only apply deprecation fix for bare category keys like flags.midi-qol.optional.NAME.save (5 parts)
                // Don't match deeper keys like flags.midi-qol.optional.NAME.damage.save where save is an action type
                if (parts.length === 5 && ["save", "check", "skill", "damage", "attack"].includes(parts[4])) {
                    console.error(`dae/midi-qol | deprecation error ${c.key} should be ${c.key}.all on actor ${this.name}`);
                    c.key = `${c.key}.all`;
                }
            }
            if (c.key === "flags.midi-qol.OverTime")
                c.key = `flags.midi-qol.OverTime.${foundry.utils.randomID()}`;
            c.effect = effect;
            if (["system.traits.ci.value", "system.traits.ci.all", "system.traits.ci.custom"].includes(c.key))
                c.priority = 0;
            else {
                // v14: use string type for priority defaults
                // @ts-expect-error v14 CHANGE_TYPES
                const typeDefaults = ActiveEffectDoc.CHANGE_TYPES ?? {};
                c.priority = c.priority ?? typeDefaults[c.type]?.defaultPriority ?? (c.mode !== undefined ? c.mode * 10 : 0);
            }
            return c;
        }));
    }, []);
    // Organize non-disabled effects by their application priority
    changes.sort((a, b) => (a.priority ?? 50) - (b.priority ?? 50));
    // Separate token.* changes for TokenDocument.applyActiveEffects() to consume
    const tokenChanges = [];
    const actorChanges = changes.filter(c => {
        if (c.key?.startsWith("token.")) {
            c.key = c.key.slice(6);
            tokenChanges.push(c);
            return false;
        }
        return true;
    });
    // @ts-expect-error v14 tokenActiveEffectChanges
    this.tokenActiveEffectChanges[phase] = tokenChanges;
    if (actorChanges.length > 0 && debugEnabled > 0)
        warn("Applying effect phase", phase, this.name, actorChanges);
    // Apply all changes using v14's field-aware application
    const replacementData = this.getRollData();
    for (let c of actorChanges) {
        if (!c.key || !c.count)
            continue;
        for (let i = 0; i < c.count; i++) {
            // @data. deprecation
            if (typeof c.value === "string" && c.value.includes("@data.")) {
                const parentInfo = c.effect?.parent ? ` on ${c.effect.parent.name} (${c.effect.parent.id})` : '';
                console.warn(`dae | @data.key is deprecated, use @key instead (${c.effect?.name} (${c.effect?.id})${parentInfo} has value ${c.value})`);
                c.value = c.value.replace(/@data./g, "@");
            }
            // dae.eval() and dae.roll() expression handling
            const stackCount = c.effect?.flags?.dae?.stacks ?? 1;
            if (typeof c.value === "string" && (c.value.includes("dae.eval(") || c.value.includes("dae.roll("))) {
                const conditionData = this.getRollData();
                foundry.utils.mergeObject(conditionData, { stackCount, effect: c.effect?.toObject() });
                c.value = daeSystemClass.safeEvalExpression(c.value, conditionData);
            }
            // @stackCount substitution (for non-numeric fields — numeric fields handle via replacementData)
            if (typeof c.value === "string") {
                c.value = c.value.replace("@stackCount", String(stackCount));
            }
            replacementData.stackCount = stackCount;
            // Delegate to v14's ActiveEffect.applyChange which handles:
            // - field resolution via getFieldForProperty
            // - type-aware casting (NumberField evaluates Roll expressions)
            // - @ref replacement via replacementData
            // - custom type dispatch via applyActiveEffect hook
            // @ts-expect-error v14 static applyChange
            const result = c.effect?.constructor.applyChange(this, c, { replacementData });
            if (result && typeof result === "object")
                Object.assign(overrides, result);
        }
    }
    // Expand the set of final overrides + merge
    this.overrides = foundry.utils.mergeObject(this.overrides || {}, foundry.utils.expandObject(overrides) || {}, { inplace: true, overwrite: true });
}
// Keep the old name as an alias for backward compatibility with any external callers
export const applyDaeEffects = daeApplyActiveEffects;
function expandEffectChanges(changes) {
    let returnChanges = changes.reduce((list, change) => {
        if (!daeSystemClass.bonusSelectors[change.key]) {
            list.push(change);
        }
        else {
            if (daeSystemClass.bonusSelectors[change.key].replaceList) {
                daeSystemClass.bonusSelectors[change.key].replaceList?.forEach(replace => {
                    const c = foundry.utils.duplicate(change);
                    c.key = replace;
                    list.push(c);
                });
            }
            else {
                const attacks = daeSystemClass.bonusSelectors[change.key].attacks;
                const selector = daeSystemClass.bonusSelectors[change.key].selector;
                attacks.forEach(at => {
                    const c = foundry.utils.duplicate(change);
                    c.key = `system.bonuses.${at}.${selector}`;
                    list.push(c);
                });
            }
        }
        return list;
    }, []);
    return returnChanges;
}
export async function addCreateItemChange(change, actor, effect, context) {
    let itemDetails = change.value;
    if (itemDetails.startsWith("@")) {
        itemDetails = Roll.replaceFormulaData(change.value, actor.getRollData(), { missing: "", warn: false });
    }
    await actionQueue.add(socketlibSocket.executeAsGM.bind(socketlibSocket), "createActorItem", { uuid: actor.uuid, itemDetails, effectUuid: effect.uuid, callItemMacro: change.key === "macro.createItemRunMacro" });
}
export async function removeCreateItemChange(itemId, actor, effect, context = {}) {
    if (itemId.startsWith("@")) {
        itemId = Roll.replaceFormulaData(itemId, actor.getRollData(), { missing: "", warn: false });
    }
    let [uuid, option] = itemId.split(",").map(s => s.trim());
    if (option === "permanent")
        return; // don't delete permanent items
    if ((effect.flags?.dae?.itemsToDelete ?? []).length === 0)
        return;
    if (!(context.effectDeleted || context.itemDeleted))
        await effect.setFlag("dae", "itemsToDelete", []);
    await actionQueue.add(socketlibSocket.executeAsGM.bind(socketlibSocket), "removeActorItem", { uuid: actor.uuid, itemUuid: itemId, itemUuids: effect.flags?.dae?.itemsToDelete, context });
}
export async function addTokenMagicChange(actor, change, tokens) {
    const tokenMagic = globalThis.TokenMagic;
    if (!tokenMagic)
        return;
    for (let token of tokens) {
        if (token instanceof foundry.canvas.placeables.Token)
            token = token.document;
        const tokenUuid = token?.uuid;
        // Put this back if TMFX does awaited calls
        // await actionQueue.add(tokenMagic.addFilters, token, change.value); - see if gm execute solve problem
        await actionQueue.add(socketlibSocket.executeAsGM.bind(socketlibSocket), "applyTokenMagic", { tokenUuid, effectId: change.value });
    }
}
export async function removeTokenMagicChange(actor, change, tokens, context = {}) {
    const tokenMagic = globalThis.TokenMagic;
    if (!tokenMagic)
        return;
    for (let token of tokens) {
        if (token instanceof foundry.canvas.placeables.Token)
            token = token.document;
        // put this back if TMFX does awaited calls
        // await actionQueue.add(tokenMagic.deleteFilters, token, change.value);
        const tokenUuid = token?.uuid;
        await actionQueue.add(socketlibSocket.executeAsGM.bind(socketlibSocket), "removeTokenMagic", { tokenUuid, effectId: change.value });
    }
}
async function myRemoveCEEffect(effectName, uuid, origin, isToken) {
    let interval = 1;
    await delay(interval); // let all of the stuff settle down
    return await ceInterface?.removeEffect({ effectName, uuid, origin });
}
export async function removeConvenientEffectsChange(effectName, uuid, origin, isToken) {
    if (isToken)
        await delay(1); // let all of the stuff settle down
    const returnValue = await actionQueue.add(myRemoveCEEffect, effectName, uuid, origin, isToken);
    return returnValue;
}
async function myAddCEEffectWith(effectData, uuid, origin, overlay, isToken) {
    if (!ceInterface)
        return;
    let interval = 1;
    if (interval)
        await delay(interval);
    return await ceInterface.addEffect({ effectName: effectData.name, uuid, origin, effectData, overlay });
}
export async function addConvenientEffectsChange(effectName, uuid, origin, context, isToken) {
    if (!ceInterface)
        return;
    let ceEffect;
    ceEffect = ceInterface.findEffect({ effectName });
    if (!ceEffect)
        return;
    let effectData = foundry.utils.mergeObject(ceEffect.toObject(), context.metaData);
    effectData.origin = origin;
    return await actionQueue.add(myAddCEEffectWith, effectData, uuid, origin, false, isToken);
}
export async function addConditionChange(actor, change, token, effect) {
    // This is from macro.statusEffect
    const condition = getStatusEffectsArray().find(se => se.id === change.value);
    if (!condition)
        return;
    const overlay = foundry.utils.getProperty(effect, "flags.core.overlay");
    if (change.value.startsWith("Convenient Effect")) {
        console.warn("Convenient Effect change detected in macro.StatusEffect which is deprecated use macro.CE instead");
        console.warn(`Actor: ${actor.name} Change: ${change.value} Token: ${token?.name} Effect: ${effect.name} ${effect.uuid}`);
        const effectName = change.value.split("Convenient Effect: ")[1];
        return await ceInterface?.addEffect({ effectName, uuid: actor.uuid, origin: effect.uuid, overlay });
    }
    else if (change.value.startsWith("zce-")) {
        console.warn("Convenient Effect change detected in macro.StatusEffect which is deprecated use macro.CE instead");
        console.warn(`Actor: ${actor.name} Change: ${change.value} Token: ${token?.name} Effect: ${effect.name} ${effect.uuid}`);
        const effectId = change.value.replace("zce-", "ce-");
        return await ceInterface?.addEffect({ effectId, uuid: actor.uuid, origin: effect.uuid, overlay });
    }
    if (condition.statuses?.length > 1 && !condition?._id) {
        condition._id = condition.id.replaceAll(/[ :,.\+\-\*\&\^\%\$\#\@\!\[\]{}\(\)]/g, "").padEnd(16, "0").slice(-16);
    }
    const effects = await toggleActorStatusEffect(actor, condition.id, { active: true, origin: effect.uuid, flags: { dnd5e: { dependentOn: effect.uuid } } });
    if (game.system.id !== "dnd5e" || foundry.utils.isNewerVersion("5.1.99", game.system.version)) {
        // @ts-expect-error no dnd5e-types
        if (effect.addDependent && effects instanceof Array)
            effect.addDependent(...effects);
    }
}
export async function removeConditionChange(actor, change, token, effect, context = {}) {
    if (change.value.startsWith("Convenient Effect")) {
        const effectName = change.value.split("Convenient Effect: ")[1];
        return await ceInterface?.removeEffect({ effectName, uuid: actor.uuid, origin: effect.uuid });
    }
    else if (change.value.startsWith("zce-") && ceInterface) {
        const effectId = change.value.replace("zce-", "ce-");
        return await ceInterface?.removeEffect({ effectId, uuid: actor.uuid, origin: effect.uuid });
    }
    const condition = actor.effects.find(ef => ef.origin === effect.uuid && ef.statuses.has(change.value));
    // Effect will auto remove
    // if (condition) await (actionQueue.add(actor.deleteEmbeddedDocuments.bind(actor), "ActiveEffect", [condition.id]));
}
export async function addStatusEffectChange(actor, change, tokens, sourceEffect, context = {}) {
    if (change.key !== "StatusEffect")
        return false;
    if (change.value.startsWith("zce-")) {
        const effectId = change.value.replace("zce-", "ce-");
        const effect = ceInterface?.findEffect && ceInterface.findEffect({ effectId });
        if (effect) {
            return await ceInterface.addEffect({ effectId, uuid: actor.uuid, origin: sourceEffect.uuid, overlay: false });
        }
    }
    else {
        let statusEffect = getStatusEffectsArray().find(se => se.id === change.value);
        if (statusEffect) {
            return toggleActorStatusEffect(actor, statusEffect.id, { active: true, origin: sourceEffect.uuid });
        }
    }
    return false;
}
export async function removeStatusEffectChange(actor, change, tokens, effect, context = {}) {
    // TODO this might remove too many effects
    const effectsToRemove = actor.effects.filter(ef => ef.origin === effect.uuid)?.map(ef => ef.id);
    if (effectsToRemove && effectsToRemove.length > 0)
        await actionQueue.add(actor.deleteEmbeddedDocuments.bind(actor), "ActiveEffect", effectsToRemove, context);
}
export async function expireEffects(actor, effects, context) {
    if (!effects)
        return {};
    const actorEffectsToExpire = [];
    const effectsToDelete = [];
    const effectsToDisable = [];
    for (let effect of effects) {
        if (!effect.id)
            continue;
        if (!fromUuidSync(effect.uuid))
            continue;
        if (effect.transfer)
            effectsToDisable.push(effect);
        else if (effect.parent instanceof Actor)
            actorEffectsToExpire.push(effect.id);
        else if (effect.parent instanceof Item) // this should be enchantments
            effectsToDelete.push(effect);
    }
    if (actorEffectsToExpire.length > 0) {
        const toDelete = [];
        const toSuppress = [];
        for (const id of actorEffectsToExpire) {
            const ef = actor.effects.get(id);
            if (!ef)
                continue;
            if (resolveEffectExpiryAction(ef) === "delete")
                toDelete.push(id);
            else
                toSuppress.push(id);
        }
        if (toDelete.length > 0) {
            await actor.deleteEmbeddedDocuments("ActiveEffect", toDelete, context);
        }
        if (toSuppress.length > 0) {
            const updates = toSuppress.map(id => ({ _id: id, "duration.expired": true }));
            await actor.updateEmbeddedDocuments("ActiveEffect", updates, context);
        }
    }
    if (effectsToDisable.length > 0) {
        for (let effect of effectsToDisable) {
            await effect.update({ "disabled": true });
        }
    }
    if (effectsToDelete.length > 0) {
        for (let effect of effectsToDelete)
            await effect.delete();
    }
    return { expired: actorEffectsToExpire, disabled: effectsToDisable, itemEffects: effectsToDelete };
}
function createActiveEffectHook(effect, options, userId) {
    if (userId !== game.user?.id)
        return true;
    // @ts-expect-error Can this happen?
    if (options.isUndo)
        return true;
    if (!effect.parent || (CONFIG.ActiveEffect.legacyTransferral === true && !(effect.parent instanceof CONFIG.Actor.documentClass)))
        return true;
    let actor = effect.parent;
    if (actor instanceof CONFIG.Item.documentClass) {
        if (!effect.transfer)
            return true; // non-transfer effects on items should not be applied to the actor
        actor = effect.parent.parent;
    }
    if (!actor) {
        // not an effect on an actor so do nothing
        return true;
    }
    const tokens = actor.isToken ? [actor.token?.object] : actor.getActiveTokens();
    if (!(tokens[0] instanceof foundry.canvas.placeables.Token))
        return;
    const token = tokens[0];
    // @ts-expect-error no dnd5e-types
    if (useDetermineSuppression)
        effect.determineSuppression();
    // @ts-expect-error v14 effect.system.changes
    if (effect.system?.changes?.length && effect.active) {
        let changeLoop = async () => {
            try {
                const selfAuraChange = foundry.utils.getProperty(effect, "flags.ActiveAuras.isAura") === true
                    && foundry.utils.getProperty(effect, "flags.ActiveAuras.ignoreSelf") === true
                    && effect.origin?.startsWith(actor.uuid);
                // don't apply macro or macro like effects if active aura and not targeting self
                if (selfAuraChange)
                    return;
                // @ts-expect-error v14 effect.system.changes
                for (let change of effect.system.changes) {
                    if (ceInterface && change.key === "macro.CE") {
                        await addConvenientEffectsChange(change.value, actor.uuid, effect.origin, options, actor.isToken);
                    }
                    if (["macro.createItem", "macro.createItemRunMacro"].includes(change.key)) {
                        await addCreateItemChange(change, actor, effect, options);
                    }
                    if (change.key === "macro.StatusEffect" || change.key === "StatusEffect") {
                        await addConditionChange(actor, change, token, effect);
                    }
                    const tokenMagic = globalThis.TokenMagic;
                    if (tokenMagic && change.key === "macro.tokenMagic" && token)
                        await addTokenMagicChange(actor, change, tokens); //TODO check disabled
                }
                // @ts-expect-error v14 effect.system.changes
                if (effect.system.changes.some(change => change.key.startsWith("macro.execute") || change.key.startsWith("macro.itemMacro") || change.key.startsWith("macro.actorUpdate") || change.key.startsWith("macro.activityMacro"))) {
                    await actionQueue.add(daeMacro, "on", actor, effect.toObject(false), { effectUuid: effect.uuid }); // TODO revisit to see if passing the effect is ok
                }
            }
            catch (err) {
                const message = "dae | createActiveEffectHook | create effect error";
                if (globalThis.MidiQOL?.apps?.TroubleShooter) {
                    globalThis.MidiQOL.apps.TroubleShooter.recordError(err, message);
                }
                console.warn(message, err);
            }
            finally {
                return true;
            }
        };
        changeLoop();
    }
    return true;
}
async function _preCreateActiveEffectRemoveExisting(effectData, options, user) {
    if (debugEnabled > 0)
        warn("preCreateActiveEffectRemoveExisting", effectData, options, user);
    let result = true;
    try {
        // @ts-expect-error Can this happen?
        if (options.isUndo)
            return;
        const parent = this.parent;
        // @ts-expect-error Can this happen?
        options.deleted = false;
        if (!(parent instanceof CONFIG.Actor.documentClass))
            return;
        // if (!foundry.utils.getProperty(this, "flags.dae.stackable")) { // Check whether this should be multi by default?
        //  this.updateSource({ "flags.dae.stackable": "multi" })
        //}
        const stackable = this.flags?.dae?.stackable ?? "";
        if (["noneName", "none", "noneNameOnly"].includes(stackable)) {
            if (!parent)
                return result = true;
            const hasExisting = parent.effects.filter(ef => {
                const efOrigin = ef.origin;
                switch (stackable) {
                    case "noneName":
                        // Effects with no origin are ignored
                        return !!(this.origin && efOrigin === this.origin && ef.name === this.name);
                    case "count":
                    case "countDeleteDecrement":
                        // @ts-expect-error Can this happen?
                        if (options.toggleEffect)
                            return !!(this.origin && efOrigin === this.origin && ef.name === this.name);
                        break;
                    case "noneNameOnly":
                        return ef.name === this.name;
                    case "none":
                        return !!(this.origin && efOrigin === this.origin);
                }
                return false;
            });
            if (hasExisting.length === 0)
                return result = true;
            // @ts-expect-error Can this happen?
            if (options.toggleEffect) {
                const updates = hasExisting.map(ef => ({ _id: ef.id, disabled: !ef.disabled }));
                await parent.updateEmbeddedDocuments("ActiveEffect", updates, options);
                return result = false;
            }
            if (debugEnabled > 0)
                warn("deleting existing effects ", parent.name, parent, hasExisting);
            options["existing"] = "effect-stacking";
            await parent.deleteEmbeddedDocuments("ActiveEffect", hasExisting.map(ef => ef.id ?? ""), options);
            // We need to wait for the chain of dependents to be deleted before allowing things to continue.
            let count = 0;
            // @ts-expect-error no dnd5e-types
            while (hasExisting.some(ef => ef.getDependents().length > 0) && count < 100) {
                count += 1;
                await busyWait(0.05);
            }
        }
    }
    catch (err) {
        error("removeExistingEffects ", err);
        result = true;
    }
    finally {
        return result;
    }
}
async function _preCreateEnchantmentEffect(data, options, user) {
    // There will be something needed here eventuall.
}
async function _preCreateActiveEffectIncrement(data, options, user) {
    if (debugEnabled > 0)
        warn("_preCreateActiveEffect", this, data, options, user);
    // Make changes to the effect data as needed
    let result = true;
    try {
        // @ts-expect-error Can this happen?
        if (options.isUndo)
            return result = true;
        const parent = this.parent;
        if (!(parent instanceof CONFIG.Actor.documentClass) /*|| actor.isToken*/)
            return result = true;
        // Check if we are trying to create an existing effect - not quite sure how that might happen
        if (parent.effects?.find(ef => ef.id === data._id && false)) {
            if (debugEnabled > 0)
                warn("Blocking creation of duplicate effect", this, parent.effects?.find(ef => ef.id === data._id));
            return result = false;
        }
        if (!this.flags?.dae?.specialDuration) {
            this.updateSource({ "flags.dae.specialDuration": [] });
            foundry.utils.setProperty(data, "flags.dae.specialDuration", []);
        }
        if (parent instanceof Actor) {
            let existingEffect;
            if (getStatusEffectsArray().find(se => se._id === this.id))
                existingEffect = parent.effects.find(ef => ef.id === this.id);
            else {
                existingEffect = parent.effects.find(ef => ef.origin === this.origin && effectBaseName(ef) === effectBaseName(this));
            }
            if (["count", "countDeleteDecrement"].includes(this.flags?.dae?.stackable)) {
                if (existingEffect) {
                    const stacks = (existingEffect.flags.dae.stacks ?? 1) + 1;
                    // const counter = globalThis.EffectCounter?.findCounter(getTokenDocument(this.parent), this.img ?? this.icon);
                    // await counter?.setValue(stacks);
                    await existingEffect.update({ "flags.dae.stacks": stacks, name: `${effectBaseName(existingEffect)} (${stacks})` });
                    if (existingEffect.getDependents && existingEffect.getDependents().length > 0) {
                        const deps = existingEffect.getDependents().filter(ef => ["count", "countDeleteDecrement"].includes(ef.flags?.dae?.stackable));
                        await parent.createEmbeddedDocuments("ActiveEffect", deps.map(ef => ef.toObject()), { keepId: true });
                    }
                    return result = false;
                }
            }
            else if (getStatusEffectsArray().find(se => se._id === this.id) && parent.effects.find(ef => ef.id === this._id)) {
                console.warn(`dae | Attempting to add ${this.id} when already presnt - ignoring`);
                return result = false;
            }
            let updates = {};
            if (CONFIG.ActiveEffect.legacyTransferral) {
                foundry.utils.setProperty(updates, "flags.dae.transfer", data.transfer === true ? true : false);
            }
            // Update the duration on the effect if needed
            if (this.flags?.dae?.durationExpression && parent instanceof Actor) {
                let sourceActor = parent;
                if (!data.transfer) { // for non-transfer effects we might be pointing to a different actor
                    const thing = fromUuidSync(this.origin);
                    if (thing?.actor)
                        sourceActor = thing.actor;
                }
                let theDurationRoll = new Roll(`${this.flags.dae.durationExpression}`, sourceActor?.getRollData());
                let theDuration = await theDurationRoll.evaluate();
                const inCombat = game.combat?.turns?.some(turnData => turnData.actor?.uuid === parent.uuid);
                if (inCombat) {
                    updates["duration.value"] = Math.floor(theDuration.total / CONFIG.time.roundTime + 0.5);
                    updates["duration.units"] = "rounds";
                }
                else {
                    updates["duration.value"] = theDuration.total;
                    updates["duration.units"] = "seconds";
                }
            }
            let changesChanged = false;
            let newChanges = [];
            for (let change of this.system.changes) {
                if (typeof change.value === "string") {
                    const token = getSelfTarget(parent);
                    const tokenUuid = token instanceof TokenDocument ? token.uuid : token.document.uuid;
                    const context = {
                        "@actorUuid": parent?.uuid,
                        "@tokenUuid": tokenUuid,
                        "@targetUuid": tokenUuid
                    };
                    for (let key of Object.keys(context)) {
                        // Can't do a Roll.replaceFormula because of non-matches being replaced.
                        let newValue;
                        if (change.value.includes(`@${key}`))
                            continue;
                        newValue = change.value.replaceAll(key, context[key]);
                        if (newValue !== change.value) {
                            changesChanged = true;
                            change.value = newValue;
                        }
                    }
                }
                const inline = typeof change.value === "string" && change.value.includes("[[");
                if (change.key === "StatusEffect") {
                    console.warn("ActiveEffect | StatusEffect is not supported in v12 and above");
                    continue;
                }
                else if (inline) {
                    const rgx = /[\[]{2,3}(\/[a-zA-Z]+\s)?(.*?)([\]]{2,3})(?:{([^}]+)})?/gi;
                    const silentInline = change.value.includes("[[[");
                    const newChange = foundry.utils.duplicate(change);
                    changesChanged = true;
                    for (let match of change.value.matchAll(rgx)) {
                        if (!match[1]) {
                            const newValue = await evalInline(match[2], parent, this, silentInline);
                            newChange.value = newChange.value.replace(match[0], `${newValue}`);
                        }
                    }
                    newChanges.push(newChange);
                }
                else if (change.key.startsWith("macro.itemMacro")) {
                    const item = fromUuidSync(this.origin);
                    if (item instanceof Item) {
                        let macroCommand = foundry.utils.getProperty(item, "flags.dae.macro.command") ?? foundry.utils.getProperty(item, "flags.itemacro.macro.command") ?? foundry.utils.getProperty(item, "flags.itemacro.macro.data.command");
                        foundry.utils.setProperty(updates, `flags.dae.itemMacro`, macroCommand);
                    }
                }
                else if (change.key.startsWith("macro.activityMacro") && this.activity) {
                    const activity = fromUuidSync(this.activity);
                    // @ts-expect-error no dnd5e-types _AND_ no midi typing (which is what adds `macro`)
                    foundry.utils.setProperty(updates, "flags.dae.activityMacro", activity?.macro?.command);
                }
                else
                    newChanges.push(change);
            }
            if (changesChanged)
                updates["system.changes"] = newChanges;
            this.updateSource(updates);
        }
    }
    catch (err) {
        console.warn("dae | _preCreateActiveEffect", err);
    }
    finally {
        return result;
    }
}
async function evalInline(expression, actor, effect, silent) {
    try {
        warn("Doing inlinve eval", expression);
        expression = expression.replaceAll("@data.", "@");
        const roll = await (new Roll(expression, actor?.getRollData())).evaluate();
        if (showInline && !silent) {
            roll.toMessage({ speaker: ChatMessage.getSpeaker({ actor }), flavor: `${effect.name} ${expression}` });
        }
        return `${roll.total}`;
    }
    catch (err) {
        console.warn(`dae | evaluate args error: rolling ${expression} failed`, err);
        return "0";
    }
}
function recordDisabledSuppressedHook(effect, updates, options, userId) {
    // @ts-expect-error v14 effect.system.changes
    foundry.utils.setProperty(options, "dae.active", { wasDisabled: effect.disabled, wasSuppressed: effect.isSuppressed, oldChanges: foundry.utils.duplicate(effect.system.changes) });
    return true;
}
export function updateActiveEffectHook(effect, updates, options, userId) {
    let result = true;
    // @ts-expect-error Can this happen?
    if (options.isUndo)
        return result = true;
    if (userId !== game.user?.id)
        return result = true;
    const parent = effect.parent;
    if (!parent)
        return true;
    // if ((foundry.utils.getProperty(updates, "flags.dae.itemsToDelete") ?? []).length > 0) return true;
    let actor;
    if (!CONFIG.ActiveEffect.legacyTransferral && parent instanceof CONFIG.Item.documentClass) {
        if (!effect.transfer)
            return;
        // Suppressed effects are covered by the item update
        actor = parent.parent;
        if (actor instanceof CONFIG.Actor.documentClass) {
            // if disabled status changed remove dependent effects macro.execute, createItem etc
            const wasDisabled = options.dae?.active?.wasDisabled ?? false;
            const becameDisabled = effect.disabled && !(options.dae?.active?.wasDisabled ?? false);
            const becameEnabled = (options.dae?.active?.wasDisabled ?? false) && !(effect.disabled ?? false);
            const item = effect.parent;
            if (becameDisabled) {
                // @ts-expect-error v14 effect.system.changes
                for (let change of effect.system.changes) {
                    removeEffectChange(actor, [], effect, item, change, options);
                }
            }
            else if (becameEnabled) {
                // @ts-expect-error v14 effect.system.changes
                for (let change of effect.system.changes) {
                    addEffectChange(actor, [], effect, item, change, options);
                }
            }
            return true;
        }
    }
    if (parent instanceof Actor)
        actor = parent;
    // if (effect.disabled === context.dae?.active?.disabled && effect.isSuppressed === context.dae?.active?.isSuppressed) return true;
    if (!actor)
        return true;
    let changeLoop = async () => {
        try {
            if (!actor)
                return;
            // const item = await fromUuid(effect.origin);
            const tokens = actor.isToken ? [actor.token?.object] : actor.getActiveTokens();
            const token = tokens[0];
            if (!(token instanceof foundry.canvas.placeables.Token))
                return;
            // @ts-expect-error no dnd5e-types
            if (useDetermineSuppression)
                effect.determineSuppression();
            // Just deal with equipped etc
            warn("add active effect actions", actor, updates);
            const tokenMagic = globalThis.TokenMagic;
            let addedChanges = [];
            let removedChanges = [];
            let existingChanges = [];
            let oldChanges = [];
            let newChanges = [];
            // @ts-expect-error v14 updates.system?.changes
            if (updates.system?.changes) {
                // const removedChanges = (context.dae?.active?.oldChanges ?? []).filter(change => !effect.system.changes.some(c => c.key === change.key));
                oldChanges = (foundry.utils.getProperty(options, "dae.active.oldChanges") ?? []).sort((a, b) => a.key < b.key ? -1 : 1);
                // @ts-expect-error v14 effect.system.changes
                newChanges = effect.system.changes.filter(c => c.key && c.key !== "").sort((a, b) => a.key < b.key ? -1 : 1);
                // @ts-expect-error v14 change.type replaces change.mode
                removedChanges = oldChanges.filter(change => !newChanges.some(c => c.key === change.key && c.type === change.type && c.value === change.value));
                // @ts-expect-error v14 change.type replaces change.mode
                existingChanges = oldChanges.filter(change => newChanges.some(c => c.key === change.key && c.type === change.type && c.value === change.value));
                // @ts-expect-error v14 change.type replaces change.mode
                addedChanges = newChanges.filter(change => !oldChanges.some(c => c.key === change.key && c.type === change.type && c.value === change.value));
                if (debugEnabled > 0) {
                    warn("updateActiveEffect hook | old changes", oldChanges);
                    warn("updateActiveEffect hook | new changes", newChanges);
                    warn("updateActiveEffect hook | removed Changes ", removedChanges);
                    warn("updateActiveEffect hook | added changes ", addedChanges);
                    warn("updateActiveEffect hook | existing changes", existingChanges);
                }
                // @ts-expect-error v14 effect.system.changes
            }
            else
                existingChanges = effect.system.changes;
            const wasDisabled = options.dae?.active?.wasDisabled ?? false;
            const wasSuppressed = options.dae?.active?.wasSuppressed ?? false;
            const becameDisabled = effect.disabled && !(options.dae?.active?.wasDisabled ?? false);
            const becameSuppressed = effect.isSuppressed && !(options.dae?.active?.wasSuppressed ?? false);
            // TODO Come back and make this use addEffectChange and removeEffectChange instead of the below
            if (becameSuppressed || becameDisabled || removedChanges.length > 0) {
                let changesToDisable = [];
                if (becameSuppressed || becameDisabled) {
                    // newly disabled disable everything
                    changesToDisable = existingChanges.concat(removedChanges);
                }
                else if (!wasDisabled && !wasSuppressed) {
                    // changes being removed were enabled so disable them
                    changesToDisable = removedChanges;
                }
                for (let change of changesToDisable) {
                    if (ceInterface && change.key === "macro.CE") {
                        await removeConvenientEffectsChange(change.value, actor.uuid, undefined, actor.isToken);
                    }
                    if (token && tokenMagic && change.key === "macro.tokenMagic")
                        removeTokenMagicChange(actor, change, tokens, options);
                    if (["macro.createItem", "macro.createItemRunMacro"].includes(change.key)) {
                        await removeCreateItemChange(change.value, actor, effect, options);
                    }
                    if (change.key === "macro.StatusEffect" || change.key === "StatusEffect") {
                        await removeConditionChange(actor, change, token, effect, options);
                    }
                }
                if (changesToDisable.some(change => change.key.startsWith("macro.execute") || change.key.startsWith("macro.itemMacro") || change.key.startsWith("macro.actorUpdate") || change.key.startsWith("macro.activityMacro"))) {
                    warn("dae add macro off", actionQueue.remaining);
                    const effectData = effect.toObject(false);
                    // @ts-expect-error v14 system.changes
                    if (updates.system?.changes)
                        effectData.system.changes = oldChanges;
                    if (becameDisabled)
                        options["expiry-reason"] = "effect-disabled";
                    else if (becameSuppressed)
                        options["expiry-reason"] = { "expiry-reason": "effect-suppressed" };
                    else
                        options["expiry-reason"] = { "expiry-reason": "change-deleted" };
                    options.effectUuid = effect.uuid;
                    await actionQueue.add(daeMacro, "off", actor, effectData, options);
                }
            }
            const becameEnabled = (options.dae?.active?.wasDisabled ?? false) && !(effect.disabled ?? false);
            const becameUnsuppressed = (options.dae?.active?.wasSuppressed ?? false) && !(effect.isSuppressed ?? false);
            if (becameEnabled || becameUnsuppressed || addedChanges.length > 0) {
                let changesToEnable = [];
                if (becameEnabled || becameUnsuppressed) {
                    // newly enabled enable everything
                    changesToEnable = existingChanges.concat(addedChanges);
                }
                else if (!effect.disabled && !effect.isSuppressed) {
                    // changes being added need to be enabled
                    changesToEnable = addedChanges;
                }
                for (let change of changesToEnable) {
                    if (ceInterface && change.key === "macro.CE") {
                        await addConvenientEffectsChange(change.value, actor.uuid, undefined, undefined, actor.isToken);
                    }
                    if (token && tokenMagic && change.key === "macro.tokenMagic")
                        addTokenMagicChange(actor, change, tokens);
                    if (["macro.createItem", "macro.createItemRunMacro"].includes(change.key)) {
                        await addCreateItemChange(change, actor, effect, options);
                    }
                    if (change.key === "macro.StatusEffect" || change.key === "StatusEffect") {
                        await addConditionChange(actor, change, token, effect);
                    }
                }
                if (changesToEnable.some(change => change.key.startsWith("macro.execute") || change.key.startsWith("macro.itemMacro") || change.key.startsWith("macro.actorUpdate") || change.key.startsWith("macro.activityMacro"))) {
                    warn("action queue add dae macro on ", actionQueue.remaining);
                    await actionQueue.add(daeMacro, "on", actor, effect.toObject(false), { effectUuid: effect.uuid });
                }
            }
            // @ts-expect-error no dnd5e-types
            for (let dependent of effect.getDependents()) {
                if (dependent.disabled !== undefined && (dependent.disabled !== effect.disabled || dependent.isSuppressed !== effect.isSuppressed)) {
                    await dependent.update({ "disabled": effect.disabled || effect.isSuppressed });
                }
            }
        }
        catch (err) {
            console.warn("dae | updating active effect error", err);
        }
        finally {
            return result;
        }
    };
    changeLoop();
    return result = true;
}
export function preUpdateActiveEffectEvalInlineHook(candidate, updates, options, userId) {
    const parent = candidate.parent;
    // @ts-expect-error Can this happen?
    if (options.isUndo)
        return true;
    if (!parent)
        return true;
    if (CONFIG.ActiveEffect.legacyTransferral && !(parent instanceof CONFIG.Actor.documentClass))
        return true;
    let actor;
    if (parent instanceof CONFIG.Actor.documentClass)
        actor = parent;
    else if (parent instanceof CONFIG.Item.documentClass && effectIsTransfer(candidate))
        actor = parent.parent;
    if (!actor)
        return true;
    try {
        // const rgx = /\[\[(\/[a-zA-Z]+\s)?(.*?)([\]]{2,3})(?:{([^}]+)})?/gi;
        // @ts-expect-error v14 system.changes
        for (let change of candidate.system?.changes ?? []) {
            let silentInline = typeof change.value === "string" && change.value.includes("[[[");
            let inline = typeof change.value === "string" && change.value.includes("[[");
            if (inline || silentInline) {
                const rgx = /[\[]{2,3}(\/[a-zA-Z]+\s)?(.*?)([\]]{2,3})(?:{([^}]+)})?/gi;
                let newChangeValue = foundry.utils.duplicate(change.value);
                for (let match of change.value.matchAll(rgx)) {
                    if (!match[1]) {
                        const newValue = evalInline(match[2], actor, candidate, silentInline);
                        newChangeValue = newChangeValue.replace(match[0], `${newValue}`);
                    }
                }
                change.value = newChangeValue;
            }
            ;
        }
    }
    catch (err) {
        console.warn(`dae | update active effect Actor ${actor.name}, Effect ${candidate.name}`, updates, err);
    }
    finally {
        return true;
    }
}
async function _preDeleteActiveEffectDecrement(options, user) {
    if (!options.removeStacks)
        options.removeStacks = 1;
    if (this.flags.dae?.stackable === "count")
        options.removeStacks = Math.max(1, this.flags.dae.stacks ?? 1);
    // @ts-expect-error Can this happen?
    if (options.forceDelete || !(this.parent instanceof Actor))
        return true;
    const stacks = Math.max(0, this.flags?.dae?.stacks ?? 1);
    const newStacks = Math.max(1, stacks - options.removeStacks);
    if (stacks <= options.removeStacks) {
        options.removeStacks = Math.max(1, stacks);
        return true;
    }
    foundry.utils.setProperty(this, "flags.dae.stacks", newStacks);
    await this.update({
        name: `${effectBaseName(this)} (${newStacks})`,
        flags: {
            dae: {
                stacks: newStacks
            }
        }
    });
    // const counter = globalThis.EffectCounter?.findCounter(getTokenDocument(this.parent), this.img ?? this.icon);
    // await counter?.setValue(newStacks);
    debug("decrementing complete", this.name, stacks);
    // @ts-expect-error no dnd5e-types
    const dependents = this.getDependents();
    if (dependents)
        for (let dependent of dependents) {
            if (fromUuidSync(dependent.uuid))
                await dependent.delete(options);
        }
    return false;
}
// async function _preDeleteActiveEffectBeta(wrapped, ...args) {
//   let [options, userId] = args;
//   if (options.forceDelete || !(this.parent instanceof Actor) || !["countDeleteDecrement", "count"].includes(this.flags.dae?.stackable))
//     return wrapped(...args);
//   const stacks = this.flags.dae.stacks;
//   if (stacks === 1) {
//     options.removeStacks = 1;
//     return wrapped(...args);
//   }
//   if (this.flags.dae.stackable === "count") options.removeStacks = stacks;
//   else options.removeStacks = 1;
//   foundry.utils.setProperty(this, "flags.dae.stacks", stacks - 1);
//   await this.update({ "flags.dae.stacks": stacks - 1, name: `${effectBaseName(this)} (${stacks - 1})` });
//   // const counter = globalThis.EffectCounter?.findCounter(getTokenDocument(this.parent), this.img ?? this.icon);
//   // await counter?.setValue(stacks - 1);
//   debug("decrementing complete", this.name, stacks);
//   if (this.getDependents()) for (let dependent of this.getDependents()) {
//     if (fromUuidSync(dependent.uuid))
//       await dependent.delete(...args);
//   }
//   return false;
// }
export function deleteActiveEffectHook(effect, options, userId) {
    if (game.user?.id !== userId)
        return true;
    // @ts-expect-error Can this happen?
    if (options.isUndo)
        return true;
    if (!effect.parent)
        return true;
    let actor;
    if (CONFIG.ActiveEffect.legacyTransferral && !(effect.parent instanceof CONFIG.Actor.documentClass))
        return true;
    if (effect.parent instanceof CONFIG.Actor.documentClass)
        actor = effect.parent;
    else if (effect.parent instanceof CONFIG.Item.documentClass && effect.transfer)
        actor = effect.parent.parent;
    if (!actor)
        return true;
    let changesLoop = async () => {
        if (!actor)
            return;
        const tokens = actor.token ? [actor.token.object] : actor.getActiveTokens();
        const token = tokens[0];
        const tokenMagic = globalThis.TokenMagic;
        /// if (actor.isToken) await delay(1);
        let entityToDelete;
        // @ts-expect-error v14 effect.system.changes
        if (effect.system?.changes) {
            // @ts-expect-error v14 effect.system.changes
            for (let change of effect.system.changes) {
                try {
                    if (token && tokenMagic && change.key === "macro.tokenMagic")
                        await removeTokenMagicChange(actor, change, tokens);
                    if (["macro.createItem", "macro.createItemRunMacro"].includes(change.key)) {
                        // @ts-expect-error Is this okay?
                        options.effectDeleted = true;
                        await removeCreateItemChange(change.value, actor, effect, options);
                    }
                    if (change.key === "macro.StatusEffect" || change.key === "StatusEffect") {
                        await removeConditionChange(actor, change, token, effect, options); // TODO this is not right
                    }
                    if (ceInterface && change.key === "macro.CE") {
                        await removeConvenientEffectsChange(change.value, actor.uuid, effect.origin, actor.isToken);
                    }
                    if (change.key === "flags.dae.deleteUuid" && change.value) {
                        await socketlibSocket.executeAsGM("deleteUuid", { uuid: change.value });
                    }
                    if (change.key === "flags.dae.suspendActiveEffect" && change.value) {
                        await socketlibSocket.executeAsGM("suspendActiveEffect", { uuid: change.value });
                    }
                    if (change.key === "flags.dae.deleteOrigin")
                        entityToDelete = effect.origin;
                    if (!foundry.utils.getProperty(options, "expiry-reason"))
                        foundry.utils.setProperty(options, "expiry-reason", "effect-deleted");
                    // @ts-expect-error v14 effect.system.changes
                    if (effect.system.changes.some(change => change.key.startsWith("macro.execute") || change.key.startsWith("macro.itemMacro") || change.key.startsWith("macro.actorUpdate") || change.key.startsWith("macro.activityMacro"))) {
                        // @ts-expect-error Is this okay?
                        options.effectUuid = effect.uuid;
                        warn("action queue dae macro add off ", actionQueue.remaining);
                        await actionQueue.add(daeMacro, "off", actor, effect.toObject(false), options);
                    }
                    if (entityToDelete)
                        await socketlibSocket.executeAsGM("deleteUuid", { uuid: entityToDelete });
                }
                catch (err) {
                    console.warn("dae | error deleting active effect ", effect, err);
                }
            }
            if (effect.origin) {
                let origin = await fromUuid(effect.origin);
                // Remove the associated animation if the origin points to the actor or if the items actor is the effects actor
                // Covers the spirit guardian case where all the aura's point back to the source item.
                if (globalThis.Sequencer && (origin === actor || origin?.parent === actor))
                    globalThis.Sequencer.EffectManager.endEffects({ origin: effect.origin });
            }
        }
    };
    changesLoop();
    return true;
}
export function getSelfTarget(actor) {
    if (actor?.token)
        return actor.token.object;
    const speaker = ChatMessage.getSpeaker({ actor });
    if (speaker.token) {
        const token = canvas?.tokens?.get(speaker.token);
        if (token)
            return token;
    }
    const tokenData = actor?.prototypeToken.toObject(false);
    return new CONFIG.Token.documentClass(tokenData);
}
export async function daeMacro(action, actor, effectData, lastArgOptions = {}) {
    let selfTarget;
    let macro;
    let theItem;
    if (effectData instanceof ActiveEffect && !lastArgOptions.effectUuid)
        lastArgOptions.effectUuid = effectData.uuid;
    // Work out what itemData should be
    warn("Dae macro ", action, actor, effectData, lastArgOptions);
    // @ts-expect-error v14 system.changes on toObject() data
    if (!effectData.system?.changes)
        return effectData;
    if (effectData instanceof ActiveEffect) {
        if (effectData.transfer && effectData.parent instanceof Item)
            theItem = effectData.parent;
        effectData = effectData.toObject(false);
    }
    if (lastArgOptions.item)
        theItem = lastArgOptions.item;
    if (!theItem) { // follow the origin trail backwards
        let source = effectData.origin ? await fromUuid(effectData.origin) : undefined;
        let count;
        for (count = 0; count < 10 && source instanceof ActiveEffect && !(source.parent instanceof Item); count++) {
            const newSource = await fromUuid(source.origin);
            if (!newSource)
                source = source.parent;
            else
                source = newSource;
        }
        if (count === 10) {
            console.warn("dae | daeMacro | too many levels of origin", effectData);
        }
        else if (source instanceof Item)
            theItem = source;
        else if (source?.parent instanceof Item)
            theItem = source.parent;
        else if (source?.item instanceof Item)
            theItem = source.item;
    }
    if (!theItem && effectData.flags?.dae?.itemUuid) {
        theItem = fromUuidSync(effectData.flags.dae.itemUuid);
    }
    if (!theItem && effectData.flags?.dae?.itemData) {
        theItem = new CONFIG.Item.documentClass(effectData.flags.dae.itemData, { parent: actor });
    }
    let context = actor.getRollData();
    if (theItem) {
        context.item = theItem;
        context.itemData = theItem.toObject(false);
        if (theItem)
            foundry.utils.setProperty(effectData, "flags.dae.itemData", theItem.toObject());
    }
    let tokenUuid;
    if (actor.token) {
        tokenUuid = actor.token.uuid;
        selfTarget = actor.token.object;
    }
    else {
        selfTarget = getSelfTarget(actor);
        tokenUuid = selfTarget instanceof TokenDocument ? selfTarget.uuid : selfTarget.document.uuid;
    }
    // @ts-expect-error v14 system.changes on toObject() data
    for (let change of (effectData.system?.changes ?? [])) {
        try {
            if (!allMacroEffects.includes(change.key))
                continue;
            context.stackCount = effectData.flags?.dae?.stacks ?? 1;
            let functionMatch;
            if (typeof change.value === "string")
                change.value = change.value.trim();
            if (change.value.startsWith("function.")) {
                const paramRe = /function\.\w+(\.\w+)*\("[^"]*"(?:\s*,\s*"[^"]*")+?\)/;
                const paramMatch = change.value.match(paramRe);
                if (paramMatch)
                    functionMatch = paramMatch[0];
                else
                    functionMatch = change.value.split(" ")[0];
                functionMatch = functionMatch.replace("function.", "");
                if (change.key.includes("macro.execute"))
                    change.value = change.value.replace(functionMatch, "FunctionMatch");
            }
            const theChange = await evalArgs({ item: theItem, effectData, context, actor, change, doRolls: true });
            let args = [];
            let v11args = {};
            if (typeof theChange.value === "string") {
                tokenizer.tokenize(theChange.value, (token) => args.push(token));
                if (theItem)
                    args = args.map(arg => {
                        if ("@itemData" === arg) {
                            return theItem.toObject(false);
                        }
                        else if ("@item" === arg) {
                            return theItem;
                        }
                        if (typeof arg === "string") {
                            const splitArg = arg.split("=");
                            if (splitArg.length === 2) {
                                if (splitArg[1] === "@itemData") {
                                    const itemData = theItem?.toObject(false);
                                    v11args[splitArg[0]] = itemData;
                                    return itemData;
                                }
                                else if (splitArg[1] === "@item") {
                                    v11args[splitArg[0]] = theItem;
                                    return theItem;
                                }
                                else
                                    v11args[splitArg[0]] = splitArg[1];
                            }
                        }
                        return arg;
                    });
            }
            else
                args = [change.value];
            if (theChange.key.includes("macro.execute") || theChange.key.includes("macro.itemMacro") || change.key.startsWith("macro.activityMacro")) {
                if (functionMatch) {
                    macro = new CONFIG.Macro.documentClass({
                        name: "DAE-Item-Macro",
                        type: "script",
                        img: null,
                        ownership: { default: CONST.DOCUMENT_OWNERSHIP_LEVELS.OWNER },
                        author: game.user?.id,
                        command: `return await ${functionMatch}.bind(this)({ speaker, actor, token, character, item, args, scope })`,
                    });
                    // TODO (Michael) `theItem` is treated as mandatory in `getMacro`, but here isn't guaranteed - or is it?
                }
                else
                    macro = await getMacro({ change, name: args[0] }, theItem, effectData, lastArgOptions.effectUuid);
                if (!macro) {
                    //TODO localize this
                    if (action !== "off") {
                        ui.notifications?.warn(`macro.execute/macro.itemMacro | No macro ${args[0]} found`);
                        warn(`macro.execute/macro.itemMacro | No macro ${args[0]} found`);
                        continue;
                    }
                }
                // doing this refetch to try and make sure the actor has not been deleted
                if (!fromUuidSync(actor.uuid)) {
                    error("actor vanished", actor.name, actor.uuid);
                    return;
                }
                const activityUuid = effectData.flags?.dae?.activity;
                let lastArg = foundry.utils.mergeObject(lastArgOptions, {
                    effectId: effectData._id,
                    origin: effectData.origin,
                    activity: activityUuid,
                    efData: effectData,
                    actorId: actor.id,
                    actorUuid: actor.uuid,
                    tokenId: selfTarget?.id,
                    effectUuid: lastArgOptions.effectUuid,
                    tokenUuid,
                }, { overwrite: false, insertKeys: true, insertValues: true, inplace: false });
                if (theChange.key.includes("macro.execute"))
                    args = args.slice(1);
                let macroArgs = [action];
                macroArgs = macroArgs.concat(args).concat(lastArg);
                const macroActivity = await fromUuid(activityUuid);
                const effect = fromUuidSync(lastArgOptions.effectUuid);
                const scope = {
                    actor,
                    token: selfTarget instanceof TokenDocument ? selfTarget.object : selfTarget,
                    lastArgValue: lastArg,
                    item: theItem,
                    macroItem: theItem,
                    macroActivity,
                    effect
                };
                scope.args = macroArgs.filter(arg => {
                    if (typeof arg === "string") {
                        const parts = arg.split("=");
                        if (parts.length === 2) {
                            scope[parts[0]] = parts[1];
                            return false;
                        }
                    }
                    return true;
                });
                return await macro?.execute(scope);
            }
            else if (theChange.key === "macro.actorUpdate") {
                let lastArg = foundry.utils.mergeObject(lastArgOptions, {
                    effectId: effectData._id,
                    origin: effectData.origin,
                    efData: effectData,
                    actorId: actor.id,
                    actorUuid: actor.uuid,
                    tokenId: selfTarget?.id,
                    tokenUuid,
                }, { overwrite: false, insertKeys: true, insertValues: true, inplace: false });
                // try and make sure the actor has not vanished
                if (!fromUuidSync(actor.uuid)) {
                    error("actor vanished", actor.name, actor.uuid);
                }
                await macroActorUpdate(action, ...args, lastArg);
                // result = await macroActorUpdate(action, ...args, lastArg);
            }
        }
        catch (err) {
            const message = `daeMacro | "${action}" macro "${macro?.name}" for actor ${actor?.name} in ${theItem ? "item " + theItem.name : ""} ${actor?.uuid} ${theItem?.uuid}`;
            console.warn(message, err);
            if (globalThis.MidiQOL?.apps?.TroubleShooter)
                globalThis.MidiQOL.apps.TroubleShooter.recordError(err, message);
        }
    }
    ;
    return effectData;
}
export async function evalArgs({ effectData, item, context, actor, change, spellLevel = undefined, damageTotal = 0, doRolls = false, critical = false, fumble = false, whisper = false, itemCardUuid = null, tokenUuid = null }) {
    const itemUuid = item?.uuid ?? effectData.flags?.dae?.itemUuid;
    if (!item && itemUuid)
        item = await fromUuid(itemUuid);
    if (typeof change.value !== 'string')
        return change; // nothing to do
    const returnChange = foundry.utils.duplicate(change);
    // @ts-expect-error context isn't typed
    spellLevel ??= context.flags?.dnd5e?.spellLevel;
    let contextToUse = foundry.utils.mergeObject({
        scene: canvas?.scene?.id,
        token: ChatMessage.getSpeaker({ actor }).token,
        target: "@target",
        targetUuid: "@targetUuid",
        targetActorUuid: "@targetActorUuid",
        spellLevel,
        itemLevel: spellLevel,
        damage: damageTotal,
        itemCardUuid: itemCardUuid,
        unique: foundry.utils.randomID(),
        actor: actor.id,
        actorUuid: actor.uuid,
        critical,
        fumble,
        whisper,
        change: JSON.stringify(change),
        itemId: item?.id,
        itemUuid: item?.uuid,
        tokenUuid
    }, context, { overwrite: true });
    //contextToUse["item"] = "@item";
    if (item) {
        foundry.utils.setProperty(effectData, "flags.dae.itemUuid", item.uuid);
        foundry.utils.setProperty(effectData, "flags.dae.itemData", item.toObject(false));
        contextToUse["itemData"] = "@itemData";
        contextToUse["item"] = item.getRollData()?.item;
    }
    else {
        contextToUse["itemData"] = "@itemData";
        contextToUse["item"] = "@item";
    }
    returnChange.value = returnChange.value.replace("@item.level", "@itemLevel");
    returnChange.value = returnChange.value.replace(/@data./g, "@");
    const returnChangeValue = Roll.replaceFormulaData(returnChange.value, contextToUse, { missing: "0", warn: false });
    if (typeof returnChange.value === "object") {
        console.error("object returned from replaceFormula Data", returnChange.value);
    }
    else {
        returnChange.value = returnChangeValue;
    }
    returnChange.value = returnChange.value.replaceAll("##", "@");
    if (typeof returnChange.value === "string" && !returnChange.value.includes("[[")) {
        switch (change.key) {
            case "macro.itemMacro":
            case "macro.itemMacro.local":
            case "macro.itemMacro.GM":
            case "macro.execute":
            case "macro.execute.local":
            case "macro.execute.GM":
            case "macro.actorUpdate":
            case "macro.activityMacro":
                break;
            case "macro.CE":
            case "macro.StatusEffect":
            case "StatusEffect":
            case "macro.tokenMagic":
            case "macro.createItem":
            case "macro.createItemRunMacro":
            case "macro.summonToken":
                break;
            default:
                const currentValue = foundry.utils.getProperty(actor, change.key);
                if (doRolls && typeof (currentValue ?? ValidSpec.actorSpecs[actor.type].allSpecsObj[change.key]?.fieldType) === "number") {
                    const roll = new Roll(returnChange.value, contextToUse);
                    if (!roll.isDeterministic) {
                        error("evalArgs: expression is not deterministic dice terms ignored", actor.name, actor.uuid, returnChange.value);
                        returnChange.value = String(roll.evaluateSync({ strict: false }).total);
                    }
                }
                ;
                break;
        }
        ;
        debug("evalargs: change is ", returnChange);
    }
    return returnChange;
}
export async function getMacro({ change, name }, item, effectData, effectUuid) {
    if (change.key.includes("macro.execute")) {
        let macro = game.macros?.getName(name);
        if (macro)
            return macro;
        let itemOrMacro;
        itemOrMacro = await fromUuid(name);
        if (itemOrMacro) {
            if (itemOrMacro instanceof Item) {
                const macroData = itemOrMacro.flags?.dae?.macro ?? itemOrMacro.flags?.itemacro?.macro;
                macroData.flags = foundry.utils.mergeObject(macroData.flags ?? {}, { dnd5e: { itemMacro: true } });
                return new CONFIG.Macro.documentClass(macroData);
            }
            else if (itemOrMacro instanceof Macro) {
                return itemOrMacro;
            }
            // Other uuids are not valid
            return undefined;
        }
    }
    else if (change.key.startsWith("macro.activityMacro") || change.key.startsWith("macro.itemMacro")) {
        let macroCommand;
        if (change.key.startsWith("macro.activityMacro")) {
            let activityUuid = effectData?.flags?.dae?.activity;
            if (activityUuid) {
                const activity = await fromUuid(activityUuid);
                macroCommand = activity?.macro?.command;
            }
        }
        else if (change.key.startsWith("macro.itemMacro")) {
            // Resolve item from effectUuid if not provided
            if (!item && effectUuid) {
                const effect = fromUuidSync(effectUuid);
                if (effect instanceof ActiveEffect && effect.parent instanceof Item)
                    item = effect.parent;
            }
            macroCommand = effectData?.flags?.dae?.itemMacro
                ?? item?.flags?.dae?.macro?.command
                ?? item?.flags?.itemacro?.macro?.command;
            const itemData = effectData?.flags?.dae?.itemData;
            if (!macroCommand && itemData)
                macroCommand = itemData.flags?.dae?.macro?.command;
            if (!macroCommand && itemData)
                macroCommand = itemData.flags?.itemacro?.macro?.command;
            if (!macroCommand && !item) { // we never got an item do a last ditch attempt
                warn("eval args: fetching item from effectData/origin ", effectData?.origin);
                const itemOrEffect = fromUuidSync(effectData?.origin);
                if (itemOrEffect instanceof CONFIG.Item.documentClass)
                    item = itemOrEffect;
                if (!item) {
                    const activity = fromUuidSync(effectData?.flags?.dae?.activity);
                    // @ts-expect-error no dnd5e-types
                    if (activity)
                        item = activity.item;
                }
                macroCommand = item?.flags?.dae?.macro?.command ?? item?.flags?.itemacro?.macro?.command;
            }
        }
        if (!macroCommand) {
            const itemOrMacro = await fromUuid(name);
            if (itemOrMacro instanceof Macro)
                macroCommand = itemOrMacro.command;
            if (itemOrMacro instanceof Item) {
                const macro = itemOrMacro.flags?.dae?.macro ?? itemOrMacro.flags?.itemacro?.macro;
                macroCommand = macro?.command;
            }
        }
        if (!macroCommand) {
            macroCommand = effectData?.flags?.dae?.itemMacro;
        }
        if (!macroCommand) {
            macroCommand = `if (!args || args[0] === "on") {ui.notifications.warn("macro.itemMacro | No macro found for item ${item?.name}");}`;
            warn(`No macro found for item ${item?.name}`);
        }
        return new CONFIG.Macro.documentClass({
            name: "DAE-Item-Macro",
            type: "script",
            img: null,
            command: macroCommand,
            author: game.user?.id,
            ownership: { default: CONST.DOCUMENT_OWNERSHIP_LEVELS.OWNER },
            // TODO see if this should change.
            flags: { dnd5e: { itemMacro: true } }
        });
    }
    else if (change.key === "actorUpdate") {
        console.error("Should not be trying to lookup the macro for actorUpdate");
    }
    return undefined;
}
/*
 * apply non-transfer effects to target tokens - provided for backwards compat
 */
export async function doEffects(item, activate, targets = undefined, options) {
    return await applyNonTransferEffects(item, activate, targets, options);
}
export async function doActivityEffects(activity, activate, targets = undefined, activityEffectsUuids, options) {
    const activityEffects = activityEffectsUuids.map(aeUuid => fromUuidSync(aeUuid) ?? activity.effects.find(ae => ae.effect.uuid === aeUuid)?.effect).filter(ef => ef).map(ef => ef.toObject());
    // TODO dnd5e v4 - a temporary fix to make sure the effects are not disabled when applied
    activityEffects.forEach(ef => ef.disabled = false);
    return await applyActivityEffects(activity, activate, targets, activityEffects, options);
}
export async function applyActivityEffects(activity, activate, targets, activityEffects, options = {
    context: {},
    critical: false,
    damageTotal: null,
    effectsToApply: [],
    fumble: false,
    itemCardUuid: null,
    origin: activity.item.uuid,
    removeMatchLabel: false,
    selfEffects: "none",
    spellLevel: 0,
    toggleEffect: false,
    whisper: false,
}) {
    if (!options.applyAll)
        activityEffects = activityEffects.filter(aeData => aeData.flags?.dae?.dontApply !== true);
    else
        activityEffects.forEach(aeData => foundry.utils.setProperty(aeData, "flags.dae.dontApply", false));
    if (activityEffects.length === 0)
        return;
    const rollData = activity.item.getRollData(); //TODO if not caster eval move to evalArgs call
    options.toggleEffect = activity.midiProperties?.toggleEffect || activity.item.flags?.midiProperties?.toggleEffect;
    let macroLocation = "mixed";
    for (let [aeIndex, activeEffectData] of activityEffects.entries()) {
        // @ts-expect-error v14 system.changes on toObject() data
        for (let [changeIndex, change] of activeEffectData.system.changes.entries()) {
            const doRolls = allMacroEffects.includes(change.key);
            if (doRolls) {
                if (macroDestination[change.key] === "local" && macroLocation !== "GM") {
                    macroLocation = "local";
                }
                else if (macroDestination[change.key] === "GM")
                    macroLocation = "GM";
            }
            // eval args before calling GMAction so macro arguments are evaled in the casting context.
            // Any @fields for macros are looked up in actor context and left unchanged otherwise
            rollData.stackCount = activeEffectData.flags?.dae?.stacks ?? 1;
            const evalArgsOptions = foundry.utils.mergeObject(options, {
                effectData: activeEffectData,
                change,
                doRolls
            });
            evalArgsOptions.context = foundry.utils.mergeObject(rollData, options.context ?? {}, { recursive: false });
            evalArgsOptions.context.activity = activity.getRollData?.() ?? activity;
            evalArgsOptions.item = activity.item;
            if (activity.actor)
                evalArgsOptions.actor = activity.actor;
            let newChange = await evalArgs(evalArgsOptions);
            // @ts-expect-error v14 system.changes on toObject() data
            activeEffectData.system.changes[changeIndex] = newChange;
        }
        ;
        // @ts-expect-error Thinks `uuid` shouldn't exist
        activeEffectData.origin = options.origin ?? activityEffects[aeIndex].uuid;
        // @ts-expect-error v14 effect.start
        activeEffectData.start = { time: game.time.worldTime };
        daeSystemClass.addDAEMetaData(activeEffectData, activity.item, options);
        activityEffects[aeIndex] = activeEffectData;
    }
    // Split up targets according to whether they are owned on not. Owned targets have effects applied locally, only unowned are passed ot the GM
    let targetList = Array.from(targets ?? []);
    targetList = targetList.map(t => (typeof t === "string") ? fromUuidSync(t)?.actor : t);
    targetList = targetList.map(t => (t instanceof foundry.canvas.placeables.Token) || (t instanceof TokenDocument) ? t.actor : t);
    targetList = targetList.filter(t => t instanceof Actor);
    let localTargets = targetList.filter(t => macroLocation === "local" || (t.isOwner && macroLocation === "mixed")).map(t => t.uuid);
    let gmTargets = targetList.filter(t => (!t.isOwner && macroLocation === "mixed") || macroLocation === "GM").map(t => t.uuid);
    debug("apply non-transfer effects: About to call gmaction ", activate, activityEffects, targets, localTargets, gmTargets);
    if (gmTargets.length > 0) {
        await socketlibSocket.executeAsGM("applyActiveEffects", { userId: game.user?.id, activate, activityUuid: activity.uuid, activeEffects: activityEffects, targetList: gmTargets, effectDuration: activity.duration, itemCardUuid: options.itemCardUuid, removeMatchLabel: options.removeMatchLabel, toggleEffect: options.toggleEffect, metaData: options.metaData });
    }
    if (localTargets.length > 0) {
        const result = await applyActiveEffects({ activate, activityUuid: activity.uuid, targetList: localTargets, activeEffects: activityEffects, effectDuration: activity.duration, itemCardUuid: options.itemCardUuid, removeMatchLabel: !!options.removeMatchLabel, toggleEffect: !!options.toggleEffect, metaData: options.metaData, origin: options.origin });
    }
}
// Apply non-transfer effects to targets.
// macro arguments are evaluated in the context of the actor applying to the targets
// @target is left unevaluated.
// request is passed to a GM client if the token is not owned
export async function applyNonTransferEffects(item, activate, targets, options = {
    critical: false,
    damageTotal: null,
    effectsToApply: [],
    fumble: false,
    itemCardUuid: null,
    removeMatchLabel: false,
    selfEffects: "none",
    spellLevel: 0,
    toggleEffect: false,
    tokenId: undefined,
    whisper: false,
}) {
    if (!targets)
        return;
    let macroLocation = "mixed";
    let appliedEffects = [];
    switch (options.selfEffects) {
        case "selfEffectsAlways":
            appliedEffects = item.effects.filter(ae => ae.transfer !== true && !isEnchantment(ae) && !!ae.flags?.dae?.selfTargetAlways).map(ae => {
                const data = ae.toObject(false);
                foundry.utils.setProperty(data, "flags.core.sourceId", ae.parent?.uuid);
                return data;
            });
            break;
        case "selfEffectsAll":
            appliedEffects = item.effects.filter(ae => ae.transfer !== true && !isEnchantment(ae) && !!(ae.flags?.dae?.selfTargetAlways || ae.flags?.dae?.selfTarget)).map(ae => {
                const data = ae.toObject(false);
                foundry.utils.setProperty(data, "flags.core.sourceId", ae.parent?.uuid);
                return data;
            });
            break;
        case "none":
        default:
            appliedEffects = item.effects.filter(ae => ae.transfer !== true && !isEnchantment(ae) && !ae.flags?.dae?.selfTargetAlways && !ae.flags?.dae?.selfTarget).map(ae => {
                const data = ae.toObject(false);
                foundry.utils.setProperty(data, "flags.core.sourceId", ae.parent?.uuid);
                return data;
            });
    }
    if (!options.applyAll)
        appliedEffects = appliedEffects.filter(aeData => aeData.flags?.dae?.dontApply !== true);
    else
        appliedEffects.forEach(aeData => foundry.utils.setProperty(aeData, "flags.dae.dontApply", false));
    if (options.effectsToApply?.length)
        appliedEffects = appliedEffects.filter(aeData => options.effectsToApply?.includes(aeData._id ?? ""));
    if (appliedEffects.length === 0)
        return;
    const rollData = item.getRollData(); //TODO if not caster eval move to evalArgs call
    // options.toggleEffect = item.flags?.midiProperties?.toggleEffect === true;
    for (let [aeIndex, activeEffectData] of appliedEffects.entries()) {
        // @ts-expect-error v14 system.changes on toObject() data
        for (let [changeIndex, change] of activeEffectData.system.changes.entries()) {
            const doRolls = allMacroEffects.includes(change.key);
            if (doRolls) {
                if (macroDestination[change.key] === "local" && macroLocation !== "GM") {
                    macroLocation = "local";
                }
                else if (macroDestination[change.key] === "GM")
                    macroLocation = "GM";
            }
            // eval args before calling GMAction so macro arguments are evaluated in the casting context.
            // Any @fields for macros are looked up in actor context and left unchanged otherwise
            rollData.stackCount = activeEffectData.flags?.dae?.stacks ?? 1;
            const evalArgsOptions = foundry.utils.mergeObject(options, {
                effectData: activeEffectData,
                change,
                doRolls
            });
            evalArgsOptions.context = foundry.utils.mergeObject(rollData, options.context ?? {}, { recursive: false });
            evalArgsOptions.item = item;
            if (item.actor)
                evalArgsOptions.actor = item.actor;
            let newChange = await evalArgs(evalArgsOptions);
            // @ts-expect-error v14 system.changes on toObject() data
            activeEffectData.system.changes[changeIndex] = newChange;
        }
        ;
        activeEffectData.origin = options.origin ?? item.uuid;
        // @ts-expect-error v14 effect.start
        activeEffectData.start = { time: game.time.worldTime };
        daeSystemClass.addDAEMetaData(activeEffectData, item, options);
        appliedEffects[aeIndex] = activeEffectData;
    }
    // Split up targets according to whether they are owned on not. Owned targets have effects applied locally, only unowned are passed ot the GM
    let targetList = Array.from(targets).map(t => (typeof t === "string")
        ? fromUuidSync(t)?.actor
        : (t instanceof Actor)
            ? t
            : t.actor).filter(t => t instanceof Actor);
    let localTargets = targetList.filter(t => macroLocation === "local" || (t.isOwner && macroLocation === "mixed")).map(t => t.uuid);
    let gmTargets = targetList.filter(t => (!t.isOwner && macroLocation === "mixed") || macroLocation === "GM").map(t => t.uuid);
    debug("apply non-transfer effects: About to call gmaction ", activate, appliedEffects, targets, localTargets, gmTargets);
    if (gmTargets.length > 0) {
        // @ts-expect-error no dnd5e-types
        await socketlibSocket.executeAsGM("applyActiveEffects", { userId: game.user?.id, activate, activeEffects: appliedEffects, targetList: gmTargets, effectDuration: item.system.duration, itemCardUuid: options.itemCardUuid, removeMatchLabel: options.removeMatchLabel, toggleEffect: options.toggleEffect, metaData: options.metaData });
    }
    if (localTargets.length > 0) {
        // @ts-expect-error no dnd5e-types
        await applyActiveEffects({ activate, targetList: localTargets, activeEffects: appliedEffects, effectDuration: item.system.duration, itemCardUuid: options.itemCardUuid, removeMatchLabel: options.removeMatchLabel, toggleEffect: options.toggleEffect, metaData: options.metaData, origin: options.origin });
    }
}
function preUpdateItemHook(candidate, updates, options, userId) {
    return true;
}
export function addEffectChange(actor, tokens, effectToApply, item, change, context) {
    if (debugEnabled > 0)
        warn("addEffectChange ", actor, change, tokens, effectToApply);
    const token = tokens[0];
    switch (change.key) {
        case "macro.CE":
            addConvenientEffectsChange(change.value, actor.uuid, effectToApply.origin, {}, actor.isToken);
            break;
        case "macro.StatusEffect":
        case "StatusEffect":
            if (CONFIG.ActiveEffect.legacyTransferral === false)
                addConditionChange(actor, change, token, effectToApply);
            break;
        case "macro.tokenMagic":
            addTokenMagicChange(actor, change, tokens);
            break;
        case "macro.createItem":
        case "macro.createItemRunMacro":
            if (!CONFIG.ActiveEffect.legacyTransferral) {
                addCreateItemChange(change, actor, effectToApply, context);
            }
            else {
                for (let effect of actor.allApplicableEffects()) {
                    if (effect.origin === item.uuid && effectIsTransfer(effect)) {
                        addCreateItemChange(change, actor, effect, context);
                    }
                }
            }
            break;
        default:
            if (change.key.startsWith("macro.execute") || change.key.startsWith("macro.itemMacro") || change.key.startsWith("macro.actorUpdate") || change.key.startsWith("macro.activityMacro")) {
                if (debugEnabled > 0)
                    warn("action queue add dae macro on ", actionQueue.remaining);
                actionQueue.add(daeMacro, "on", actor, effectToApply.toObject(false), { item, effectUuid: effectToApply.uuid });
                break;
            }
    }
}
export function removeEffectChange(actor, tokens, effectToApply, item, change, context) {
    let token = tokens[0];
    if (!token) {
        token = getToken(actor);
        tokens = token ? [token] : [];
    }
    switch (change.key) {
        case "macro.CE":
            removeConvenientEffectsChange(change.value, actor.uuid, effectToApply.origin, actor.isToken);
            break;
        case "macro.tokenMagic":
            removeTokenMagicChange(actor, change, tokens, context);
            break;
        case "macro.createItem":
        case "macro.createItemRunMacro":
            if (CONFIG.ActiveEffect.legacyTransferral === false) {
                // for non legacy transferral the only effect is the one on the actor
                removeCreateItemChange(change.value, actor, effectToApply, context);
            }
            else {
                for (let effect of actor.allApplicableEffects()) {
                    if ((effect.origin === item.uuid || effect.parent?.uuid === item.uuid) && effectIsTransfer(effect)) {
                        removeCreateItemChange(change.value, actor, effect, context);
                    }
                }
            }
            break;
        case "macro.StatusEffect":
        case "StatusEffect":
            if (CONFIG.ActiveEffect.legacyTransferral === false)
                removeConditionChange(actor, change, tokens[0], effectToApply, context);
            break;
        default:
            if (change.key.startsWith("macro.execute") || change.key.startsWith("macro.itemMacro") || change.key.startsWith("macro.actorUpdate") || change.key.startsWith("macro.activityMacro")) {
                if (debugEnabled > 0)
                    warn("dae add macro off", actionQueue.remaining);
                actionQueue.add(daeMacro, "off", actor, effectToApply.toObject(false), { item, origin: item.uuid, effectUuid: effectToApply.uuid, "expiry-reason": context["expiry-reason"] });
            }
            break;
    }
}
// Update the actor active effects when editing an owned item
function updateItemEffects(candidate, updates, options, userId) {
    if (!candidate.isOwned)
        return true;
    if (userId !== game.user?.id)
        return true;
    if (CONFIG.ActiveEffect.legacyTransferral === false) {
        return true;
    }
    // @ts-expect-error Can this happen?
    if (options.isUndo)
        return true;
    // if (updates.system?.equipped !== undefined || updates.system?.attuned !== undefined || updates.system?.attunement !== undefined) {
    // // equipped / attuned updated.
    // const isEnabled = (updates.system.equipped ?? candidate.system.equipped) && ((updates.system.attuned ?? candidate.system.attuned) || (updates.system?.attunment ?? candidate.system.attunment) !== "");
    // const effects = candidate.effects.filter(ef => !!(ef.transfer || ef.flags?.dae?.transfer))
    // }
    // @ts-expect-error Can this happen?
    if (options.isAdvancement) {
        console.warn(`dae | Skipping effect re-creation for class advancement ${candidate.parent?.name ?? ""} item ${candidate.name}`);
        return;
    }
    if (updates.effects) { // item effects have changed - update transferred effects
        const itemUuid = candidate.uuid;
        // delete all actor effects for the given item
        let deletions = [];
        for (let aef of (candidate.parent?.effects ?? [])) { // remove all transferred effects for the item
            const isTransfer = aef.flags.dae?.transfer;
            if (isTransfer && (aef.origin === itemUuid))
                deletions.push(aef.id);
        }
        ;
        // Now get all the item transfer effects
        let additions = candidate.effects.filter(aef => {
            const isTransfer = aef.transfer;
            foundry.utils.setProperty(aef, "flags.dae.transfer", isTransfer);
            return isTransfer;
        }).map(ef => ef.toObject(false));
        additions.forEach(efData => {
            efData.origin = itemUuid;
        });
        if (candidate.parent) {
            if (deletions.length > 0) {
                actionQueue.add(candidate.parent.deleteEmbeddedDocuments.bind(candidate.parent), "ActiveEffect", deletions);
            }
            if (additions.length > 0) {
                actionQueue.add(candidate.parent.createEmbeddedDocuments.bind(candidate.parent), "ActiveEffect", additions);
            }
        }
    }
    return true;
}
// Update the actor active effects when changing a transfer effect on an item
function updateTransferEffectsHook(candidate, updates, options, userId) {
    if (userId !== game.user?.id)
        return true;
    if (CONFIG.ActiveEffect.legacyTransferral === false) { // if not legacy transfer do nothing
        // TODO consider rewriting the origin for the effect
        return true;
    }
    // @ts-expect-error Can this happen?
    if (options.isUndo)
        return true;
    if (!(candidate.parent instanceof CONFIG.Item.documentClass))
        return true;
    const item = candidate.parent;
    if (!item.isOwned)
        return true;
    const actor = item.parent;
    // @ts-expect-error Can this happen?
    if (options.isAdvancement) {
        console.warn(`dae | Skipping effect re-creation for class advancement ${candidate.parent?.name ?? ""} item ${candidate.name}`);
        return;
    }
    const itemUuid = item.uuid;
    // delete all actor effects for the given item
    let deletions = [];
    for (let aef of (actor?.effects ?? [])) { // remove all transferred effects for the item
        const isTransfer = aef.flags.dae?.transfer;
        if (isTransfer && (aef.origin === itemUuid))
            deletions.push(aef.id);
    }
    ;
    // Now get all the item transfer effects
    let additions = item.effects.filter(aef => {
        const isTransfer = aef.transfer;
        foundry.utils.setProperty(aef, "flags.dae.transfer", isTransfer);
        return isTransfer;
    }).map(ef => ef.toObject(false));
    additions.forEach(efData => {
        efData.origin = itemUuid;
    });
    if (actor) {
        if (deletions.length > 0) {
            actionQueue.add(actor.deleteEmbeddedDocuments.bind(actor), "ActiveEffect", deletions);
        }
        if (additions.length > 0) {
            actionQueue.add(actor.createEmbeddedDocuments.bind(actor), "ActiveEffect", additions);
        }
    }
    return true;
}
// When an item is created any effects have a source that points to the original item
// Need to update to refer to the created item
// THe id in the this is not the final _id
// export function preCreateItemHook(candidate: Item.Implementation, data: Item.CreateData, options: Item.Database.PreCreateOptions, userId: string) {
//   if (options.isUndo) return true;
//   return true;
// }
export async function deleteItemHook(candidateItem, options, userId) {
    if (userId !== game.user?.id)
        return;
    // @ts-expect-error Can this happen?
    if (options.isUndo)
        return;
    if (CONFIG.ActiveEffect.legacyTransferral)
        return;
    const actor = candidateItem.parent;
    if (!(actor instanceof Actor))
        return;
    const token = tokenForActor(actor);
    for (let effect of candidateItem.effects) {
        if (!effect.transfer)
            continue;
        if (effect.disabled || effect.isSuppressed)
            continue;
        try {
            const selfAuraChange = foundry.utils.getProperty(effect, "flags.ActiveAuras.isAura") === true
                && foundry.utils.getProperty(effect, "flags.ActiveAuras.ignoreSelf") === true
                && effect.origin?.startsWith(actor.uuid);
            // don't apply macro or macro like effects if active aura and not targeting self
            if (selfAuraChange)
                return;
            // @ts-expect-error v14 effect.system.changes
            for (let change of effect.system.changes) {
                // @ts-expect-error Is this okay?
                options.itemDeleted = true;
                removeEffectChange(actor, token ? [token] : [], effect, candidateItem, change, options);
            }
        }
        catch (err) {
            console.warn("dae | error creating delete item hook", err);
        }
    }
    return;
}
export async function createItemHook(item, options, userId) {
    // @ts-expect-error Can this happen?
    if (options.isUndo)
        return;
    if (userId !== game.user?.id)
        return;
    const actor = item.parent;
    if (!(actor instanceof Actor))
        return;
    if (CONFIG.ActiveEffect.legacyTransferral)
        return;
    const token = tokenForActor(actor);
    for (let effect of item.effects) {
        if (!effect.transfer)
            continue;
        if (effect.disabled || effect.isSuppressed)
            continue;
        try {
            const selfAuraChange = foundry.utils.getProperty(effect, "flags.ActiveAuras.isAura") === true
                && foundry.utils.getProperty(effect, "flags.ActiveAuras.ignoreSelf") === true
                && effect.origin?.startsWith(actor.uuid);
            // don't apply macro or macro like effects if active aura and not targeting self
            if (selfAuraChange)
                return;
            // @ts-expect-error v14 effect.system.changes
            for (let change of effect.system.changes) {
                addEffectChange(actor, [token], effect, item, change, options);
            }
        }
        catch (err) {
            console.warn("dae | error creating active effect ", err);
        }
    }
    return;
}
// Process onUpdateTarget flags
export function preUpdateActorHook(candidate, updates, options, userId) {
    let result = true;
    try {
        // @ts-expect-error Can this happen?
        if (options.onUpdateCalled)
            return result = true;
        for (let onUpdate of (candidate.flags?.dae?.onUpdateTarget ?? [])) {
            if (onUpdate.macroName.length === 0)
                continue;
            if (onUpdate.filter.startsWith("data.")) {
                onUpdate.filter = onUpdate.filter.replace("data.", "system.");
            }
            if (foundry.utils.getProperty(updates, onUpdate.filter) === undefined)
                continue;
            const originObject = fromUuidSync(onUpdate.origin);
            const sourceTokenDocument = fromUuidSync(onUpdate.sourceTokenUuid);
            const targetTokenDocument = fromUuidSync(onUpdate.targetTokenUuid);
            const sourceActor = actorFromUuid(onUpdate.sourceActorUuid);
            const sourceToken = sourceTokenDocument?.object;
            const targetActor = targetTokenDocument?.actor;
            const targetToken = targetTokenDocument?.object;
            let originItem = (originObject instanceof Item) ? originObject : undefined;
            if (!originItem && originObject instanceof ActiveEffect)
                originItem = originObject.parent;
            if (!originItem) {
                const theEffect = targetActor?.appliedEffects.find(ef => ef.origin === onUpdate.origin);
                if (theEffect?.flags?.dae?.itemUuid) {
                    originItem = fromUuidSync(theEffect.flags.dae.itemUuid);
                }
            }
            let lastArg = {
                tag: "onUpdateTarget",
                effectId: null,
                origin: onUpdate.origin,
                efData: null,
                actorId: targetActor?.id,
                actorUuid: targetActor?.uuid,
                tokenId: targetToken?.id,
                tokenUuid: targetTokenDocument?.uuid,
                actor: candidate,
                updates,
                options,
                user: userId,
                userId,
                sourceActor,
                sourceToken,
                targetActor,
                targetToken,
                originItem,
                macroItem: originItem
            };
            let macroText;
            if (onUpdate.macroName.startsWith("ItemMacro")) { // TODO Come back and make sure this is tagged to the effect
                if (onUpdate.macroName === "ItemMacro") {
                    macroText = originItem?.flags?.dae?.macro?.command ?? originItem?.flags?.itemacro?.macro?.command;
                }
                else if (onUpdate.macroName.startsWith("ItemMacro.")) {
                    let macroObject = sourceActor?.items.getName(onUpdate.macroName.split(".")[1]);
                    const originActor = originObject?.parent instanceof Actor ? originObject.parent : originObject?.parent?.parent;
                    if (!macroObject)
                        macroObject = originActor?.items.getName(onUpdate.macroName.split(".")[1]);
                    if (macroObject)
                        macroText = macroObject.flags?.dae?.macro?.command ?? macroObject.flags?.itemacro?.macro?.command;
                }
            }
            else if (onUpdate.macroName.trim().startsWith("function.")) {
                macroText = `return await ${onUpdate.macroName.trim().replace("function.", "").trim()}(speaker, actor, token, character, scope)`;
            }
            else {
                const theMacro = game.macros?.getName(onUpdate.macroName);
                if (!theMacro) {
                    console.warn(`dae | onUpdateActor no macro found for actor ${candidate.name} macro ${onUpdate.macroName}`);
                    continue;
                }
                if (theMacro?.type === "chat") {
                    theMacro.execute(); // use the core foundry processing for chat macros
                    continue;
                }
                macroText = theMacro?.command;
            }
            try { // TODO make an actual macro and then call macro.execute....
                const speaker = ChatMessage.getSpeaker({ actor: candidate });
                const args = ["onUpdateActor"].concat(onUpdate.args);
                args.push(lastArg);
                const character = undefined; // game.user?.character;
                const scope = { args, lastArgValue: lastArg, item: originItem, macroItem: originItem };
                args.forEach(argString => {
                    if (typeof argString === "string") {
                        const parts = argString.split("=");
                        if (parts.length === 2) {
                            scope[parts[0]] = parts[1];
                        }
                    }
                });
                macroText = `try { ${macroText} } catch(err) { console.warn("dae | macro error", err) };`;
                const AsyncFunction = (async function () { }).constructor;
                const argNames = Object.keys(scope);
                const argValues = Object.values(scope);
                //@ts-expect-error for some reason
                const fn = new AsyncFunction("speaker", "actor", "token", "character", "item", "macroItem", "scope", ...argNames, macroText);
                fn.call(this, speaker, candidate, targetTokenDocument?.object, character, scope.item, scope.macroItem, scope, ...argValues);
            }
            catch (err) {
                ui.notifications?.error(`There was an error running your macro. See the console (F12) for details`);
                error("dae | Error evaluating macro for onUpdateActor", err);
            }
        }
    }
    catch (err) {
        console.warn("dae | error in onUpdateTarget ", err);
    }
    finally {
        return result;
        // return wrapped(updates, options, user);
    }
}
export function daeReadyActions() {
    DAEReadyComplete = true;
    // @ts-expect-error no typings for dfreds ce
    ceInterface = game.modules.get("dfreds-convenient-effects")?.active ? game.modules.get("dfreds-convenient-effects").api : undefined;
    ValidSpec.localizeSpecs();
    // initSheetTab();
    if (game.settings.get("dae", "disableEffects")) {
        ui.notifications?.warn("DAE effects disabled no DAE effect processing");
        console.warn("dae disabled - no active effects");
    }
    daeSystemClass.readyActions();
    // Process init macros that were deferred during prepareData before game.ready
    // Pass the live ActiveEffect (not .toObject()) so daeMacro resolves theItem
    // from effect.parent (the owned item) rather than following origin to a compendium.
    if (pendingInitMacroEffects.length > 0) {
        for (const { effectUuid, actorUuid } of pendingInitMacroEffects) {
            const effect = fromUuidSync(effectUuid);
            const actor = fromUuidSync(actorUuid);
            if (!effect || !actor)
                continue;
            actionQueue.add(daeMacro, "init", actor, effect, { effectUuid });
        }
        pendingInitMacroEffects.length = 0;
    }
    aboutTimeInstalled = game.modules.get("about-time")?.active ?? false;
    simpleCalendarInstalled = game.modules.get("foundryvtt-simple-calendar")?.active ?? false;
    timesUpActive = game.modules.get("times-up")?.active ?? false;
    // Provide human-readable labels for module flags (midi-qol, etc.) to dnd5e's
    // effect change display (PR #6820). Falls back to DAE's localizationMap which
    // modules populate via the DAE API.
    Hooks.on("dnd5e.getUnknownAttributeLabel", (attr, options) => {
        const entry = localizationMap[attr];
        if (entry?.name)
            options.label = entry.name;
    });
}
export let tokenizer;
Hooks.on("spotlightOmnisearch.indexBuilt", async (index) => {
    const fieldData = await foundry.utils.fetchJsonWithTimeout('modules/dae/data/field-data.json');
    const entries = Object.entries(fieldData).flatMap(([category, fields]) => Object.entries(fields).map(([key, { name, description }]) => ({
        key,
        name,
        description,
        category
    })));
    for (let entry of entries) {
        // @ts-expect-error no typings for spotlight omnisearch
        index.push(new CONFIG.SpotlightOmnisearch.SearchTerm({
            icon: ["fas fa-heart"],
            dragData: { fieldName: entry.key },
            name: entry.key,
            description: entry.description,
            query: "",
            keywords: ["dae", entry.category],
            type: "DAE attributes"
        }));
    }
});
export function daeInitActions() {
    atlActive = game.modules.get("ATL")?.active ?? false;
    midiActive = game.modules.get("midi-qol")?.active ?? false;
    useDetermineSuppression = game.system.id === "dnd5e" && foundry.utils.isNewerVersion("5.1", game.system.version);
    // Default system class is setup, this overrides with system specific class
    const dnd5System = DAESystemDND5E; // force reference so they are installed?
    libWrapper = globalThis.libWrapper;
    daeSystemClass = foundry.utils.getProperty(globalThis.daeSystems, game.system.id ?? "");
    daeSystemClass ??= CONFIG.DAE.systemClass;
    daeSystemClass.initActions();
    daeSystemClass.initSystemData();
    if (game.settings.get("dae", "disableEffects")) {
        ui.notifications?.warn("DAE effects disabled no DAE effect processing");
        console.warn("dae | All active effects disabled.");
        return;
    }
    // Augment actor get rollData with actorUuid, actorId, tokenId, tokenUuid
    libWrapper.register("dae", "CONFIG.Actor.documentClass.prototype.getRollData", daeSystemClass.getRollDataFunc(), "MIXED");
    // libWrapper.register("dae", "CONFIG.Token.objectClass.prototype.drawEffects", drawEffects, "WRAPPER")
    // libWrapper.register("dae", "CONFIG.Actor.documentClass.prototype.applyActiveEffects", applyBaseActiveEffects, "OVERRIDE");
    // If updating item effects recreate actor effects for updated item.
    Hooks.on("updateItem", updateItemEffects);
    Hooks.on("preUpdateItem", preUpdateItemHook);
    Hooks.on("createItem", createItemHook);
    Hooks.on("deleteItem", deleteItemHook);
    // libWrapper.register("dae", "CONFIG.Actor.documentClass.prototype._preUpdate", preUpdateActor, "WRAPPER");
    // libWrapper.register("dae", "CONFIG.Item.documentClass.prototype._preCreate", _preCreateItem, "WRAPPER");
    // process onUpdateTarget flags
    Hooks.on("preUpdateActor", preUpdateActorHook);
    // Hooks for conditional effects
    Hooks.on("updateActor", processConditionalEffects);
    Hooks.on("updateToken", (tokenDocument, updates) => {
        if (updates.x || updates.y)
            processConditionalEffects(tokenDocument.actor, updates);
    });
    Hooks.on("updateItem", (item, updates) => {
        if (item.parent instanceof Actor)
            processConditionalEffects(item.parent, updates);
    });
    Hooks.on("createActiveEffect", (effect, options, userId) => {
        if (game.user !== game.users?.activeGM)
            return;
        if (effect.parent instanceof Actor) {
            processConditionalEffects(effect.parent, {});
        }
        else if (effect.transfer) {
            const item = effect.parent;
            const actor = item?.parent;
            if (actor)
                processConditionalEffects(actor, {});
        }
    });
    Hooks.on("updateActiveEffect", (effect, updates) => {
        if (game.user !== game.users?.activeGM)
            return;
        if (effect.parent instanceof Actor) {
            processConditionalEffects(effect.parent, updates);
        }
        else if (effect.transfer) {
            const item = effect.parent;
            const actor = item?.parent;
            if (actor)
                processConditionalEffects(actor, updates);
        }
    });
    Hooks.on("deleteActiveEffect", (effect) => {
        if (game.user !== game.users?.activeGM)
            return;
        if (effect.parent instanceof Actor) {
            processConditionalEffects(effect.parent, {});
        }
        else if (effect.transfer) {
            const item = effect.parent;
            const actor = item?.parent;
            if (actor)
                processConditionalEffects(actor, {});
        }
    });
    libWrapper.register("dae", "CONFIG.ActiveEffect.documentClass.prototype._preCreate", _preCreateActiveEffect, "MIXED");
    async function _preCreateActiveEffect(wrapped, data, context, user) {
        // Migrate deprecated flags.dae.showIcon to native showIcon field
        if (this.flags?.dae?.showIcon) {
            console.error(`dae | Effect "${this.name}" uses deprecated flags.dae.showIcon. Edit the effect to migrate to the native showIcon field.`);
        }
        let result = await _preCreateActiveEffectRemoveExisting.bind(this)(data, context, user);
        if (result)
            result = await _preCreateActiveEffectIncrement.bind(this)(data, context, user);
        await _preCreateEnchantmentEffect.bind(this)(data, context, user);
        // @ts-expect-error no dnd5e-types
        if (this.active && this.type !== "enchantment" && dependentConditions /* && !this.flags?.dae?.autoCreated */) {
            await daeSystemClass.preCreateActiveEffect(this);
            if (debugEnabled > 0)
                warn("_preCreateActiveEffect", this, context);
            // Status effect reconciliation now handled via queueStatusReconciliation hook
        }
        if (result)
            result = await wrapped(data, context, user);
        return result;
    }
    // The below seems to work, but may just be good luck since the timing is "random"
    // Hooks.on("createActiveEffect", applyRequiredStatusEffectsHook);
    libWrapper.register("dae", "CONFIG.ActiveEffect.documentClass.prototype._preDelete", _preDeleteActiveEffect, "MIXED");
    async function _preDeleteActiveEffect(wrapped, options, user) {
        let result = await _preDeleteActiveEffectDecrement.bind(this)(options, user);
        if (this.active && dependentConditions && result) { // took this out 12.0.22 && !this.flags?.dae?.autoCreated)
            if (debugEnabled > 0)
                warn("_preDeleteActiveEffect", this, options);
            // Status effect reconciliation now handled via queueStatusReconciliation hook
        }
        if (result)
            result = wrapped(options, user);
        return result;
    }
    libWrapper.register("dae", "CONFIG.ActiveEffect.documentClass.prototype._preUpdate", _preUpdateActiveEffect, "MIXED");
    async function _preUpdateActiveEffect(wrapped, ...args) {
        const [changed, options, userId] = args;
        if (dependentConditions) {
            let shouldInclude = this.active;
            if (this.parent instanceof Item && !this.transfer)
                shouldInclude = false;
            // If the effect is active only process changes if the statuses of the effect changed
            const changedStatuses = new Set(changed.statuses);
            const statusesChanged = this.statuses.difference(changedStatuses).size > 0 && this.statuses.size !== changedStatuses.size;
            if (shouldInclude && (statusesChanged || changed.disabled !== undefined || changed.isSuppressed !== undefined)) {
                if (debugEnabled > 0)
                    warn("preUpdateActiveEffect ", this, changed, options);
                // Status effect reconciliation now handled via queueStatusReconciliation hook
            }
        }
        return wrapped(...args);
    }
    Hooks.on("createActiveEffect", createActiveEffectHook);
    Hooks.on("updateItem", (item, data, options, userId) => updateStatusEffects(item, options, userId));
    Hooks.on("deleteItem", (item, options, userId) => updateStatusEffects(item, options, userId));
    Hooks.on("createItem", (item, options, userId) => updateStatusEffects(item, options, userId));
    Hooks.on("deleteActiveEffect", deleteActiveEffectHook);
    //  Hooks.on("preDeleteActiveEffect", preDeleteActiveEffectHook); - moved wrapper to avoid race conditions
    Hooks.on("preUpdateActiveEffect", preUpdateActiveEffectEvalInlineHook);
    Hooks.on("preUpdateActiveEffect", recordDisabledSuppressedHook);
    Hooks.on("updateActiveEffect", updateActiveEffectHook);
    Hooks.on("updateActiveEffect", updateTransferEffectsHook);
    // Queue status reconciliation after effect changes complete
    Hooks.on("createActiveEffect", (effect, options, userId) => {
        queueStatusesReconciliation(effect, userId);
    });
    Hooks.on("deleteActiveEffect", (effect, options, userId) => {
        queueStatusesReconciliation(effect, userId);
    });
    Hooks.on("updateActiveEffect", (effect, data, options, userId) => {
        queueStatusesReconciliation(effect, userId);
    });
    // Add the active effects title bar actions
    Hooks.on("getHeaderControlsItemSheet5e", appendDocumentSheetHeaderControls);
    Hooks.on("getHeaderControlsActorSheetV2", appendDocumentSheetHeaderControls);
    Hooks.on("renderItemSheetV2", colorSheetHeaderButtons); // tidy5e item sheets
    Hooks.on("renderItemSheet5e", colorSheetHeaderButtons); // dnd5e item sheets
    Hooks.on("renderActorSheetV2", colorSheetHeaderButtons);
    Hooks.on("renderActorSheetV2", injectDeleteExpiredButton);
    setupSpecialDurationHooks();
    //@ts-expect-error no typings for this (can we maybe ditch in favor of our own tokenization?)
    tokenizer = new DETokenizeThis({
        shouldTokenize: ['(', ')', ',', '*', '/', '%', '+', '===', '==', '!=', '!', '<', '> ', '<=', '>=', '^']
    });
    actionQueue = new foundry.utils.Semaphore();
}
function updateStatusEffects(doc, options, userId) {
    if (!dependentConditions)
        return;
    if (userId !== game.user?.id)
        return;
    let actor = doc;
    if (doc instanceof Item || doc instanceof ActiveEffect) {
        actor = doc.parent;
    }
    if (actor instanceof Item) {
        actor = actor.parent;
    }
    if (!(actor instanceof Actor))
        return;
    if (!reconciliationPending.has(actor.uuid)) {
        reconciliationPending.add(actor.uuid);
        actionQueue.add(async () => {
            try {
                reconciliationPending.delete(actor.uuid);
                await reconcileActorStatuses(actor);
            }
            catch (err) {
                console.warn("dae | Error reconciling actor statuses (item change):", err);
            }
        });
    }
}
/**
 * Queue a status reconciliation for an actor after effect changes complete.
 * Uses the actionQueue semaphore to serialize reconciliations and avoid race conditions.
 */
function queueStatusesReconciliation(effect, userId) {
    if (!dependentConditions)
        return;
    if (userId !== game.user?.id)
        return;
    // Reconcile if the effect has statuses OR if it has condition immunity changes
    // (toggling a CI effect needs to create/remove auto-created status documents)
    const hasStatuses = !!effect.statuses?.size;
    // @ts-expect-error v14 effect.system.changes
    const hasCIChanges = effect.system?.changes?.some(c => c.key.startsWith("system.traits.ci"));
    if (!hasStatuses && !hasCIChanges)
        return;
    const actor = effect.parent instanceof Actor ? effect.parent : effect.parent?.parent;
    if (!(actor instanceof Actor))
        return;
    if (!reconciliationPending.has(actor.uuid)) {
        reconciliationPending.add(actor.uuid);
        actionQueue.add(async () => {
            try {
                reconciliationPending.delete(actor.uuid);
                await reconcileActorStatuses(actor);
            }
            catch (err) {
                console.warn("dae | Error reconciling actor statuses:", err);
            }
        });
    }
}
/**
 * Reconcile the status effects on an actor based on all active effects.
 * This calculates what statuses SHOULD exist based on current effects,
 * then adds missing statuses and removes extra ones.
 *
 * Status effect documents use static _ids (e.g., staticID("dnd5eparalyzed")).
 * The dnd5e character sheet determines active conditions by checking for these
 * documents, not actor.statuses. So reconciliation must create/remove the
 * actual documents to keep the sheet in sync.
 */
async function reconcileActorStatuses(actor) {
    if (!dependentConditions)
        return;
    if (debugEnabled > 0)
        warn("reconcileActorStatuses", actor.name);
    const excludedStatuses = ["concentrating", "bonusaction", "reaction", "encumbered", "heavilyEncumbered", "exceedingCarryingCapacity"];
    // Calculate expected statuses from all active effects
    // Skip status effect documents with static _ids (those are the output, not the input)
    let expectedStatuses = new Set();
    const existingStaticStatusIds = new Set(); // Track which static-_id status effect documents exist
    const autoCreatedStaticStatusIds = new Set(); // Track which were created by DAE (vs manually by user)
    for (let effect of actor.allApplicableEffects()) {
        if (effect.flags?.["dfreds-convenient-effects"])
            continue;
        // @ts-expect-error determineSuppression may not exist
        if (effect.transfer && effect.parent instanceof Item && useDetermineSuppression)
            effect.determineSuppression?.();
        // Check if this effect has a static _id matching a CONFIG status effect.
        // These are status effect documents (created by toggleStatusEffect, fromStatusEffect,
        // or by this reconciliation). They are the OUTPUT of reconciliation, not input.
        // Track these REGARDLESS of active state — an inactive (disabled/suppressed) static-id
        // document still needs to be removed if the actor is immune to that condition.
        const configStatusEffect = getStatusEffectsArray().find(se => se._id === effect.id);
        if (configStatusEffect) {
            existingStaticStatusIds.add(configStatusEffect.id);
            if (effect.flags?.dae?.autoCreated) {
                autoCreatedStaticStatusIds.add(configStatusEffect.id);
            }
            // Only count sub-statuses from ACTIVE static-id effects as expected
            if (effect.active) {
                for (const status of effect.statuses) {
                    if (status !== configStatusEffect.id) {
                        expectedStatuses.add(status);
                    }
                }
            }
            continue; // Don't add all statuses via the union below
        }
        if (!effect.active)
            continue;
        expectedStatuses = expectedStatuses.union(effect.statuses);
    }
    // Filter out statuses we don't manage
    for (const status of excludedStatuses) {
        expectedStatuses.delete(status);
    }
    // Filter out statuses the actor is immune to
    // @ts-expect-error no dnd5e-types
    const conditionImmunities = actor.system.traits?.ci?.value;
    if (conditionImmunities) {
        for (const condition of conditionImmunities) {
            expectedStatuses.delete(condition);
        }
    }
    // Add status effect documents that should exist but don't
    for (let status of expectedStatuses) {
        if (existingStaticStatusIds.has(status))
            continue;
        const statusEffect = getStatusEffectsArray().find(se => se.id === status);
        if (!statusEffect)
            continue;
        if (!statusEffect._id)
            continue;
        if (statusEffect.statuses?.includes(status))
            continue; // Self referential
        try {
            await toggleActorStatusEffect(actor, status, { active: true, flags: { dae: { autoCreated: true } } });
        }
        catch (err) {
            if (!String(err).includes("does not exist")) {
                console.warn("dae | Error adding status effect:", status, err);
            }
        }
    }
    // Remove status effect documents that should not exist
    // Only remove auto-created documents (created by DAE reconciliation), not ones
    // manually applied by the user from the character sheet
    // Exception: CI overrides even manual statuses
    for (let statusEffectId of existingStaticStatusIds) {
        if (expectedStatuses.has(statusEffectId))
            continue;
        if (!autoCreatedStaticStatusIds.has(statusEffectId) && !conditionImmunities?.has(statusEffectId))
            continue;
        const statusEffect = getStatusEffectsArray().find(se => se.id === statusEffectId);
        if (!statusEffect)
            continue;
        if (!statusEffect._id)
            continue;
        try {
            await toggleActorStatusEffect(actor, statusEffectId, { active: false });
        }
        catch (err) {
            if (!String(err).includes("does not exist")) {
                console.warn("dae | Error removing status effect:", statusEffectId, err);
            }
        }
    }
}
Hooks.once("tidy5e-sheet.ready", api => {
    api.registerItemHeaderControls?.({
        controls: [
            {
                icon: 'fas fa-wrench',
                label: "DAE",
                async onClickAction() {
                    new ActiveEffects({ document: this.document }).render({ force: true });
                }
            },
            {
                icon: 'fas fa-file-pen',
                label: "DIME",
                async onClickAction() {
                    new DIMEditor({ document: this.document }).render({ force: true });
                }
            }
        ]
    });
    /* enable this when available
    api.registerActivityHeaderControls?.({
      controls: [
        {
          icon: 'fas fa-file-pen',
          label: "DIME",
          async onClickAction() {
            new DIMEditor({ document: this.document }).render({ force: true });
          }
        }
      ]
    });
    */
});
function appendDocumentSheetHeaderControls(app, controls) {
    const daeTitle = i18n("dae.ActiveEffectName");
    const DIMETitle = i18n("dae.DIMEditor.Name");
    if (daeTitleBar) {
        controls.push({
            label: daeTitle,
            icon: "fa-solid fa-wrench",
            action: "dae-effects",
            onClick: () => new ActiveEffects({ document: app.document }).render({ force: true })
        });
    }
    if (DIMETitleBar && app.document instanceof Item) {
        controls.push({
            label: DIMETitle,
            icon: "fa-solid fa-file-pen",
            action: "dae-dime",
            onClick: () => new DIMEditor({ document: app.document }).render({ force: true })
        });
    }
    // Color icons in the dnd5e context menu (nav#context-menu).
    // dnd5e replaces the standard Foundry .controls-dropdown with a ContextMenu5e,
    // and getHeaderControls fires when that context menu opens.
    // Use setTimeout so the context menu DOM has been built.
    if (!daeColorTitleBar)
        return;
    const doc = app.document;
    if (!doc)
        return;
    const green = "#36ba36";
    let hasEffects = false;
    let hasMacro = false;
    if (daeTitleBar) {
        if (doc instanceof Actor)
            hasEffects = doc.allApplicableEffects().next().value !== undefined;
        else
            hasEffects = doc.effects?.size > 0;
    }
    if (DIMETitleBar && doc instanceof Item) {
        const validMacroFlags = ["flags.dae.macro.command", "flags.itemacro.macro.command", "flags.itemacro.macro.data.command"];
        hasMacro = validMacroFlags.some(f => foundry.utils.getProperty(doc, f));
    }
    if (!hasEffects && !hasMacro)
        return;
    setTimeout(() => {
        const contextItems = document.querySelectorAll("nav#context-menu .context-item");
        contextItems.forEach(item => {
            const label = item.textContent?.trim() ?? "";
            const icon = item.querySelector("i");
            if (!icon)
                return;
            if (hasEffects && label.includes(daeTitle)) {
                icon.style.color = green;
            }
            if (hasMacro && label.includes(DIMETitle)) {
                icon.style.color = green;
            }
        });
    });
}
// Inject global CSS rules once for DAE/DIME icon coloring.
// Color tidy5e header buttons on render (tidy5e puts buttons directly in .window-header)
function colorSheetHeaderButtons(app, _element) {
    if (!daeColorTitleBar)
        return;
    const appElement = app.element;
    if (!appElement)
        return;
    const doc = app.document;
    if (!doc)
        return;
    const green = "#36ba36";
    if (daeTitleBar) {
        let hasEffects = false;
        if (doc instanceof Actor)
            hasEffects = doc.allApplicableEffects().next().value !== undefined;
        else
            hasEffects = doc.effects?.size > 0;
        if (hasEffects) {
            const tidyWrench = appElement.querySelector(".window-header .header-control.fa-wrench");
            if (tidyWrench)
                tidyWrench.style.color = green;
        }
    }
    if (DIMETitleBar && doc instanceof Item) {
        const validMacroFlags = ["flags.dae.macro.command", "flags.itemacro.macro.command", "flags.itemacro.macro.data.command"];
        const hasMacro = validMacroFlags.some(f => foundry.utils.getProperty(doc, f));
        if (hasMacro) {
            const tidyFilePen = appElement.querySelector(".window-header .header-control.fa-file-pen");
            if (tidyFilePen)
                tidyFilePen.style.color = green;
        }
    }
}
function injectDeleteExpiredButton(app, _element) {
    const actor = app.document;
    if (!(actor instanceof Actor))
        return;
    const appElement = app.element;
    if (!appElement)
        return;
    // Find the suppressed effects section header
    const suppressedSection = appElement.querySelector('.items-section[data-effect-type="suppressed"]');
    if (!suppressedSection)
        return;
    const header = suppressedSection.querySelector('.items-header');
    if (!header)
        return;
    // Don't add duplicate buttons
    if (header.querySelector('[data-action="deleteExpiredEffects"]'))
        return;
    const controlsDiv = header.querySelector('.item-controls, .effect-controls') ?? header;
    const btn = document.createElement("a");
    btn.classList.add("effect-control", "item-control");
    btn.dataset.action = "deleteExpiredEffects";
    btn.dataset.tooltip = i18n("dae.deleteExpiredEffects");
    btn.setAttribute("aria-label", i18n("dae.deleteExpiredEffects"));
    btn.style.color = "var(--color-text-primary, #191813)";
    btn.innerHTML = '<i class="fas fa-trash-can"></i>';
    btn.addEventListener("click", async (event) => {
        event.preventDefault();
        event.stopPropagation();
        const expiredEffects = [];
        for (const effect of actor.allApplicableEffects()) {
            // @ts-expect-error expired not in fvtt-types _source schema
            if (effect.duration?.expired || effect._source?.duration?.expired) {
                if (effect.id)
                    expiredEffects.push(effect.id);
            }
        }
        if (expiredEffects.length === 0)
            return;
        await actor.deleteEmbeddedDocuments("ActiveEffect", expiredEffects);
    });
    controlsDiv.prepend(btn);
}
export function daeSetupActions() {
    daeSystemClass.setupActions();
}
export let maxShortDuration;
export function fetchParams() {
    setDebugLevel(game.settings.get("dae", "ZZDebug"));
    // useAbilitySave = game.settings.get("dae", "useAbilitySave") disabled as of 0.8.74
    noDupDamageMacro = game.settings.get("dae", "noDupDamageMacro");
    disableEffects = game.settings.get("dae", "disableEffects");
    daeTitleBar = game.settings.get("dae", "DAETitleBar");
    DIMETitleBar = game.settings.get("dae", "DIMETitleBar");
    daeColorTitleBar = game.settings.get("dae", "DAEColorTitleBar");
    daeNoTitleText = game.settings.get("dae", "DAENoTitleText");
    // showDeprecation = game.settings.get("dae", "showDeprecation") ?? true;
    showInline = game.settings.get("dae", "showInline") ?? false;
    dependentConditions = game.settings.get("dae", "DependentConditions") ?? false;
    maxShortDuration = game.settings.get("dae", "maxShortDuration") ?? 600;
    specialDurationExpiryAction = game.settings.get("dae", "expiryAction") ?? "default";
    fetchDurationParams();
    Hooks.callAll("dae.settingsChanged");
}
export function getTokenDocument(tokenRef) {
    if (typeof tokenRef === "string") {
        const entity = fromUuidSync(tokenRef);
        if (entity instanceof TokenDocument)
            return entity;
        if (entity instanceof foundry.canvas.placeables.Token)
            return entity.document;
        if (entity instanceof Actor) {
            if (entity.isToken)
                return entity.token ?? undefined;
            else
                return entity.getActiveTokens(false, true)[0];
        }
        return undefined;
    }
    if (tokenRef instanceof TokenDocument)
        return tokenRef;
    if (tokenRef instanceof foundry.canvas.placeables.Token)
        return tokenRef.document;
    if (tokenRef instanceof Actor) {
        // actor.token returns a token document
        if (tokenRef.isToken)
            return tokenRef.token ?? undefined;
        else
            return tokenRef.getActiveTokens(false, true)[0];
    }
}
export function getToken(tokenRef) {
    if (!tokenRef)
        return undefined;
    if (tokenRef instanceof foundry.canvas.placeables.Token)
        return tokenRef;
    if (tokenRef instanceof TokenDocument)
        return tokenRef.object ?? undefined;
    let entity = tokenRef;
    if (typeof tokenRef === "string") {
        entity = fromUuidSync(tokenRef);
    }
    if (entity instanceof foundry.canvas.placeables.Token)
        return entity;
    if (entity instanceof TokenDocument)
        return entity.object ?? undefined;
    if (entity instanceof Actor)
        return tokenForActor(entity);
    if (entity instanceof Item && entity.parent instanceof Actor)
        return tokenForActor(entity.parent);
    if (entity instanceof ActiveEffect && entity.parent instanceof Actor)
        return tokenForActor(entity.parent);
    if (entity instanceof ActiveEffect && entity.parent instanceof Item)
        return tokenForActor(entity.parent?.parent);
    return undefined;
}
export function actorFromUuid(uuid) {
    let doc = fromUuidSync(uuid);
    if (doc instanceof CONFIG.Token.documentClass)
        doc = doc.actor;
    if (doc instanceof CONFIG.Actor.documentClass)
        return doc;
    if (doc instanceof CONFIG.Item.documentClass)
        return doc.parent;
    return null;
}
// Allow limited recursion of the formula replace function for things like
// bonuses.heal.damage in spell formulas.
export function replaceFormulaData(wrapped, formula, data = {}, { missing, warn = false } = { missing: undefined, warn: false }) {
    let result = formula;
    const maxIterations = 3;
    data.Embed = "@Embed"; // Never replace these
    if (typeof formula !== "string")
        return formula;
    for (let i = 0; i < maxIterations; i++) {
        if (!result.includes("@"))
            break;
        try {
            result = wrapped(result, data, { missing, warn });
        }
        catch (err) {
            error(err, formula, data, missing, warn);
        }
    }
    return result;
}
export function tokensForActor(actorRef) {
    let actor;
    if (!actorRef)
        return undefined;
    if (typeof actorRef === "string")
        actor = fromUuidSync(actorRef);
    else
        actor = actorRef;
    if (actor.token)
        return [actor.token.object];
    if (!(actor instanceof Actor))
        return undefined;
    const tokens = actor.getActiveTokens();
    if (!tokens.length)
        return undefined;
    const controlled = tokens.filter(t => t.controlled);
    return controlled.length ? controlled : tokens;
}
export function tokenForActor(actor) {
    const tokens = tokensForActor(actor);
    if (!tokens)
        return undefined;
    return tokens[0];
}
export function effectIsTransfer(effect) {
    if (CONFIG.ActiveEffect.legacyTransferral === false)
        return effect.transfer === true;
    if (effect.flags.dae?.transfer !== undefined)
        return effect.flags.dae.transfer;
    if (effect.transfer !== undefined)
        return effect.transfer;
    return false;
}
export async function delay(interval) {
    await new Promise(resolve => setTimeout(resolve, interval));
}
export function safeGetGameSetting(moduleName, settingName) {
    // @ts-expect-error too generic to type
    if (game.settings.settings.get(`${moduleName}.${settingName}`))
        return game.settings.get(moduleName, settingName);
    else
        return undefined;
}
export function getApplicableEffects(actor, { includeEnchantments, includeExpired = false }) {
    if (!actor)
        return [];
    let effects = [];
    for (let effect of actor.allApplicableEffects()) {
        if (!includeExpired && effect.duration?.expired)
            continue;
        effects.push(effect);
    }
    if (includeEnchantments) {
        const enchantments = actor.items.contents.flatMap(i => i.effects.contents).filter(ae => {
            if (!ae.isAppliedEnchantment)
                return false;
            if (!includeExpired && ae.duration?.expired)
                return false;
            return true;
        });
        effects = effects.concat(enchantments);
    }
    return effects;
}
// This does not work since the hook is called after _preCreateEffect is called which leads to the update source firing too late
export async function toggleActorStatusEffectPossible(actor, statusId, { active = false, overlay = false, enableCondition = "", origin = "", flags = {} } = {}) {
    let preCreateActiveEffectHookId;
    try {
        const statusEffect = getStatusEffectsArray().find(e => e.id === statusId);
        preCreateActiveEffectHookId = Hooks.on("preCreateActiveEffect", (effect, data, options, userId) => {
            if (effect._id !== statusEffect?._id)
                return;
            if (origin)
                effect.updateSource({ origin });
            if (enableCondition?.length)
                effect.updateSource({ "flags.dae.enableCondition": enableCondition });
            if (overlay)
                effect.updateSource({ "flags.core.overlay": true });
            flags = foundry.utils.mergeObject(effect.flags ?? {}, flags ?? {}, { inplace: false });
            effect.updateSource({ flags });
        });
        return await actor.toggleStatusEffect(statusId, { active, overlay });
    }
    finally {
        if (preCreateActiveEffectHookId)
            Hooks.off("preCreateActiveEffect", preCreateActiveEffectHookId);
    }
}
// TODO can't use the core toggleActorStatusEffect, consider patching this to replace the core one
export async function toggleActorStatusEffect(actor, statusId, { active = false, overlay = false, enableCondition = "", origin = "", flags = {} } = {}) {
    if (debugEnabled > 0)
        warn("toggleActorStatusEffect", actor, statusId, active);
    const status = getStatusEffectsArray().find(e => e.id === statusId);
    if (!status)
        throw new Error(`Invalid status ID "${statusId}" provided to Actor#toggleStatusEffect`);
    let existing = [];
    // Find the effect with the static _id of the status effect
    if (status._id) {
        const effect = actor.effects.get(status._id);
        if (effect?.id)
            existing.push(effect);
    }
    // If no static _id, find all single-status effects that have actor status
    else {
        for (const effect of actor.effects) {
            const statuses = effect.statuses;
            if ((statuses.size === 1) && statuses.has(status.id))
                existing.push(effect);
        }
    }
    // Remove the existing effects unless the status effect is forced active
    if (existing.length) {
        if (active) {
            return true;
        }
        await actor.deleteEmbeddedDocuments("ActiveEffect", existing.map(e => e.id));
        return false;
    }
    // Create a new effect unless the status effect is forced inactive
    if (!active && active !== undefined)
        return false;
    const effect = await ActiveEffect.implementation.fromStatusEffect(statusId);
    if (origin)
        effect.updateSource({ origin });
    if (enableCondition?.length)
        effect.updateSource({ flags: { dae: { enableCondition: enableCondition } } });
    if (overlay)
        effect.updateSource({ flags: { core: { overlay: true } } });
    flags = foundry.utils.mergeObject(effect.flags ?? {}, flags ?? {}, { inplace: false });
    effect.updateSource({ flags });
    const returnEffect = await ActiveEffect.implementation.create(effect.toObject(), { parent: actor, keepId: true });
    return returnEffect ? [returnEffect] : false;
}
export async function processConditionalEffects(actor, updates) {
    if (!game.users?.activeGM?.isSelf)
        return;
    if (!actor || !["character", "npc"].includes(actor.type))
        return;
    const tokenDocument = tokenForActor(actor)?.document;
    const token = tokenDocument?.object;
    // while (token?.animationContexts?.get(token.animationName)?.to) await delay(100);
    // @ts-expect-error missing in fvtt-types currently
    await token?.movementAnimationPromise;
    const rollData = actor.getRollData();
    const effectItem = game.items?.getName(i18n("dae.ConditionalEffectsItem"));
    if (effectItem) {
        for (let conditionalEffect of effectItem.effects) {
            let enableCondition = conditionalEffect.flags?.dae?.enableCondition;
            if (!enableCondition || conditionalEffect.disabled)
                continue;
            const ceData = conditionalEffect.toObject(false);
            const expression = Roll.replaceFormulaData(enableCondition, rollData);
            const result = daeSystemClass.safeEval(expression, rollData);
            if (!result)
                continue;
            let overlay = ceData.flags.core?.overlay ?? false;
            const statusEffects = new Set();
            // @ts-expect-error v14 system.changes on toObject() data
            for (let change of ceData.system.changes) {
                if (daeSystemClass.fieldMappings[change.key]) {
                    const mapping = daeSystemClass.fieldMappings[change.key];
                    if (typeof mapping === "string") {
                        change.key = mapping;
                    }
                    else {
                        change.key = mapping.key;
                        if (mapping.value !== undefined)
                            change.value = mapping.value;
                        if (mapping.type !== undefined)
                            change.type = mapping.type;
                        else if (mapping.mode !== undefined) {
                            // Legacy field mapping with numeric mode -- convert to v14 string type
                            const modeToType = { 0: "custom", 1: "multiply", 2: "add", 3: "downgrade", 4: "upgrade", 5: "override" };
                            change.type = modeToType[mapping.mode] ?? "custom";
                        }
                    }
                }
            }
            // @ts-expect-error v14 system.changes on toObject() data
            ceData.system.changes = ceData.system.changes
                .filter(change => change.key !== "StatusEffect" || change.value.startsWith("zce-"));
            for (let status of ceData.statuses) {
                statusEffects.add(status);
            }
            const existingEffect = actor.effects.find(ef => ef.origin === conditionalEffect.uuid);
            if (!existingEffect || ["countDeleteDecrement", "count", "multi"].includes(ceData.flags?.dae?.stackable ?? "")) {
                for (let statusEffect of statusEffects) {
                    // Once v12 only change to actor.toggleStatusEffect
                    await toggleActorStatusEffect(actor, statusEffect, { active: true, overlay, origin: conditionalEffect.uuid, enableCondition: enableCondition });
                }
                // @ts-expect-error v14 system.changes on toObject() data
                if (ceData.system.changes.length > 0 || statusEffects.size === 0) {
                    if (actor.effects.some(ef => ef.id === ceData._id))
                        continue;
                    ceData.origin = conditionalEffect.uuid;
                    if (debugEnabled > 0)
                        warn(`dae | creating conditional effect on ${actor.name} ${actor.uuid}`, ceData);
                    await actor.createEmbeddedDocuments("ActiveEffect", [ceData]);
                }
            }
        }
    }
    for (let effect of actor.effects) {
        let condition = effect?.flags?.dae?.enableCondition;
        if (condition) {
            // add other things to rollData
            rollData.combat = game.combat;
            rollData.time = game.time;
            rollData.effect = effect.toObject();
            const expression = Roll.replaceFormulaData(condition, rollData);
            // rollData.origin = fromUuidSync(effect.origin);
            const result = daeSystemClass.safeEval(expression, rollData);
            if (!result) {
                await actor.deleteEmbeddedDocuments("ActiveEffect", [effect.id]);
            }
        }
    }
    for (let effect of actor.allApplicableEffects()) {
        const disableCondition = foundry.utils.getProperty(effect, "flags.dae.disableCondition");
        if (typeof disableCondition === "string" && disableCondition.trim() !== "") {
            const rollData = (effect.parent?.getRollData() ?? {});
            rollData.effect = effect.toObject();
            let value = Roll.replaceFormulaData(disableCondition, rollData, { missing: "0", warn: false });
            try { // Roll parser no longer accepts some expressions it used to so we will try and avoid using it
                let disabled;
                if (value.includes("dae.eval(") || value.includes("dae.roll(")) {
                    disabled = daeSystemClass.safeEvalExpression(value, rollData);
                    disabled = daeSystemClass.safeEval(disabled, rollData);
                }
                else
                    disabled = daeSystemClass.safeEval(value, rollData);
                if (!!disabled !== effect.disabled) {
                    if (debugEnabled > 0)
                        warn("setting disabled effect", effect, disabled);
                    await effect.update({ disabled: !!disabled });
                }
            }
            catch (err) {
                warn("diabledCondition error", err);
            }
        }
    }
    await token?.drawEffects();
}
// TODO (Michael) type this for activities not just items
export function enumerateBaseValues(objectDataModels, logErrors = true) {
    const baseValues = {};
    //@ts-expect-error no dnd5e-types
    const dataModels = game.system.dataModels;
    const MappingField = dataModels.fields.MappingField;
    // TODO (Michael) once dnd5e-types in, ensure mapping field properly typed
    function processMappingField(key, mappingField, baseValues, logErrors = true) {
        const fields = mappingField.initialKeys;
        if (!fields)
            return;
        for (let fieldKey of Object.keys(fields)) {
            if (mappingField.model instanceof SchemaField) {
                processSchemaField(`${key}.${fieldKey}`, mappingField.model, baseValues, logErrors);
            }
            else if (mappingField.model instanceof MappingField) {
                processMappingField(`${key}.${fieldKey}`, mappingField.model, baseValues, logErrors);
            }
            else {
                // TODO come back and see how favorites might be supported.
                if (fieldKey.includes("favorites"))
                    return;
                // let initial = fields[fieldKey].initial ?? 0;;
                // if (typeof fields[fieldKey].initial === "function") { initial = fields[fieldKey].initial() ?? ""; }
                baseValues[`${key}.${fieldKey}`] = [fields[fieldKey], ""];
            }
        }
    }
    function processSchemaField(key, schemaField, baseValues, logErrors = true) {
        const fields = schemaField.fields;
        for (let fieldKey of Object.keys(fields)) {
            if (fields[fieldKey] instanceof SchemaField) {
                processSchemaField(`${key}.${fieldKey}`, fields[fieldKey], baseValues, logErrors);
            }
            else if (fields[fieldKey] instanceof MappingField) {
                processMappingField(`${key}.${fieldKey}`, fields[fieldKey], baseValues, logErrors);
            }
            else {
                if (fieldKey.includes("favorites"))
                    return; //TODO see above
                // let initial = fields[fieldKey].initial ?? 0;;
                // if (typeof fields[fieldKey].initial === "function") { initial = fields[fieldKey].initial() ?? ""; }
                baseValues[`${key}.${fieldKey}`] = [fields[fieldKey], ""];
            }
        }
    }
    for (let key of Object.keys(objectDataModels)) {
        const schema = objectDataModels[key].schema;
        baseValues[key] = {};
        if (schema instanceof SchemaField) {
            processSchemaField(`system`, schema, baseValues[key]);
        }
        else if (logErrors)
            console.error("Unexpected field ", key, schema);
    }
    return baseValues;
}
export function effectBaseName(effect) {
    if (!effect?.name)
        return "";
    if (!effect.flags.dae?.stacks)
        return effect.name;
    const returnName = effect.name.replace(/(.*) \([0-9]+\)?$/, "$1");
    return returnName;
}
function busyWait(seconds) {
    return new Promise(resolve => setTimeout(resolve, seconds * 1000));
}
export function getStaticID(id) {
    id = `dnd5e${id}`;
    if (id.length >= 16)
        return id.substring(0, 16);
    return id.padEnd(16, "0");
}
