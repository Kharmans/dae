import { ceInterface, atlActive, daeSystemClass, getStatusEffectsArray, localizationMap } from "../dae.js";
import { i18n, daeSpecialDurations, daeMacroRepeats, error } from "../../dae.js";
import { ValidSpec } from "../Systems/DAESystem.js";
import { DAEFieldBrowser } from "./FieldBrowser.js";
/**
 * A DataField for boolean formula strings that combine with || (OR) and && (AND) semantics
 * via Active Effect change modes, analogous to dnd5e's FormulaField for arithmetic formulas.
 */
export class BooleanFormulaField extends foundry.data.fields.StringField {
    _castChangeDelta(delta) {
        return (this._cast(delta) ?? "").trim();
    }
    // ADD → OR semantics: either condition grants the flag
    _applyChangeAdd(value, delta, model, change) {
        if (!value)
            return delta;
        return `(${value}) || (${delta})`;
    }
    // MULTIPLY → AND semantics: all conditions must be met
    _applyChangeMultiply(value, delta, model, change) {
        if (!value)
            return value;
        return `(${value}) && (${delta})`;
    }
    // UPGRADE → OR (same as ADD for booleans)
    _applyChangeUpgrade(value, delta, model, change) {
        return this._applyChangeAdd(value, delta, model, change);
    }
    // DOWNGRADE → AND (same as MULTIPLY for booleans)
    _applyChangeDowngrade(value, delta, model, change) {
        return this._applyChangeMultiply(value, delta, model, change);
    }
}
export const otherFieldsMap = new Map();
export function addAutoFields(fields) {
    for (const field of fields) {
        const entry = typeof field === "string" ? { name: field } : field;
        if (!entry.name)
            continue;
        const existing = otherFieldsMap.get(entry.name);
        if (existing) {
            // Update type if a new type is provided for an existing entry
            if (entry.type !== undefined)
                existing.type = entry.type;
            continue;
        }
        otherFieldsMap.set(entry.name, entry);
    }
}
const fieldEditorRegistry = new Map();
export function registerFieldEditor(registration) {
    fieldEditorRegistry.set(registration.keyMatch, registration);
}
export function getFieldEditor(key) {
    // Exact match first
    if (fieldEditorRegistry.has(key))
        return fieldEditorRegistry.get(key);
    // Then prefix match — walk up the key segments
    const parts = key.split(".");
    while (parts.length > 1) {
        parts.pop();
        const prefix = parts.join(".") + ".";
        if (fieldEditorRegistry.has(prefix))
            return fieldEditorRegistry.get(prefix);
    }
    return undefined;
}
const stackableOptions = {
    noneName: "dae.StackableOptions.noneName",
    noneNameOnly: "dae.StackableOptions.noneNameOnly",
    none: "dae.StackableOptions.none",
    multi: "dae.StackableOptions.multi",
    count: "dae.StackableOptions.count",
    countDeleteDecrement: "dae.StackableOptions.countDeleteDecrement"
};
export class DAEActiveEffectConfig extends foundry.applications.sheets.ActiveEffectConfig {
    ceEffectList = {};
    constructor(options) {
        // @ts-expect-error v13 stubby
        super(options);
        this.tokenMagicEffects = {};
        if (globalThis.TokenMagic?.getPresets) {
            globalThis.TokenMagic.getPresets().forEach(preset => {
                this.tokenMagicEffects[preset.name] = preset.name;
            });
        }
        else
            this.tokenMagicEffects["invalid"] = "module not active";
        this.validSpecsToUse = ValidSpec.actorSpecs?.["union"];
        if (!this.validSpecsToUse) {
            ui.notifications?.error("DAE | No valid specs found");
            return;
        }
        daeSystemClass.configureLists();
        this.statusEffectList = {};
        getStatusEffectsArray()
            .filter(se => se.id)
            .map(se => ({ id: se.id, name: i18n(se.name) }))
            .toSorted((a, b) => a.name < b.name ? -1 : 1)
            .forEach(se => {
            this.statusEffectList[se.id] = se.name;
        });
        if (ceInterface) {
            ceInterface.findEffects().forEach(ceEffect => { this.ceEffectList[ceEffect.name] = ceEffect.name; });
        }
        if (atlActive && !isEnchantment(options.document)) {
            this.ATLPresets = {};
            game.settings.get("ATL", "presets").forEach(preset => this.ATLPresets[preset.name] = preset.name);
            Object.keys(CONFIG.Canvas.detectionModes).forEach(dm => {
                const name = `ATL.detectionModes.${dm}.range`;
                if (!otherFieldsMap.has(name)) {
                    otherFieldsMap.set(name, { name });
                }
            });
            this.ATLVisionModes = {};
            Object.values(CONFIG.Canvas.visionModes)
                .filter(f => f.tokenConfig)
                .forEach(f => this.ATLVisionModes[f.id] = i18n(f.label));
        }
        this.validFields = { "__": { name: "" } };
        this.validFields = this.validSpecsToUse.allSpecs
            .filter(e => e._fieldSpec.includes(""))
            .reduce((mods, em) => {
            mods[em._fieldSpec] = {
                name: localizationMap[em._fieldSpec]?.name ?? em._label,
                description: localizationMap[em._fieldSpec]?.description ?? em._description
            };
            return mods;
        }, this.validFields);
        if (!isEnchantment(this.document)) {
            for (let fieldName of [...otherFieldsMap.keys()].sort((a, b) => a.toLocaleLowerCase() < b.toLocaleLowerCase() ? -1 : 1)) {
                this.validFields[fieldName] = {
                    name: localizationMap[fieldName]?.name ?? fieldName,
                    description: localizationMap[fieldName]?.description || (localizationMap[fieldName]?.name ?? fieldName)
                };
            }
        }
        this.daeFieldBrowser = new DAEFieldBrowser(this.validFields, this);
        this.daeFieldBrowser.init().then(() => this.render());
    }
    static DEFAULT_OPTIONS = {
        window: {
            resizable: true
        },
        position: {
            height: "auto",
            width: 900
        },
        classes: ["sheet", "active-effect-config", "window-app", "dae"],
        actions: {
            addChange: DAEActiveEffectConfig.#onAddChange,
            deleteChange: DAEActiveEffectConfig.#onDeleteChange,
            addSpecialDuration: DAEActiveEffectConfig.#onAddSpecialDuration,
            deleteSpecialDuration: DAEActiveEffectConfig.#onDeleteSpecialDuration,
            resetStartTime: DAEActiveEffectConfig.#onResetStartTime
        }
    };
    static PARTS = foundry.utils.mergeObject(super.PARTS ?? {}, {
        details: { template: "./modules/dae/templates/DAESheetConfig/Details.hbs", scrollable: [""] },
        duration: { template: "./modules/dae/templates/DAESheetConfig/Duration.hbs" },
        changes: { template: "./modules/dae/templates/DAESheetConfig/Changes.hbs", scrollable: ["scrollable"] }
    }, { inplace: false });
    /* ----------------------------------------- */
    getOptionsForSpec(spec) {
        if (!spec?.key)
            return undefined;
        if (spec.key.includes("tokenMagic"))
            return this.tokenMagicEffects;
        if (spec.key === "macro.CE")
            return this.ceEffectList;
        if (spec.key === "macro.StatusEffect")
            return this.statusEffectList;
        if (spec.key === "StatusEffect")
            return this.statusEffectList;
        if (spec.key === "ATL.preset")
            return this.ATLPresets;
        if (spec.key === "ATL.sight.visionMode")
            return this.ATLVisionModes;
        return daeSystemClass.getOptionsForSpec(spec);
    }
    async _prepareContext(options) {
        const context = await super._prepareContext(options);
        const document = this.document;
        if (document.parent instanceof CONFIG.Actor.documentClass || document instanceof CONFIG.Actor.documentClass) {
            this.validSpecsToUse = ValidSpec.actorSpecs[document.parent?.type ?? ""];
        }
        if (isEnchantment(document)) {
            document.transfer = false;
            // @ts-expect-error no dnd5e-types
            if (document.isAppliedEnchantment) {
                this.validSpecsToUse = ValidSpec.itemSpecs[document.parent?.type ?? ""] ?? ValidSpec.itemSpecs["union"];
            }
            else {
                let restrictionType = "union";
                if (document.parent instanceof CONFIG.Item.documentClass) {
                    // @ts-expect-error no dnd5e-types
                    const activity = document.parent.system.activities.find(a => a.type === "enchant" && a.effects.find(e => e.effect?.uuid === document?.uuid));
                    if (activity) {
                        restrictionType = activity.restrictions.type;
                    }
                    this.validSpecsToUse = ValidSpec.itemSpecs[restrictionType || "union"];
                }
            }
        }
        if (!this.validSpecsToUse) {
            ui.notifications?.error("DAE | No valid specs found");
            return context;
        }
        this.validFields = { "__": { name: "" } };
        this.validFields = this.validSpecsToUse.allSpecs
            .filter(e => e._fieldSpec.includes(""))
            .reduce((mods, em) => {
            mods[em._fieldSpec] = {
                name: localizationMap[em._fieldSpec]?.name ?? em._label,
                description: localizationMap[em._fieldSpec]?.description ?? em._description
            };
            return mods;
        }, this.validFields);
        if (!isEnchantment(document)) {
            for (let fieldName of [...otherFieldsMap.keys()].sort((a, b) => a.toLocaleLowerCase() < b.toLocaleLowerCase() ? -1 : 1)) {
                this.validFields[fieldName] = {
                    name: localizationMap[fieldName]?.name ?? fieldName,
                    description: localizationMap[fieldName]?.description || (localizationMap[fieldName]?.name ?? fieldName)
                };
            }
        }
        this.daeFieldBrowser = new DAEFieldBrowser(this.validFields, this);
        this.daeFieldBrowser.init();
        if (document.flags?.dae?.specialDuration === undefined)
            foundry.utils.setProperty(document, "flags.dae.specialDuration", []);
        // Migrate deprecated special durations to v14 duration.expiry + combatActorOverride
        const deprecatedSpecialDurMap = {
            "turnStart": { expiry: "turnStart", combatActor: "target" },
            "turnEnd": { expiry: "turnEnd", combatActor: "target" },
            "turnStartSource": { expiry: "turnStart", combatActor: "source" },
            "turnEndSource": { expiry: "turnEnd", combatActor: "source" },
            "combatEnd": { expiry: "combatEnd", combatActor: null }
        };
        let specialDurs = Array.isArray(document.flags?.dae?.specialDuration) ? document.flags.dae.specialDuration : (document.flags?.dae?.specialDuration ? [document.flags.dae.specialDuration] : []);
        if (typeof specialDurs === "string")
            specialDurs = [specialDurs];
        const deprecatedDurs = specialDurs.filter(sd => sd in deprecatedSpecialDurMap);
        if (deprecatedDurs.length > 0) {
            const migration = deprecatedSpecialDurMap[deprecatedDurs[0]];
            const remaining = specialDurs.filter(sd => !(sd in deprecatedSpecialDurMap));
            ui.notifications?.warn(`DAE | Effect "${document.name}": special duration "${deprecatedDurs.join(", ")}" is deprecated. Migrating to duration expiry.`);
            foundry.utils.setProperty(document, "flags.dae.specialDuration", remaining);
            foundry.utils.setProperty(document, "duration.expiry", migration.expiry);
            if (migration.combatActor) {
                foundry.utils.setProperty(document, "flags.dae.combatActorOverride", migration.combatActor);
            }
        }
        // Migrate deprecated flags.dae.showIcon to native showIcon field
        if (document.flags?.dae?.showIcon) {
            ui.notifications?.warn(`DAE | Effect "${document.name}": flags.dae.showIcon is deprecated. Migrating to native showIcon field.`);
            foundry.utils.setProperty(document, "showIcon", 2);
            foundry.utils.setProperty(document, "flags.dae.-=showIcon", null);
        }
        if (!document.flags?.dae?.stackable) {
            foundry.utils.setProperty(document, "flags.dae.stackable", "multi");
            foundry.utils.setProperty(context, "effect.flags.dae.stackable", "multi");
        }
        await daeSystemClass.editConfig();
        // v14: build change type options from ActiveEffect.CHANGE_TYPES (string-keyed)
        // @ts-expect-error v14 ActiveEffect.CHANGE_TYPES not in fvtt-types yet
        const changeTypesRaw = ActiveEffect.CHANGE_TYPES ?? {};
        const allTypes = {};
        for (const [type, config] of Object.entries(changeTypesRaw)) {
            allTypes[type] = i18n(config.label);
        }
        context.allTypes = allTypes;
        // v14: provide default priorities keyed by type string (for placeholder in template)
        const priorities = {};
        for (const [type, config] of Object.entries(changeTypesRaw)) {
            priorities[type] = config.defaultPriority;
        }
        context.priorities = priorities;
        // v14: provide change schema fields from system.changes (not top-level changes)
        // @ts-expect-error v14 system typed data model
        context.changeFields = document.system.schema.fields.changes.element.fields;
        // v14: duration units, expiry events, and start context are provided by the core's
        // _preparePartContext("duration", ...) — no need to set them here.
        // DAE-specific duration context:
        context.specialDuration = daeSpecialDurations;
        context.showSpecialDurations = Object.keys(daeSpecialDurations)?.length > 1;
        context.macroRepeats = daeMacroRepeats;
        context.stackableOptions = stackableOptions;
        context.combatActorOptions = {
            "source": i18n("dae.combatActorSource"),
            "target": i18n("dae.combatActorTarget")
        };
        // v14: use native duration.units instead of shimmed duration.rounds/turns
        const isCombatDuration = ["rounds", "turns"].includes(document.duration?.units);
        const hasTurnExpiry = ["turnStart", "turnEnd"].includes(document.duration?.expiry);
        context.showCombatActorOverride = isCombatDuration || hasTurnExpiry;
        context.expiryModeOptions = {
            "default": i18n("dae.expiryMode.default"),
            "delete": i18n("dae.expiryMode.delete"),
            "suppress": i18n("dae.expiryMode.suppress"),
        };
        if (document.parent) {
            context.isItemEffect = document.parent instanceof CONFIG.Item.documentClass;
            context.isActorEffect = document.parent instanceof CONFIG.Actor.documentClass;
        }
        context.submitText = "EFFECT.Submit";
        context.source.system.changes.forEach(change => {
            const spec = this.validSpecsToUse.allSpecsObj[change.key];
            if (!spec?.forcedMode) {
                // No forced mode — allow all types
                if (change.types && options.force)
                    error("DAE | change already has types set", this.document, change);
                change.types = allTypes;
            }
            else if (spec) {
                // Forced type — restrict dropdown to the single specified type
                const restrictedTypes = {};
                restrictedTypes[spec.forcedMode] = allTypes[spec.forcedMode] ?? spec.forcedMode;
                if (change.types && options.force)
                    error("DAE | change already has types set", this.document, change);
                change.types = restrictedTypes;
            }
            if (spec?.options) {
                if (change.options && options.force)
                    error("DAE | change already has options set", this.document, change);
                change.options = spec.options;
            }
            else {
                if (change.options && options.force)
                    error("DAE | change already has options set", this.document, change);
                change.options = this.getOptionsForSpec(change);
            }
            if (!change.priority)
                change.priority = changeTypesRaw[change.type ?? "add"]?.defaultPriority ?? 0;
            const fieldInfo = this.daeFieldBrowser.getFieldInfo(change.key);
            change.fieldName = fieldInfo.name;
            change.fieldDescription = fieldInfo.description;
            if (fieldInfo.name === change.key && !change.key.startsWith("flags")) {
                // Could not find the key so set the name to <UNKNOWN>
                change.fieldName = "<UNKNOWN>";
            }
            // Some SRD/Player's Handbook effects have string fields enclosed in quotes which confuses DAEs selection process
            // Stripping them off is safe since the field is still a string
            if (typeof change.value === "string") {
                change.value = change.value.replace(/^(["'])(.*)\1$/, "$2");
            }
            // Mark changes that have a registered pluggable editor
            const fieldEditor = getFieldEditor(change.key);
            if (fieldEditor) {
                change.hasEditor = true;
                change.editorIcon = fieldEditor.icon ?? "fas fa-edit";
                change.editorTooltip = fieldEditor.tooltip ?? "Edit";
            }
        });
        // v14: start time display is handled by core's _prepareStartContext() using game.time.calendar
        foundry.utils.setProperty(context.document, "flags.dae.durationExpression", document.flags?.dae?.durationExpression);
        if (!context.document.flags?.dae?.specialDuration || !(context.document.flags.dae.specialDuration instanceof Array))
            foundry.utils.setProperty(context.document.flags, "dae.specialDuration", []);
        context.sourceName = await document.sourceName;
        context.midiActive = globalThis.MidiQOL !== undefined;
        context.isEnchantment = isEnchantment(document);
        context.isConditionalActivationEffect = document.parent?.name === i18n("dae.ConditionalEffectsItem");
        context.transfer = document.transfer;
        if (context.isConditionalActivationEffect) {
            context.transfer = false;
            context.document.transfer = false;
        }
        return context;
    }
    updateFieldInfo() {
        // @ts-expect-error v14 system.changes
        const changes = this.document.system.changes;
        changes.forEach((change, index) => {
            const fieldInfo = this.daeFieldBrowser.getFieldInfo(change.key);
            const row = this.element?.querySelector(`.effect-change[data-index="${index}"]`);
            const fieldName = row?.querySelector(".dae-field-name");
            const fieldDescription = row?.querySelector(".dae-field-description");
            if (fieldName && fieldDescription) {
                fieldName.textContent = fieldInfo.name;
                fieldDescription.textContent = fieldInfo.description;
            }
        });
    }
    async _onRender(context, options) {
        // @ts-expect-error wait 'til types de-stubs, then type this properly
        const currTabId = Object.values(context.tabs)?.find(i => i.active)?.id;
        if (currTabId !== "changes")
            this.position.height = this.element.offsetHeight ?? "auto";
        const keyInputs = Array.from(this.element.querySelectorAll(".key-input"));
        for (const keyInput of keyInputs) {
            keyInput.addEventListener("click", this.#onKeyInputInteraction.bind(this));
            keyInput.addEventListener("input", this.#onKeyInputInteraction.bind(this));
        }
        const transferCheckBox = Array.from(this.element.querySelectorAll(".transferCheckbox"));
        for (const checkbox of transferCheckBox) {
            checkbox.addEventListener("change", (event) => {
                this.submit()?.then(() => this.render());
            });
        }
        new foundry.applications.ux.DragDrop.implementation({
            // dragSelector: ".dae-change-drag-handle",
            dropSelector: ".value",
            callbacks: {
                drop: this._onDrop.bind(this)
            }
        }).bind(this.element);
        // Pluggable editor buttons
        const editButtons = Array.from(this.element.querySelectorAll(".dae-edit-value"));
        for (const btn of editButtons) {
            btn.addEventListener("click", this.#onEditValue.bind(this));
        }
    }
    changeTab(tab, group, options) {
        let autoPos = { ...this.position, height: "auto" };
        this.setPosition(autoPos);
        super.changeTab(tab, group, options);
        // Don't want to allow resizing height for changes tab, as that's handled by resizing the textareas themselves
        if (tab === "changes")
            return;
        let newPos = { ...this.position, height: this.element.offsetHeight };
        this.setPosition(newPos);
    }
    #onKeyInputInteraction(event) {
        const input = event.currentTarget;
        this.daeFieldBrowser.setInput(input);
        if (event.type === "click") {
            this.daeFieldBrowser.updateBrowser();
        }
        else if (event.type === "input") {
            this.daeFieldBrowser.debouncedUpdateBrowser();
        }
    }
    onFieldSelected() {
        this.submit()?.then(() => this.render());
    }
    async #onEditValue(event) {
        const btn = event.currentTarget;
        const index = Number(btn.dataset.index);
        // @ts-expect-error v14 system.changes
        const change = this.document.system.changes[index];
        if (!change)
            return;
        const registration = getFieldEditor(change.key);
        if (!registration)
            return;
        // Read current value from the textarea (may have unsaved edits)
        const textarea = this.element.querySelector(`textarea[name="system.changes.${index}.value"]`);
        const currentValue = textarea?.value ?? change.value ?? "";
        const result = await registration.editor(currentValue, {
            key: change.key,
            effect: this.document,
            parent: this.document.parent,
            changeIndex: index,
            app: this,
        });
        if (result !== null && result !== undefined) {
            if (textarea)
                textarea.value = result;
            this.submit()?.then(() => this.render());
        }
    }
    /* ----------------------------------------- */
    _onDragStart(ev) { }
    // TODO: What is this actually for?
    async _onDrop(ev) {
        ev.preventDefault();
        const data = foundry.applications.ux.TextEditor.getDragEventData(ev);
        const item = await fromUuid(data.uuid);
        const targetValue = ev.target?.value?.split(",")[1];
        if (data.uuid && ev.target) {
            ev.target.value = data.uuid + (targetValue ? `, ${targetValue}` : "");
            this.submit()?.then(() => this.render());
        }
        if (data.fieldName) {
            if (ev.target)
                ev.target.value = data.fieldName;
            this.daeFieldBrowser.debouncedUpdateBrowser();
        }
    }
    // v14: Override core's addChange — collect from system.changes and append a new empty change
    static #onAddChange() {
        // @ts-expect-error v13 stubby
        const submitData = this._processFormData(null, this.form, new foundry.applications.ux.FormDataExtended(this.form));
        const changes = Object.values(submitData.system?.changes ?? {});
        // @ts-expect-error v14 system typed data model
        changes.push(this.document.system.schema.fields.changes.element.getInitialValue());
        // @ts-expect-error v13 stubby
        return this.submit({ updateData: { system: { changes } } });
    }
    // v14: Override core's deleteChange — collect from system.changes and remove the target
    static #onDeleteChange(event) {
        // @ts-expect-error v13 stubby
        const submitData = this._processFormData(null, this.form, new foundry.applications.ux.FormDataExtended(this.form));
        const changes = Object.values(submitData.system?.changes ?? {});
        const row = event.target.closest("li");
        const index = Number(row.dataset.index) || 0;
        changes.splice(index, 1);
        // @ts-expect-error v13 stubby
        return this.submit({ updateData: { system: { changes } } });
    }
    static #onAddSpecialDuration() {
        // @ts-expect-error v13 stubby
        const submitData = this._processFormData(null, this.form, new foundry.applications.ux.FormDataExtended(this.form));
        const specialDuration = Object.values(submitData.flags?.dae?.specialDuration ?? {});
        // @ts-expect-error v13 stubby
        return this.submit({
            updateData: {
                "flags.dae.specialDuration": specialDuration.concat("None")
            }
        });
    }
    static #onDeleteSpecialDuration(event) {
        // @ts-expect-error v13 stubby
        const submitData = this._processFormData(null, this.form, new foundry.applications.ux.FormDataExtended(this.form));
        const specialDuration = Object.values(submitData.flags?.dae?.specialDuration ?? {});
        const idx = Number(event.target.closest("li").dataset.index) || 0;
        specialDuration.splice(idx, 1);
        // @ts-expect-error v13 stubby
        return this.submit({
            updateData: {
                "flags.dae.specialDuration": specialDuration
            }
        });
    }
    static #onResetStartTime() {
        // @ts-expect-error v14 ActiveEffect.getEffectStart
        const start = ActiveEffect.getEffectStart(game.combat);
        // @ts-expect-error v13 stubby
        return this.submit({
            updateData: {
                start,
                "duration.expired": false
            }
        });
    }
    async _processSubmitData(event, form, submitData) {
        const document = this.document;
        if (!submitData.tint || submitData.tint === "")
            submitData.tint = null;
        // fixed for very old items
        if (document.origin?.includes("OwnedItem."))
            submitData.origin = document.origin.replace("OwnedItem.", "Item.");
        if (submitData.flags?.dae?.enableCondition?.length > 0)
            submitData.transfer = false;
        if (submitData.transfer && !isEnchantment(document))
            submitData.origin = document.parent?.uuid;
        else
            delete submitData.origin;
        if (isEnchantment(document))
            submitData.transfer = false;
        submitData.statuses ??= [];
        foundry.utils.setProperty(submitData, "flags.dae.specialDuration", Array.from(Object.values(submitData.flags?.dae?.specialDuration ?? {})));
        // Set the correct phase on each change based on the ValidSpec lookup.
        // The schema defaults phase to "initial", but specials/derived fields need "final".
        const changes = submitData.system?.changes;
        if (changes && this.validSpecsToUse?.allSpecsObj) {
            for (const change of Object.values(changes)) {
                const spec = this.validSpecsToUse.allSpecsObj[change.key];
                if (spec)
                    change.phase = spec.phase;
            }
        }
        await this.document.update(submitData);
    }
    /* ----------------------------------------- */
    async _preClose(options) {
        await super._preClose(options);
        if (this.daeFieldBrowser && this.daeFieldBrowser.browserElement) {
            this.daeFieldBrowser.browserElement.remove();
            this.daeFieldBrowser.browserElement = null;
        }
        // v14: changes are in system.changes, not top-level changes
        for (let change of (this.document._source.system?.changes ?? [])) {
            delete change.types;
            delete change.options;
        }
    }
}
export function geti18nTranslations() {
    let translations = game.i18n?.translations["dae"];
    // if (!translations) translations = game.i18n._fallback["dae"];
    return translations ?? {};
}
Hooks.once("setup", () => {
    foundry.applications.apps.DocumentSheetConfig.registerSheet(CONFIG.ActiveEffect.documentClass, "core", DAEActiveEffectConfig, {
        label: i18n("dae.EffectSheetLabel"),
        makeDefault: true,
        canBeDefault: true,
        canConfigure: true
    });
});
export function isEnchantment(effect) {
    //@ts-expect-error no dnd5e-types
    return effect.type === "enchantment";
}
