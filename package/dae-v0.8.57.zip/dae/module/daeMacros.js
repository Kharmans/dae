import { requestGMAction, GMAction } from "./GMAction.js";
import { warn, error } from "../dae.js";
export let applyActive = (itemName, activate = true, itemType = "") => {
};
export let activateItem = () => {
    //@ts-ignore cant do anything if there are no targets
    const speaker = ChatMessage.getSpeaker();
    const token = canvas.tokens.get(speaker.token);
    if (!token) {
        ui.notifications.warn(`${game.i18n.localize("dae.noSelection")}`);
        return;
    }
    // return new ActiveItemSelector(token.actor, {}).render(true);
};
let tokenScene = (tokenName, sceneName) => {
    if (!sceneName) {
        for (let scene of game.scenes) {
            //@ts-ignore
            let found = scene.tokens.getName(tokenName);
            if (found)
                return { scene, found };
        }
    }
    else {
        //@ts-ignore
        let scene = game.scenes.getName(sceneName);
        if (scene) {
            //@ts-ignore
            let found = scene.tokens.getName(tokenName);
            if (found) {
                return { scene, found };
            }
        }
    }
    return { scene: null, tokenDocument: null };
};
export let moveToken = async (token, targetTokenName, xGridOffset = 0, yGridOffset = 0, targetSceneName = "") => {
    let { scene, found } = tokenScene(targetTokenName, targetSceneName);
    if (!token) {
        warn("Dynmaiceffects | moveToken: Token not found");
        return ("Token not found");
    }
    if (!found) {
        warn("dae | moveToken: Target Not found");
        return `Token ${targetTokenName} not found`;
    }
    return await requestGMAction(GMAction.actions.recreateToken, { userId: game.user.id,
        startSceneId: canvas.scene.id,
        tokenUuid: token.uuid,
        targetSceneId: scene.id, tokenData: token.data,
        x: found.data.x + xGridOffset * canvas.scene.data.grid,
        y: found.data.y + yGridOffset * canvas.scene.data.grid
    });
};
export let renameToken = async (token, newName) => {
    requestGMAction(GMAction.actions.renameToken, { userId: game.user.id, startSceneId: canvas.scene.id, tokenData: token.data, newName });
};
export let teleportToToken = async (token, targetTokenName, xGridOffset = 0, yGridOffset = 0, targetSceneName = "") => {
    let { scene, found } = tokenScene(targetTokenName, targetSceneName);
    if (!token) {
        error("dae| teleportToToken: Token not found");
        return ("Token not found");
    }
    if (!found) {
        error("dae| teleportToToken: Target Not found");
        return `Token ${targetTokenName} not found`;
    }
    //@ts-ignore target.scene.data.grid
    return teleport(token, scene, found.data.x + xGridOffset * canvas.scene.data.grid, found.data.y + yGridOffset * canvas.scene.data.grid);
};
export async function createToken(tokenData, x, y) {
    let targetSceneId = canvas.scene.id;
    requestGMAction(GMAction.actions.createToken, { userId: game.user.id, targetSceneId, tokenData, x, y });
}
export let teleport = async (token, targetScene, xpos, ypos) => {
    let x = Number(xpos);
    let y = parseInt(ypos);
    if (isNaN(x) || isNaN(y)) {
        error("dae| teleport: Invalid co-ords", xpos, ypos);
        return `Invalid target co-ordinates (${xpos}, ${ypos})`;
    }
    if (!token) {
        console.warn("dae | teleport: No Token");
        return "No active token";
    }
    // Hide the current token
    if (targetScene.name === canvas.scene.name) {
        //@ts-ignore
        CanvasAnimation.terminateAnimation(`Token.${token.id}.animateMovement`);
        let sourceSceneId = canvas.scene.id;
        requestGMAction(GMAction.actions.recreateToken, { userId: game.user.id, tokenUuid: token.uuid, startSceneId: sourceSceneId, targetSceneId: targetScene.id, tokenData: token.data, x: xpos, y: ypos });
        canvas.pan({ x: xpos, y: ypos });
        return true;
    }
    // deletes and recreates the token
    var sourceSceneId = canvas.scene.id;
    Hooks.once("canvasReady", async () => {
        await requestGMAction(GMAction.actions.createToken, { userId: game.user.id, startSceneId: sourceSceneId, targetSceneId: targetScene.id, tokenData: token.data, x: xpos, y: ypos });
        // canvas.pan({ x: xpos, y: ypos });
        await requestGMAction(GMAction.actions.deleteToken, { userId: game.user.id, tokenUuid: token.uuid });
    });
    // Need to stop animation since we are going to delete the token and if that happens before the animation completes we get an error
    //@ts-ignore
    CanvasAnimation.terminateAnimation(`Token.${token.id}.animateMovement`);
    return await targetScene.view();
};
export let setTokenVisibility = async (tokenId, visible) => {
    if (typeof tokenId !== "string")
        tokenId = tokenId.id;
    return requestGMAction(GMAction.actions.setTokenVisibility, { targetSceneId: canvas.scene.id, tokenId, hidden: !visible });
};
export let setTileVisibility = async (tileId, visible) => {
    if (typeof tileId !== "string")
        tileId = tileId.id;
    return requestGMAction(GMAction.actions.setTileVisibility, { targetSceneId: canvas.scene.id, tileId, hidden: !visible });
};
export let blindToken = async (tokenId) => {
    if (typeof tokenId !== "string")
        tokenId = tokenId.id;
    return requestGMAction(GMAction.actions.blindToken, { tokenId: tokenId, sceneId: canvas.scene.id });
};
export let restoreVision = async (tokenId) => {
    if (typeof tokenId !== "string")
        tokenId = tokenId.id;
    return requestGMAction(GMAction.actions.restoreVision, { tokenId: tokenId, sceneId: canvas.scene.id });
};
export let macroReadySetup = () => {
};
export function getTokenFlag(token, flagName) {
    return getProperty(token, `data.flags.dae.${flagName}`);
}
export function deleteActiveEffect(actorUuid, origin, ignore = []) {
    requestGMAction(GMAction.actions.deleteEffects, { targets: [{ actorUuid }], origin, ignore });
}
export function setTokenFlag(token, flagName, flagValue) {
    const tokenId = (typeof token === "string") ? token : token.id;
    return requestGMAction(GMAction.actions.setTokenFlag, { tokenId: tokenId, sceneId: canvas.scene.id, flagName, flagValue });
}
export function getFlag(actor, flagId) {
    let theActor;
    if (!actor)
        return error(`dae.getFlag: actor not defined`);
    if (typeof actor === "string") { // assume tstring === tokenId
        theActor = canvas.tokens.get(actor)?.actor;
        if (!theActor)
            theActor = game.actors.get(actor); // if not a token maybe an actor
    }
    else {
        if (actor instanceof Actor)
            theActor = actor;
        else
            theActor = actor.actor;
    }
    if (!theActor)
        return error(`dae.getFlag: actor not defined`);
    warn("dae get flag ", actor, theActor, getProperty(theActor.data, `flags.dae.${flagId}`));
    return getProperty(theActor.data, `flags.dae.${flagId}`);
}
export function setFlag(actor, flagId, value) {
    if (typeof actor === "string") {
        return requestGMAction(GMAction.actions.setFlag, { actorId: actor, flagId, value });
    }
    if (actor instanceof Token)
        actor = actor.actor;
    if (!actor)
        return error(`dae.setFlag: actor not defined`);
    return requestGMAction(GMAction.actions.setFlag, { actorId: actor.id, actorUuid: actor.uuid, flagId, value });
}
export function unsetFlag(actor, flagId) {
    //@ts-ignore
    if (typeof actor === "string") {
        return requestGMAction(GMAction.actions.unsetFlag, { actorId: actor, flagId });
    }
    if (actor instanceof Token)
        actor = actor.actor;
    if (!actor)
        return error(`dae.setFlag: actor not defined`);
    return requestGMAction(GMAction.actions.unsetFlag, { actorId: actor.id, actorUuid: actor.uuid, flagId });
}
