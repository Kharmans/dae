import { warn, debug } from "../dae.js";
export class GMActionMessage {
    constructor(action, sender, targetGM, data) {
        this.action = action;
        this.sender = sender;
        this.targetGM = targetGM;
        this.data = data;
    }
}
export let requestGMAction = async (action, data, debugLog = false) => {
    if (game.user.isGM) {
        //@ts-ignore
        return await GMAction.processAction(action, game.user.id, duplicate(data));
    }
    //@ts-ignore
    let intendedGM = game.users.entities.find(u => u.isGM && u.active);
    //@ts-ignore
    // if (!game.user.isTrusted) return;
    if (!intendedGM) {
        ui.notifications.error(`${game.user.name} ${game.i18n.localize("dae.noGM")}`);
        console.error("dae | No GM user connected - cannot do request ", action, data);
        return;
    }
    //@ts-ignore
    let message = new DAE.GMActionMessage(action, game.user.id, intendedGM.id, data);
    debug("About to send message", message);
    //@ts-ignore
    game.socket.emit(DAE.GMAction._moduleSocket, message, resp => {
        debug("message sent");
    });
};
export class GMAction {
    static _setupSocket() {
        //@ts-ignore
        game.socket.on(this._moduleSocket, async (message) => {
            console.error("socket received ", message);
            if (game.user.id !== message.targetGM)
                return;
            if (!game.user.isGM)
                return;
            return this.processAction(message.action, message.sender, message.data);
        });
    }
    static initActions() {
    }
    static setupActions() {
    }
    static readyActions() {
        this._setupSocket();
        requestGMAction("testMessage", game.user.name);
    }
    static async processAction(action, userId, data) {
        this.processSingleAction(action, userId, data);
    }
    static async processActionQueue() {
        debug("Processing action queue");
        this.processingActions = this.actionQueue.length > 0;
        while (this.processingActions) {
            debug("Processing Actions ", this.actionQueue.length);
            let { action, userId, data } = this.actionQueue[0];
            debug("Processing actions ", action, userId, data);
            await this.processSingleAction(action, userId, data);
            this.actionQueue = this.actionQueue.slice(1);
            this.processingActions = this.actionQueue.length > 0;
        }
    }
    static async processSingleAction(action, userId, data) {
        var actorId;
        //@ts-ignore
        let itemData = data.itemData;
        //@ts-ignore
        var tokenId = data.tokenId;
        var targetList;
        //@ts-ignore
        var requester = userId;
        //@ts-ignore
        var actorId = data.actorId;
        var scene;
        switch (action) {
            case "testMessage":
                console.log("DyamicEffects | test message received", data);
                return "Test message received and processed";
                break;
            case this.actions.setTokenVisibility:
                //@ts-ignore
                await setTokenVisibility(requester, data);
                break;
            case this.actions.setTileVisibility:
                //@ts-ignore
                await setTileVisibility(requester, data);
                break;
            case this.actions.applyActiveEffects:
                //@ts-ignore
                await applyActiveEffects(data.activate, data.targets, data.activeEffects);
                //@ts-ignore
                // this.chatEffects(requester, actorId, itemData, [tokenId], game.i18n.localize("dae.applyingEffects"), data.whisper)
                break;
            case this.actions.recreateToken:
                //@ts-ignore
                await recreateToken(requester, data);
                break;
            case this.actions.createToken:
                //@ts-ignore
                await createToken(requester, data);
                break;
            case this.actions.deleteToken:
                //@ts-ignore
                await deleteToken(requester, data);
                break;
            case this.actions.blindToken:
                //@ts-ignore
                scene = game.scenes.get(data.sceneId);
                await scene.updateEmbeddedEntity("Token", { "_id": tokenId, vision: false });
                break;
            case this.actions.restoreVision:
                //@ts-ignore
                scene = game.scenes.get(data.sceneId);
                await scene.updateEmbeddedEntity("Token", { "_id": tokenId, vision: true });
                break;
            case this.actions.renameToken:
                //@ts-ignore
                canvas.tokens.placeables.find(t => t.id === data.tokenData._id).update({ "name": data.newName });
                break;
            case this.actions.applyTokenMagic:
                //@ts-ignore
                await applyTokenMagic(data.tokenId, data.effectId, data.duration);
                break;
            default:
                console.warn("dae invalid message received", action, data);
        }
    }
}
GMAction.actions = {
    test: "testMessage",
    setTokenVisibility: "setTokenVisibility",
    setTileVisibility: "setTileVisibility",
    blindToken: "blindToken",
    restoreVision: "restoreVision",
    recreateToken: "recreateToken",
    createToken: "createToken",
    deleteToken: "deleteToken",
    renameToken: "renameToken",
    moveToken: "moveToken",
    applyTokenMagic: "applyTokenMagic",
    applyActiveEffects: "applyActiveEffects"
};
GMAction.actionQueue = [];
GMAction.processingActions = false;
GMAction._moduleSocket = "module.dae";
GMAction.chatEffects = (userId, actorId, itemData, tokenList, flavor, whisper) => {
    let names = tokenList.filter(tid => canvas.tokens.get(tid)).map(tid => canvas.tokens.get(tid).name);
    if (names.length > 0) {
        let chatData = {
            user: game.users.get(userId),
            speaker: { actor: game.actors.get(actorId) },
            content: `${flavor} (${itemData.name}): ${names}`,
            type: CONST.CHAT_MESSAGE_TYPES.OTHER,
            flags: {}
        };
        //@ts-ignore
        if (whisper)
            chatData.whisper = ChatMessage.getWhisperRecipients("GM");
        ChatMessage.create(chatData);
    }
};
// delete a token from the specified scene and recreate it on the target scene.
let recreateToken = async (userId, data) => {
    createToken(userId, data);
    deleteToken(userId, data);
    return;
};
// delete a token from the specified scene and recreate it on the target scene.
let deleteToken = async (userId, data) => {
    //@ts-ignore
    let scenes = game.scenes;
    let startScene = scenes.get(data.startSceneId);
    //@ts-ignore
    await startScene.deleteEmbeddedEntity("Token", data.tokenData._id);
};
// delete a token from the specified scene and recreate it on the target scene.
let createToken = async (userId, data) => {
    //@ts-ignore
    let scenes = game.scenes;
    let targetScene = scenes.get(data.targetSceneId);
    return await targetScene.createEmbeddedEntity('Token', mergeObject(duplicate(data.tokenData), { "x": data.x, "y": data.y, hidden: false }, { overwrite: true, inplace: true }));
};
//Set the hidden status for a token.
let setTokenVisibility = async (userId, data) => {
    if (!data.targetSceneId || !data.tokenId)
        return;
    //@ts-ignore
    let scene = game.scenes.get(data.targetSceneId);
    await scene.updateEmbeddedEntity("Token", { "_id": data.tokenId, "hidden": data.hidden });
    return "token visibility complete";
};
// Set the hidden staturs for a tile
let setTileVisibility = async (userId, data) => {
    if (!data.targetSceneId || !data.tileId)
        return;
    //@ts-ignore
    let scene = game.scenes.get(data.targetSceneId);
    return await scene.updateEmbeddedEntity("Tile", { "_id": data.tileId, "hidden": data.hidden });
};
let applyTokenMagic = async (tokenId, effectId, duration) => {
    let token = canvas.tokens.get(tokenId);
    //@ts-ignore
    let tokenMagic = window.TokenMagic;
    if (tokenMagic && token) {
        tokenMagic.addFilters(token, effectId);
    }
    else {
        console.log(`dae | Something went wrong with finding effect ${effectId} or the duration ${duration}`);
    }
};
async function applyActiveEffects(activate, tokenList, activeEffects) {
    warn("gmaction apply effect ", activate, tokenList, duplicate(activeEffects));
    console.warn("gmaction apply effect ", activate, tokenList, duplicate(activeEffects));
    tokenList.forEach(async (tid) => {
        const token = canvas.tokens.get(tid);
        console.warn("GMAction token is ", token);
        if (token) {
            let actEffects = duplicate(activeEffects);
            let removeList = [];
            // TODO redo this as a reduce
            actEffects.forEach(newAE => {
                removeList = removeList.concat(token.actor.effects.filter(ae => ae.data.origin === newAE.origin && getProperty(ae.data.flags, "dae.transfer") === false));
            });
            removeList = removeList.map(ae => ae.data._id);
            await token.actor.deleteEmbeddedEntity("ActiveEffect", removeList);
            // token.actor.deleteEmbeddedEntity("ActiveEffect", activeEffects)
            if (activate) {
                actEffects.forEach(ae => {
                    warn("Apply active effects ", ae);
                    setProperty(ae.flags, "dae.transfer", false);
                    ae.changes.forEach(change => {
                        if (["macro.execute", "macro.itemMacro"].includes(change.key)) {
                            change.value = change.value.map(f => f === "@target" ? tid : f);
                        }
                    });
                    setProperty(ae, "flags.dae.token", tid);
                });
                await token.actor.createEmbeddedEntity("ActiveEffect", actEffects);
            }
        }
        ;
    });
}
