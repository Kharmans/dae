import { requestGMAction, GMAction } from "./GMAction.js";
import { debug, setDebugLevel } from "../dae.js";
import { initSheetTab } from "./daeTab.js";
export let _characterSpec = { data: {}, flags: {} };
let templates = {};
export var aboutTimeInstalled = false;
export var requireItemTarget = true;
export var playersCanSeeEffects = "view";
export var tokenEffects = false;
export var cubActive;
export var itemacroActive;
export var calculateArmor;
export var debugEnabled;
let debugLog = true;
let acAffectingArmorTypes = [];
export class ValidSpec {
    constructor(fs, sv, forcedMode = -1) {
        this._fieldSpec = fs;
        this._sampleValue = sv;
        this._label = fs;
        this._forcedMode = forcedMode;
    }
    get fieldSpec() { return this._fieldSpec; }
    ;
    set fieldSpec(spec) { this._fieldSpec = spec; }
    get sampleValue() { return this._sampleValue; }
    set sampleValue(value) { this._sampleValue = value; }
    get label() { return this._label; }
    set label(label) { this._label = label; }
    get forcedMode() { return this._forcedMode; }
    set forcedMode(mode) { this._forcedMode = mode; }
    static createValidMods(characterSpec = game.system.model.Actor.character) {
        var _a, _b;
        _characterSpec["data"] = duplicate(characterSpec);
        let baseValues = flattenObject(_characterSpec);
        //@ts-ignore
        if ((_a = game.modules.get("gm-notes")) === null || _a === void 0 ? void 0 : _a.active) {
            baseValues["flags.gm-notes.notes"] = "";
        }
        //@ts-ignore
        const ACTIVE_EFFECT_MODES = CONST.ACTIVE_EFFECT_MODES;
        if (game.system.id === "dnd5e") {
            var specials = {
                //@ts-ignore - come back to this
                "flags.dnd5e.initiativeHalfProf": [false, ACTIVE_EFFECT_MODES.OVERRIDE],
                "flags.dnd5e.weaponCriticalThreshold": [20, -1],
                "data.attributes.ac.value": [0, -1],
                "data.attributes.ac.min": [0, -1],
                "data.attributes.hp.max": [0, -1],
                "data.attributes.hp.tempmax": [0, -1],
                "data.attributes.hp.min": [0, -1],
                "data.attributes.init.total": [0, -1],
                "data.attributes.hd": [0, -1],
                "data.attributes.prof": [0, -1],
                "data.attributes.spelldc": [0, -1],
                "data.attributes.encumbrance.max": [0, -1],
                // "data.attributes.spelllevel":  0,
                // "skills.all": [false, ACTIVE_EFFECT_MODES.CUSTOM],
                "macro.execute": ["", ACTIVE_EFFECT_MODES.CUSTOM],
                "macro.itemMacro": ["", ACTIVE_EFFECT_MODES.CUSTOM],
                "macro..tokenMagic": ["", ACTIVE_EFFECT_MODES.CUSTOM],
                "data.bonuses.All-Attacks": ["", ACTIVE_EFFECT_MODES.CUSTOM],
                "data.bonuses.weapon.damage": ["", ACTIVE_EFFECT_MODES.CUSTOM],
                "data.bonuses.spell.damage": ["", ACTIVE_EFFECT_MODES.CUSTOM],
                "data.traits.languages.all": [false, ACTIVE_EFFECT_MODES.CUSTOM],
                "data.traits.languages.value": ["", ACTIVE_EFFECT_MODES.CUSTOM],
                "data.traits.languages.custom": ["", ACTIVE_EFFECT_MODES.CUSTOM],
                "data.traits.di.all": [false, ACTIVE_EFFECT_MODES.CUSTOM],
                "data.traits.di.value": ["", ACTIVE_EFFECT_MODES.CUSTOM],
                "data.traits.di.custom": ["", ACTIVE_EFFECT_MODES.CUSTOM],
                "data.traits.dr.all": [false, ACTIVE_EFFECT_MODES.CUSTOM],
                "data.traits.dr.value": ["", ACTIVE_EFFECT_MODES.CUSTOM],
                "data.traits.dr.custom": ["", ACTIVE_EFFECT_MODES.CUSTOM],
                "data.traits.dv.all": [false, ACTIVE_EFFECT_MODES.CUSTOM],
                "data.traits.dv.value": ["", ACTIVE_EFFECT_MODES.CUSTOM],
                "data.traits.dv.custom": ["", ACTIVE_EFFECT_MODES.CUSTOM],
                "data.traits.ci.all": [false, ACTIVE_EFFECT_MODES.CUSTOM],
                "data.traits.ci.value": ["", ACTIVE_EFFECT_MODES.CUSTOM],
                "data.traits.ci.custom": ["", ACTIVE_EFFECT_MODES.CUSTOM],
                "data.traits.toolProf.all": [false, ACTIVE_EFFECT_MODES.CUSTOM],
                "data.traits.toolProf.value": [false, ACTIVE_EFFECT_MODES.CUSTOM],
                "data.traits.toolProf.custom": [false, ACTIVE_EFFECT_MODES.CUSTOM],
                "data.traits.armorProf.all": [false, ACTIVE_EFFECT_MODES.CUSTOM],
                "data.traits.armorProf.value": [false, ACTIVE_EFFECT_MODES.CUSTOM],
                "data.traits.armorProf.custom": [false, ACTIVE_EFFECT_MODES.CUSTOM],
                "data.traits.weaponProf.all": [false, ACTIVE_EFFECT_MODES.CUSTOM],
                "data.traits.weaponProf.value": [false, ACTIVE_EFFECT_MODES.CUSTOM],
                "data.traits.weaponProf.custom": [false, ACTIVE_EFFECT_MODES.CUSTOM],
                "data.resources.primary.max": [0, -1],
                "data.resources.primary.label": ["", ACTIVE_EFFECT_MODES.OVERRIDE],
                "data.resources.secondary.max": [0, -1],
                "data.resources.secondary.label": ["", ACTIVE_EFFECT_MODES.OVERRIDE],
                "data.resources.tertiary.max": [0, -1],
                "data.resources.tertiary.label": ["", ACTIVE_EFFECT_MODES.OVERRIDE],
                "data.resources.legact.max": [0, -1],
                "data.resources.legres.max": [0, -1],
                "data.spells.pact.level": [0, -1],
                "data.bonuses.spell.dc": [0, -1],
                "flags.dnd5e.conditions": [false, ACTIVE_EFFECT_MODES.CUSTOM],
                "flags.dnd5e.forceCritical": [false, ACTIVE_EFFECT_MODES.CUSTOM],
            };
            // move all the characteer flags to specials so that the can be custom effects only
            Object.keys(CONFIG.DND5E.characterFlags).forEach(key => {
                let theKey = `flags.dnd5e.${key}`;
                if (key === "flags.dnd5E.weaponCriticalThreshold")
                    specials[theKey] = [0, -1];
                else
                    specials[theKey] = [false, ACTIVE_EFFECT_MODES.CUSTOM];
                delete baseValues[theKey];
            });
            // patch for missing fields
            baseValues["data.bonuses.heal.damage"] = "";
            baseValues["data.bonuses.heal.attack"] = "";
            Object.keys(baseValues).forEach(key => {
                // can't modify all spell details.
                if (key.includes("data.spells")) {
                    delete baseValues[key];
                }
                if (key.includes("data.spells") && key.includes("orerride"))
                    specials[key] = [0, -1];
                if (key.includes("data.spells") && key.includes("max"))
                    specials[key] = [0, -1];
            });
            Object.keys(specials).forEach(key => {
                delete baseValues[key];
            });
        }
        // baseSpecs are all those fields defined in template.json game.system.model and are things the user can directly change
        this.baseSpecs = Object.keys(baseValues).map(spec => {
            let validSpec = new ValidSpec(spec, baseValues[spec], -1);
            this.baseSpecsObj[spec] = validSpec;
            return validSpec;
        });
        //@ts-ignore
        if ((_b = game.modules.get("tokenmagic")) === null || _b === void 0 ? void 0 : _b.active) {
            specials["macro.tokenMagic"] = ["", ACTIVE_EFFECT_MODES.CUSTOM];
        }
        // Do the system specific part
        if (game.system.id === "dnd5e") {
            // 1. abilities add mod and save to each;
            Object.keys(_characterSpec.data.abilities).forEach(ablKey => {
                let abl = _characterSpec.data.abilities[ablKey];
                this.derivedSpecs.push(new ValidSpec(`data.abilities.${ablKey}.mod`, 0));
                this.derivedSpecs.push(new ValidSpec(`data.abilities.${ablKey}.save`, 0));
                this.derivedSpecs.push(new ValidSpec(`data.abilities.${ablKey}.min`, 0));
            });
            // adjust specs for bonuses - these are strings, @fields are looked up but dice are not rolled.
            // Skills add mod, passive and bonus fields
            Object.keys(_characterSpec.data.skills).forEach(sklKey => {
                let skl = _characterSpec.data.skills[sklKey];
                this.derivedSpecs.push(new ValidSpec(`data.skills.${sklKey}.mod`, 0));
                this.derivedSpecs.push(new ValidSpec(`data.skills.${sklKey}.passive`, 0));
            });
            Object.entries(specials).forEach(special => {
                let validSpec = new ValidSpec(special[0], special[1][0], special[1][1]);
                this.derivedSpecs.push(validSpec);
            });
            this.allSpecs = this.baseSpecs.concat(this.derivedSpecs);
            if (game.system.id === "dnd5e") {
                // Special case for armor/hp which can depend on derived attributes - like dexterity mod or constituion mod
                // and initiative bonus depends on advantage on initiative
                this.allSpecs.forEach(m => {
                    if (["attributes.hp", "attributes.ac"].includes(m._fieldSpec)) {
                        m._sampleValue = 0;
                    }
                });
            }
            this.allSpecs.sort((a, b) => { return a._fieldSpec < b._fieldSpec ? -1 : 1; });
            this.baseSpecs.sort((a, b) => { return a._fieldSpec < b._fieldSpec ? -1 : 1; });
            this.derivedSpecs.sort((a, b) => { return a._fieldSpec < b._fieldSpec ? -1 : 1; });
            this.allSpecs.forEach(ms => this.allSpecsObj[ms._fieldSpec] = ms);
            this.baseSpecs.forEach(ms => this.baseSpecsObj[ms._fieldSpec] = ms);
            this.derivedSpecs.forEach(ms => this.derivedSpecsObj[ms._fieldSpec] = ms);
        }
    }
    static localizeSpecs() {
        this.allSpecs = this.allSpecs.map(m => {
            m._label = m._label.replace("data.", "").replace("dnd5e.", "").replace(".value", "").split(".").map(str => game.i18n.localize(`dae.${str}`)).join(" ");
            return m;
        });
    }
}
ValidSpec.allSpecs = [];
ValidSpec.allSpecsObj = {};
ValidSpec.baseSpecs = [];
ValidSpec.derivedSpecsObj = {};
ValidSpec.baseSpecsObj = {};
ValidSpec.derivedSpecs = [];
// Is the item disalbed?
export function isDisabled(itemData) {
    var _a;
    // Get the dae flags from the item.
    const daeFlags = (_a = itemData.flags) === null || _a === void 0 ? void 0 : _a.dae;
    if (!daeFlags)
        return true;
    let active = daeFlags.alwaysActive
        || (daeFlags.activeEquipped && itemData.data.equipped)
        || (itemData.data.attuned && itemData.data.equipped);
    debug("is disabled returning ", !active, daeFlags);
    return !active;
}
var oldPrepareData;
/*
 * Replace default appplyAffects to do value lookups
 */
function applyDaeEffects(specList) {
    const overrides = {};
    if (this.effects.size === 0)
        return this.overrides;
    const rollData = daeRollData(this);
    // Organize non-disabled effects by their application priority
    const changes = this.effects.reduce((changes, e) => {
        var _a, _b, _c;
        let id = (_a = e.data.origin) === null || _a === void 0 ? void 0 : _a.match(/Actor.*Item\.(.*)/);
        if ((id === null || id === void 0 ? void 0 : id.length) === 2) {
            var item = e.parent.items.get(id[1]);
        }
        // override default disabled behaviour to use item settings to toggle
        e.data.disabled = (item && isDisabled(item.data) && ((_c = (_b = e.data.flags) === null || _b === void 0 ? void 0 : _b.dae) === null || _c === void 0 ? void 0 : _c.transfer) !== false) || false;
        if (e.data.disabled)
            return changes;
        return changes.concat(e.data.changes
            .filter(c => { return specList[c.key] !== undefined; })
            .map(c => {
            var _a;
            c = duplicate(c);
            if (typeof specList[c.key].sampleValue === "number" && typeof c.value === "string") {
                debug("appplyDaeEffects: Doing eval of ", c, c.value);
                try {
                    c.value = new Roll(c.value, rollData).roll().total;
                }
                catch (err) {
                    console.warn(err);
                }
                ;
            }
            c.effect = e;
            c.priority = (_a = c.priority) !== null && _a !== void 0 ? _a : (c.mode * 10);
            return c;
        }));
    }, []);
    changes.sort((a, b) => a.priority - b.priority);
    // Apply all changes
    for (let change of changes) {
        const result = change.effect.apply(this, change);
        if (result !== null)
            overrides[change.key] = result;
    }
    // Expand the set of final overrides
    this.overrides = mergeObject(this.overrides || {}, expandObject(overrides) || {}, { inplace: true, overwrite: true });
}
/*
 * do custom effect applications
 * damage resistance/immunity/vulnerabilities
 * languages
 */
function daeCustomEffect(actor, change) {
    const current = getProperty(actor.data, change.key);
    var validValues;
    var value;
    switch (change.key) {
        case "data.traits.di.all":
        case "data.traits.dr.all":
        case "data.traits.dv.all":
            const key = change.key.replace(".all", ".value");
            setProperty(actor.data, key, Object.keys(CONFIG.DND5E.damageResistanceTypes));
            return true;
        case "data.traits.di.value":
        case "data.traits.dr.value":
        case "data.traits.dv.value":
            return doCustomValue(actor, current, change, Object.keys(CONFIG.DND5E.damageResistanceTypes));
        case "data.traits.di.custom":
        case "data.traits.dr.custom":
        case "data.traits.dv.custom":
        case "data.traits.ci.custom":
        case "data.traits.languages.custom":
        case "data.traits.toolProf.custom":
        case "data.traits.armorProf.custom":
        case "data.traits.weaponProf.custom":
            value = current.concat(current.length === 0 ? `${change.value}` : `; ${change.value}`);
            setProperty(actor.data, change.key, value);
            return true;
        case "data.traits.languages.all":
            setProperty(actor.data, "data.traits.languages.value", Object.keys(CONFIG.DND5E.languages));
            return true;
        case "data.traits.languages.value":
            return doCustomValue(actor, current, change, Object.keys(CONFIG.DND5E.languages));
        case "data.traits.ci.all":
            setProperty(actor.data, "data.traits.ci.value", Object.keys(CONFIG.DND5E.conditionTypes));
            return true;
        case "data.traits.ci.value":
            return doCustomValue(actor, current, change, Object.keys(CONFIG.DND5E.conditionTypes));
        case "data.traits.toolProf.value":
            return doCustomValue(actor, current, change, Object.keys(CONFIG.DND5E.toolProficiencies));
        case "data.traits.toolProf.all":
            setProperty(actor.data, "data.traits.toolProf.value", Object.keys(CONFIG.DND5E.toolProficiencies));
            return true;
        case "data.traits.armorProf.value":
            return doCustomValue(actor, current, change, Object.keys(CONFIG.DND5E.armorProficiencies));
        case "data.traits.armorProf.all":
            setProperty(actor.data, "data.traits.armorProf.value", Object.keys(CONFIG.DND5E.armorProficiencies));
            return true;
        case "data.traits.weaponProf.value":
            return doCustomValue(actor, current, change, Object.keys(CONFIG.DND5E.weaponProficiencies));
        case "data.traits.weaponProf.all":
            setProperty(actor.data, "data.traits.weaponProf.value", Object.keys(CONFIG.DND5E.weaponProficiencies));
            return true;
        case "data.bonuses.All-Attacks":
            value = (change.value.startsWith("+") || change.value.startsWith("-")) ? change.value : "+" + change.value;
            ["mwak", "rwak", "msak", "rsak"].forEach(atType => actor.data.data.bonuses[atType].attack += value);
            return true;
        case "data.bonuses.weapon.damage":
            value = (change.value.startsWith("+") || change.value.startsWith("-")) ? change.value : "+" + change.value;
            ["mwak", "rwak"].forEach(atType => actor.data.data.bonuses[atType].damage += value);
            return true;
        case "data.bonuses.spell.damage":
            value = (change.value.startsWith("+") || change.value.startsWith("-")) ? change.value : "+" + change.value;
            ["msak", "rsak"].forEach(atType => actor.data.data.bonuses[atType].damage += value);
            return true;
    }
}
function doCustomValue(actor, current, change, validValues) {
    if (current.includes(change.value))
        return true;
    if (!validValues.includes(change.value))
        return true;
    setProperty(actor.data, change.key, current.concat([change.value]));
    return true;
}
/*
* replace the default actor prepareData
* call applyDaeEffects
* add an additional pass after derivfed data
*/
function prepareData() {
    this.data = duplicate(this._data);
    debug("prepare data: before passes", this.data);
    if (!this.data.img)
        this.data.img = CONST.DEFAULT_TOKEN;
    if (!this.data.name)
        this.data.name = "New " + this.entity;
    this.prepareBaseData();
    this.prepareEmbeddedEntities();
    applyDaeEffects.bind(this)(ValidSpec.baseSpecsObj);
    this.prepareDerivedData();
    applyDaeEffects.bind(this)(ValidSpec.derivedSpecsObj);
    debug("prepare data: after passes", this.data);
}
export function daeCheckMacro(...args) {
    // conisder toggling according to item isactive
}
export function daeOnMacro(actor, effect) {
    debug("daeOnMacro", actor, effect);
    return daeMacro(true, actor, effect);
}
export function daeOffMacro(actor, effect) {
    debug("daeOffMacro", actor, effect);
    return daeMacro(false, actor, effect);
}
async function daeMacro(enable, actor, effect) {
    var _a;
    if (actor.__proto__.constructor.name !== CONFIG.Actor.entityClass.name)
        return;
    debug("dae macro ", enable, actor, effect);
    (_a = effect.changes) === null || _a === void 0 ? void 0 : _a.forEach(async (change) => {
        var _a;
        if (!["macro.execute", "macro.itemMacro"].includes(change.key))
            return;
        if (typeof change.value === "string") { //args have not been evaled yet
            let rollData = daeRollData(actor);
            let id = (_a = effect.origin) === null || _a === void 0 ? void 0 : _a.match(/Actor.*Item\.(.*)/);
            if ((id === null || id === void 0 ? void 0 : id.length) === 2) {
                const item = actor.items.get(id[1]);
                change.value = evalArgs.bind(item)(rollData, actor, change, 0, 0);
            }
        }
        if (change.key === "macro.execute") {
            const macro = game.macros.getName(change.value[0]);
            //@ts-ignore
            await macro.execute(enable ? "on" : "off", ...duplicate(change.value).splice(1));
        }
        else if (change.key === "macro.itemMacro") {
            let macroCommand = change.value[0]; // this is populated in evalArgs
            // macroCommand = `ChatMessage.create({content: "Item macro for ${itemData.name} called"})\n` + macroCommand;
            if (!macroCommand) {
                macroCommand = `ChatMessage.create({content: "No Item Macro for ${this.name}"})`;
                return;
            }
            let macro = await CONFIG.Macro.entityClass.create({
                name: "DAE-Item-Macro",
                type: "script",
                img: null,
                command: macroCommand,
                flags: { "dnd5e.itemMacro": true }
            }, { displaySheet: false, temporary: true });
            await macro.execute(enable ? "on" : "off", ...duplicate(change.value).splice(1));
        }
    });
    return true;
}
function daeCheckTokenMagic(...args) {
    //consider toggling according to isactive
}
function daeOnTokenMagic(actor, effect) {
    // TODO: Check item active to see whether enable or disable
    daeTokenMagic(true, actor, effect);
}
;
function daeOffTokenMagic(actor, effect) { daeTokenMagic(false, actor, effect); }
function daeTokenMagic(enable, actor, effect) {
    var _a;
    // TODO lookup enabled from the item.isActive
    if (actor.__proto__.constructor.name !== CONFIG.Actor.entityClass.name)
        return;
    debug("dae token magic ", actor, effect, enable);
    (_a = effect.changes) === null || _a === void 0 ? void 0 : _a.forEach(change => {
        if (change.key === "macro.tokenMagic") {
            // get the token id from the effect
            let tokenId = getProperty(effect, "flags.dae.token");
            if (!tokenId)
                tokenId = ChatMessage.getSpeaker().token;
            let token = canvas.tokens.get(tokenId);
            //@ts-ignore
            let tokenMagic = window.TokenMagic;
            if (tokenMagic && token && enable) {
                tokenMagic.addFilters(token, change.value);
            }
            else if (tokenMagic && token && !enable) {
                tokenMagic.deleteFilters(token, change.value);
            }
        }
    });
}
function daeRollData(actor) {
    let rollData = actor.getRollData();
    rollData.data = rollData;
    rollData.flags = actor.flags;
    return rollData;
}
function evalArgs(context, actor, change, spellLevel, damageTotal) {
    var _a, _b, _c, _d, _e;
    //@ts-ignore
    let filteredChanges = [];
    //@ts-ignore effects not defined
    let fields = [];
    let value;
    switch (change.key) {
        case "macro.itemMacro":
        case "macro.execute":
            tokenizer.tokenize(change.value, (token) => fields.push(token));
            fields = fields.map(f => {
                if (f === "@scene")
                    return canvas.scene.id;
                else if (f === "@token")
                    return ChatMessage.getSpeaker().token;
                else if (f === "@item")
                    return this.data;
                else if (f === "@spellLevel")
                    return spellLevel;
                else if (f === "@item.level")
                    return spellLevel;
                else if (f === "@damage")
                    return damageTotal;
                else if (f === "@target")
                    return "@target";
                else if (f === "@unique")
                    return randomID();
                else if (f.startsWith("@")) {
                    return getProperty(context, f.slice(1));
                }
                else
                    return f;
            });
            if (change.key === "macro.itemMacro") {
                let macroCommand = ((_d = (_c = (_b = (_a = this === null || this === void 0 ? void 0 : this.data) === null || _a === void 0 ? void 0 : _a.flags) === null || _b === void 0 ? void 0 : _b.itemacro) === null || _c === void 0 ? void 0 : _c.macro) === null || _d === void 0 ? void 0 : _d.data.command) || 'console.warn("No macro defined for item")';
                value = [macroCommand].concat(fields);
            }
            else
                value = fields;
            break;
        default:
            if (typeof ((_e = ValidSpec[change.key]) === null || _e === void 0 ? void 0 : _e.sampleValue) === "number")
                value = new Roll(change.value, context).roll().total;
            else
                value = change.value;
            break;
    }
    ;
    debug("evalargs: change is ", change);
    return value;
}
/*
 * appply non-transfer effects to target tokens
 */
export function doEffects(item, activate, targets = undefined, { whisper = false, spellLevel = 0, damageTotal = null }) {
    applyNonTransferEffects.bind(item)(activate, targets, { whisper, spellLevel, damageTotal });
}
export function applyNonTransferEffects(activate, targets, { whisper = false, spellLevel = 0, damageTotal = null }) {
    if (!targets)
        return;
    let appliedEffects = duplicate(this.data.effects.filter(aeData => aeData.transfer === false));
    if (appliedEffects.length === 0)
        return;
    const rollData = daeRollData(this.actor);
    appliedEffects.forEach(activeEffectData => {
        activeEffectData.changes.forEach(change => {
            // eval args before calling GMAction so values are taken from the casting etc actor.
            change.value = evalArgs.bind(this)(rollData, this.actor, change, spellLevel, damageTotal);
        });
        activeEffectData.origin = `Actor.${this.actor.id}.OwnedItem.${this.id}`;
        activeEffectData.duration.startTime = game.time.worldTime;
        mergeObject(activeEffectData.duration, mapDuration(this), { overwrite: true, inplace: true });
        console.warn("duration calc is ", activeEffectData.duration, mapDuration(this));
        activeEffectData.transfer = false;
        activeEffectData.disabled = false;
        //@ts-ignore
        targets = Array.from(targets).map(t => typeof t === "string" ? t : t.id);
    });
    debug("About to call gmaction ", activate, appliedEffects, targets);
    requestGMAction(GMAction.actions.applyActiveEffects, { activate, activeEffects: appliedEffects, targets });
}
function ownedItemUpdate(actor, ownedItem, updates) {
    var _a;
    let deletions = [];
    let additions = ((_a = updates.effects) === null || _a === void 0 ? void 0 : _a.filter(ef => ef.transfer)) || [];
    let origin = `Actor.${actor.id}.OwnedItem.${ownedItem._id}`;
    ownedItem.effects.forEach(ef => {
        if (ef.transfer) { // need to update owned effects
            let match = actor.effects.filter(aef => {
                var _a;
                // warn("matching",  aef.data.flags.dae?.transfer, aef.data.origin, origin, ef, aef)
                return ((_a = aef.data.flags.dae) === null || _a === void 0 ? void 0 : _a.transfer) && (aef.data.origin === origin);
            });
            if (match.length > 0) {
                deletions = deletions.concat(match.map(ef => ef.id || ef._id));
            }
        }
    });
    additions.forEach(efData => efData.origin = `Actor.${actor.id}.OwnedItem.${updates._id}`);
    // warn("owneditemupdate ", additions, deletions)
    Hooks.once("updateOwnedItem", () => {
        actor.deleteEmbeddedEntity("ActiveEffect", deletions);
        actor.createEmbeddedEntity("ActiveEffect", additions);
    });
    return true;
}
// How to do armor effects
/* Create a single actor effect with each of the item fields in it - updated when armor is equipeed/unequipped?
*/
/*
let addArmorEffect = (itemData, effectList, actor) => {
  // Special case for armor
  if (itemData.data.hasOwnProperty("armor") && hasProperty(actor.data, "data.abilities.dex")
    && acAffectingArmorTypes.includes(itemData.data.armor.type)
    && (itemData.data.equipped || itemData.data.armor.type === "natural")
  ) {
    let acValue = itemData.data.armor.value || 0;
    if (!["shield", "bonus"].includes(itemData.data.armor.type)) {
      let dexMod = itemData.data.armor.dex === 0 ? 0 : actor.data.data.abilities.dex.mod || 0;
      acValue = acValue + ([null, "", undefined].includes(itemData.data.armor.dex) ? dexMod : Math.min(itemData.data.armor.dex, dexMod));
    }
    if (itemData.data.armor.value !== 0) effectList.push(new EffectModifier("data.attributes.ac.value", ["shield", "bonus"].includes(itemData.data.armor.type) ? "+" : "=", acValue))
  }
}
*/
export function daeReadyActions() {
    var _a;
    ValidSpec.localizeSpecs();
    initSheetTab();
    //@ts-ignore
    aboutTimeInstalled = (_a = game.modules.get("about-time")) === null || _a === void 0 ? void 0 : _a.active;
}
export function localDeleteFilters(tokenId, filterName) {
    //@ts-ignore
    let tokenMagic = window.TokenMagic;
    let token = canvas.tokens.get(tokenId);
    tokenMagic.deleteFilters(token, filterName);
}
export var tokenizer;
export function daeInitActions() {
    if (game.system.id === "dnd5e") {
        acAffectingArmorTypes = ["light", "medium", "heavy", "bonus", "natural", "shield"];
    }
    fetchParams();
    ValidSpec.createValidMods();
    oldPrepareData = CONFIG.Actor.entityClass.prototype.prepareData;
    CONFIG.Actor.entityClass.prototype.prepareData = prepareData;
    Hooks.on("applyActiveEffect", daeCustomEffect); // apply DAE custom effects
    Hooks.on("preUpdateOwnedItem", ownedItemUpdate);
    // macros are called on active effect creationg and deletion
    Hooks.on("preCreateActiveEffect", daeOnMacro);
    Hooks.on("preDeleteActiveEffect", daeOffMacro);
    // Hooks.on("preUpdateOwnedItem", daeCheckMacro)
    // token magic effects are apllied/removed on active effect creation/deletion
    Hooks.on("preCreateActiveEffect", daeOnTokenMagic);
    Hooks.on("preDeleteActiveEffect", daeOffTokenMagic);
    // Hooks.on("preUpdateOwnedItem", daeCheckTokenMagic)
    //@ts-ignore
    tokenizer = new DETokenizeThis({
        shouldTokenize: ['(', ')', ',', '*', '/', '%', '+', '=', '!=', '!', '<', '> ', '<=', '>=', '^']
    });
}
export function daeSetupActions() {
    var _a, _b, _c, _d;
    //@ts-ignore
    cubActive = (_a = game.modules.get("combat-utility-belt")) === null || _a === void 0 ? void 0 : _a.active;
    //@ts-ignore
    debug("Combat utility belt active ", cubActive, " and cub version is ", (_b = game.modules.get("combat-utility-belt")) === null || _b === void 0 ? void 0 : _b.data.version);
    //@ts-ignore
    if (cubActive && !isNewerVersion((_c = game.modules.get("combat-utility-belt")) === null || _c === void 0 ? void 0 : _c.data.version, "1.1.1")) {
        ui.notifications.warn("Combat Utility Belt needs to be version 1.1.2 or later - conditions disabled");
        console.warn("Combat Utility Belt needs to be version 1.1.2 or later - conditions disabled");
        cubActive = false;
    }
    else if (cubActive) {
        debug("dae | Combat Utility Belt active and conditions enabled");
    }
    //@ts-ignore
    itemacroActive = (_d = game.modules.get("itemacro")) === null || _d === void 0 ? void 0 : _d.active;
}
export function fetchParams() {
    requireItemTarget = game.settings.get("dae", "requireItemTarget");
    playersCanSeeEffects = game.settings.get("dae", "playersCanSeeEffects");
    tokenEffects = game.settings.get("dae", "tokenEffects");
    calculateArmor = game.settings.get("dae", "calculateArmor");
    debugEnabled = setDebugLevel(game.settings.get("dae", "Debug"));
}
export function mapDuration(item) {
    console.warn("item duration is ", item);
    if (!item.data.data.duration)
        return null;
    const itemData = item.data;
    let aboutTime = false;
    if (!aboutTime) {
        switch (itemData.data.duration.units) {
            case "turn": return { turns: itemData.data.duration.value };
            case "round": return { rounds: itemData.data.duration.value };
            case "minute": return { rounds: itemData.data.duration.value * 60 / CONFIG.time.roundTime };
            case "hour": return { seconds: itemData.data.duration.value * 3600 };
            case "day": return { sconds: itemData.data.duration.value * 3600 * 24 };
            case "week": return { sconds: itemData.data.duration.value * 3600 * 7 };
            case "month": return { seconds: itemData.data.duration.value * 3600 * 7 * 30 };
            case "year": return { seconds: itemData.data.duration.value * 3600 * 7 * 365 };
        }
    }
    else {
        // do about time stuff
    }
}
