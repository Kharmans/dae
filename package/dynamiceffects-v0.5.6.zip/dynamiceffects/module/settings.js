import { fetchParams } from "./dynamiceffects.js";
export const registerSettings = function () {
    game.settings.register("dynamiceffects", "ConsumeCharge", {
        name: game.i18n.localize("dynamiceffects.ConsumeCharge.Name"),
        hint: game.i18n.localize("dynamiceffects.ConsumeCharge.Hint"),
        scope: "world",
        default: true,
        config: true,
        type: Boolean
    });
    game.settings.register("dynamiceffects", "requireItemTarget", {
        name: game.i18n.localize("dynamiceffects.requireItemTarget.Name"),
        hint: game.i18n.localize("dynamiceffects.requireItemTarget.Hint"),
        scope: "world",
        default: true,
        config: true,
        type: Boolean,
        onChange: fetchParams
    });
    game.settings.register("dynamiceffects", "playersCanSeeEffects", {
        name: game.i18n.localize("dynamiceffects.playersCanSeeEffects.Name"),
        hint: game.i18n.localize("dynamiceffects.playersCanSeeEffects.Hint"),
        scope: "world",
        default: true,
        config: true,
        type: Boolean,
        onChange: fetchParams
    });
};
