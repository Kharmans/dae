import { activateItemEffectsForActor, activateItemEffectsForToken, activateItemEffectsForTargets, removeAllItemActiveEffectsTokenId, removeAllItemActiveEffectsActorId, removeAllItemActiveEffectsTargets } from "./dynamiceffects.js";
export class GMActionMessage {
    constructor(action, sender, targetGM, data) {
        this.action = action;
        this.sender = sender;
        this.targetGM = targetGM;
        this.data = data;
    }
}
export let requestGMAction = async (action, data, debugLog = false) => {
    if (game.user.isGM) {
        //@ts-ignore
        return await DynamicEffects.GMAction.processAction(action, data);
    }
    //@ts-ignore
    let intendedGM = game.users.entities.find(u => u.isGM && u.active);
    if (!intendedGM) {
        ui.notifications.error(`${game.user.name} ${game.i18n.localize("dynamiceffects.noGM")}`);
        console.error("dynamiceffects | No GM user connected - cannot do request ", action, data);
        return;
    }
    //@ts-ignore
    let message = new DynamicEffects.GMActionMessage(action, game.user.name, intendedGM.id, data);
    if (debugLog)
        console.log("About to send message", this._moduleSocket, message);
    //@ts-ignore
    game.socket.emit(DynamicEffects.GMAction._moduleSocket, message, resp => {
        if (debugLog)
            console.log("message sent");
    });
};
export class GMAction {
    static _setupSocket() {
        console.log("Setting up ", this._moduleSocket);
        //@ts-ignore
        game.socket.on(this._moduleSocket, (message) => {
            if (game.user.id !== message.targetGM)
                return;
            if (!game.user.isGM)
                return;
            this.processAction(message.action, message.data);
        });
    }
    static initActions() {
    }
    static setupActions() {
    }
    static readyActions() {
        this._setupSocket();
        requestGMAction("testMessage", game.user.name);
    }
    static async processAction(action, data) {
        var actorId;
        //@ts-ignore
        let itemData = data.itemData;
        var tokenId;
        var targetList;
        //@ts-ignore
        var requester = data.userId;
        //@ts-ignore
        var actorId = data.actorId;
        switch (action) {
            case "testMessage":
                console.log("test message received", data);
                break;
            case "updateActor":
                //@ts-ignore
                let updateData = data.data;
                let actor = game.actors.get(actorId);
                console.log("actor change ", actorId, updateData, requester);
                console.log(data);
                if (actor) {
                    await actor.update(updateData, {});
                }
                break;
            case "activateItemEffectsForTargets":
                //@ts-ignore
                targetList = data.targetList;
                await activateItemEffectsForTargets(targetList, itemData);
                this.chatEffects(requester, actorId, itemData, targetList, "Applying effects");
                break;
            case "activateItemEffectsForToken":
                //@ts-ignore
                tokenId = data.tokenId;
                await activateItemEffectsForToken(tokenId, itemData);
                this.chatEffects(requester, actorId, itemData, [tokenId], "Applying effects");
                break;
            case "activateItemEffectsForActor":
                //@ts-ignore
                await activateItemEffectsForActor(data.actorId, data.itemData);
                console.log(data);
                break;
            case "removeAllItemActiveEffectsTokenId":
                //@ts-ignore
                tokenId = data.tokenId;
                await removeAllItemActiveEffectsTokenId(tokenId, itemData);
                this.chatEffects(requester, actorId, itemData, [tokenId], "Removing effects");
                break;
            case "removeAllItemActiveEffectsActorId":
                //@ts-ignore
                await removeAllItemActiveEffectsActorId(data.actorId, data.itemData);
                break;
            case "removeAllItemActiveEffectsTargets":
                //@ts-ignore
                targetList = data.targetList;
                await removeAllItemActiveEffectsTargets(targetList, itemData);
                this.chatEffects(requester, actorId, itemData, targetList, "Removing effects");
                break;
            case "moveToken":
                //@ts-ignore
                await moveToken(requester, data);
            default:
                console.warn("dynamiceffects invalid message received", action, data);
        }
    }
}
GMAction.actions = {
    test: "testMessage",
    actorUpdate: "updateActor",
    activateItemEffectsForActor: "activateItemEffectsForActor",
    activateItemEffectsForToken: "activateItemEffectsForToken",
    activateItemEffectsForTargets: "activateItemEffectsForTargets",
    removeAllItemActiveEffectsActorId: "removeAllItemActiveEffectsActorId",
    removeAllItemActiveEffectsTokenId: "removeAllItemActiveEffectsTokenId",
    removeAllItemActiveEffectsTargets: "removeAllItemActiveEffectsTargets",
    moveToken: "moveToken"
};
GMAction._moduleSocket = "module.dynamiceffects";
GMAction.chatEffects = (userId, actorId, itemData, tokenList, flavor) => {
    let names = tokenList.map(tid => canvas.tokens.get(tid).name);
    console.log(`Dynamiceffects | ${userId} uses ${itemData.name} ${flavor} to ${names}`);
    console.log("Actor ", actorId, game.actors.get(actorId));
    console.log("User ", userId, game.users.get(userId));
    ChatMessage.create({
        user: game.users.get(userId),
        speaker: { actor: game.actors.get(actorId) },
        content: `${flavor} (${itemData.name}): ${names}`,
        type: CONST.CHAT_MESSAGE_TYPES.OTHER,
        flags: {}
    });
};
let moveToken = async (userId, data) => {
    console.log("Move token request ", userId, data);
    //@ts-ignore
    //@ts-ignore
    let scenes = game.scenes;
    let startScene = scenes.get(data.startSceneId);
    let targetScene = scenes.get(data.targetSceneId);
    console.log("scenes are ", startScene, targetScene);
    //@ts-ignore
    let currentScene = canvas.scene;
    console.log(startScene.tokens, data.tokenData);
    //@ts-ignore
    await startScene.deleteEmbeddedEntity("Token", data.tokenData._id);
    console.log(data.tokenData, mergeObject(duplicate(data.tokenData), { x: data.x, y: data.y, hidden: false }, { overwrite: true, inplace: false }));
    // for some reason does not display corretly for the user.
    // await targetScene.createEmbeddedEntity('Token', mergeObject(data.tokenData, {"x": data.x, "y": data.y, hidden: false}, {overwrite: true, inplace:true}))
};
