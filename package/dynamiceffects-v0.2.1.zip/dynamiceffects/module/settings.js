export const registerSettings = function () {
    game.settings.register("dynamiceffects", "ConsumeCharge", {
        name: "ConsumeCharge",
        hint: "ConsumeCharge",
        scope: "world",
        default: true,
        config: true,
        type: Boolean
    });
};
