export function mergeObjectLookup(original, other = {}, { insertKeys = true, insertValues = true, overwrite = true, inplace = true, enforceTypes = false, context = {}, debug = false } = {}, _d = 0) {
    other = other || {};
    if (!(original instanceof Object) || !(other instanceof Object)) {
        console.log("mergeadd", original, other);
        throw new Error("One of original or other are not Objects!");
    }
    let depth = _d + 1;
    // Maybe copy the original data at depth 0
    if (!inplace && (_d === 0))
        original = duplicate(original);
    // Enforce object expansion at depth 0
    if ((_d === 0) && Object.keys(original).some(k => /\./.test(k)))
        original = expandObject(original);
    if ((_d === 0) && Object.keys(other).some(k => /\./.test(k)))
        other = expandObject(other);
    if (debug)
        console.log("mergeadd", _d, duplicate(original), duplicate(other));
    // Iterate over the other object
    for (let [k, v] of Object.entries(other)) {
        if (debug)
            console.log("merge object loop doing ", duplicate(k), duplicate(v));
        let tv = getType(v);
        // Prepare to delete
        let toDelete = false;
        if (k.startsWith("-=")) {
            k = k.slice(2);
            toDelete = (v === null);
        }
        let toAdd = false;
        if (k.startsWith("+")) {
            if (debug)
                console.log("Found adder", k, k.slice(2));
            k = k.slice(1);
            toAdd = true;
            if (debug)
                console.log("new key is ", k);
        }
        // Get the existing object
        let x = original[k];
        let has = original.hasOwnProperty(k);
        let tx = getType(x);
        // Ensure that inner objects exist
        if (!has && (tv === "Object")) {
            x = original[k] = {};
            has = true;
            tx = "Object";
        }
        // Case 1 - Key exists
        if (has) {
            if (debug)
                console.log("Key exists ", duplicate(tv), duplicate(tx), Array.isArray(x));
            // 1.1 - Recursively merge an inner object
            if ((tv === "Object") && (tx === "Object") && !Array.isArray(x)) {
                if (debug)
                    console.log("doing recursive merge", k, v);
                mergeObjectLookup(x, v, {
                    insertKeys: insertValues,
                    insertValues: insertValues,
                    overwrite: overwrite,
                    inplace: true,
                    enforceTypes: enforceTypes,
                    context: context,
                    debug: debug
                }, depth);
            }
            // 1.2 - Remove an existing key
            else if (toDelete) {
                delete original[k];
            }
            // 1.3 - Overwrite existing value
            else if (overwrite && !toAdd) {
                if (debug)
                    console.log("Doing overwrite");
                if (tx && (tv !== tx) && enforceTypes) {
                    throw new Error(`Mismatched data types encountered during object merge.`);
                }
                original[k] = v;
            }
            // 1.4 - Insert new value
            else if ((x === undefined) && insertValues) {
                if (debug)
                    console.log("X undefined");
                original[k] = v;
            }
            else if (x !== undefined) { // append elements 
                if (Array.isArray(x)) {
                    original[k] = (toAdd ? original[k] : []).concat(v);
                    if (debug)
                        console.log("Doing array concat", duplicate(x), duplicate(v), original[k]);
                }
                else if (typeof x === "string") {
                    // Check for embedded @s in the string if so we string concatenate the lookup value or just add a string value like 1d4
                    if (typeof v === "string" && v.includes("@"))
                        v = doLookups(v, context);
                    original[k] = `${((toAdd && original[k]) ? original[k] : "")}+${v}`;
                    if (debug)
                        console.log("Doing string", duplicate(x), duplicate(v), original[k]);
                }
                else if (typeof x === "number") { // number
                    // we do a roll here as the target is a number and we need to resolve the values including rolling values
                    v = new Roll(`0+${v}`, context).roll().total;
                    original[k] = ((toAdd && original[k]) ? original[k] : 0) + Number(v);
                    if (debug)
                        console.log("Doing number", duplicate(x), duplicate(v), original[k]);
                }
            }
            // Case 2 - Key does not exist
            else if (!toDelete) {
                let canInsert = (depth === 1 && insertKeys) || (depth > 1 && insertValues);
                if (canInsert)
                    original[k] = v;
            }
        }
    }
    // Return the object for use
    return original;
}
function doLookups(v, context) {
    return v.split("+")
        .map(s => s.trim())
        .map(s => s.startsWith("@") ? (getProperty(context, s.slice(1)) || "") : s)
        .join("+");
}
export function myMergeObject(original, other = {}, { insertKeys = true, insertValues = true, overwrite = true, inplace = true, enforceTypes = false } = {}, _d = 0) {
    other = other || {};
    if (!(original instanceof Object) || !(other instanceof Object)) {
        throw new Error("One of original or other are not Objects!");
    }
    let depth = _d + 1;
    // Maybe copy the original data at depth 0
    if (!inplace && (_d === 0))
        original = duplicate(original);
    // Enforce object expansion at depth 0
    if ((_d === 0) && Object.keys(original).some(k => /\./.test(k)))
        original = expandObject(original);
    if ((_d === 0) && Object.keys(other).some(k => /\./.test(k)))
        other = expandObject(other);
    // Iterate over the other object
    for (let [k, v] of Object.entries(other)) {
        let tv = getType(v);
        // Prepare to delete
        let toDelete = false;
        if (k.startsWith("-=")) {
            k = k.slice(2);
            toDelete = (v === null);
        }
        // Get the existing object
        let x = original[k];
        let has = original.hasOwnProperty(k);
        let tx = getType(x);
        // Ensure that inner objects exist
        if (!has && (tv === "Object")) {
            x = original[k] = {};
            has = true;
            tx = "Object";
        }
        // Case 1 - Key exists
        if (has) {
            // 1.1 - Recursively merge an inner object
            if ((tv === "Object") && (tx === "Object")) {
                myMergeObject(x, v, {
                    insertKeys: insertValues,
                    insertValues: insertValues,
                    overwrite: overwrite,
                    inplace: true,
                    enforceTypes: enforceTypes
                }, depth);
            }
            // 1.2 - Remove an existing key
            else if (toDelete) {
                delete original[k];
            }
            // 1.3 - Overwrite existing value
            else if (overwrite) {
                if (tx && (tv !== tx) && enforceTypes) {
                    throw new Error(`Mismatched data types encountered during object merge.`);
                }
                original[k] = v;
            }
            // 1.4 - Insert new value
            else if ((x === undefined) && insertValues) {
                original[k] = v;
            }
        }
        // Case 2 - Key does not exist
        else if (!toDelete) {
            let canInsert = (depth === 1 && insertKeys) || (depth > 1 && insertValues);
            if (canInsert)
                original[k] = v;
        }
    }
    // Return the object for use
    return original;
}
//@ts-ignore
window.mergeObjectAdd = mergeObjectAdd;
async function convertToTrinket(item) {
    if (item.type !== "loot") {
        ui.notifications.error(`${item.name} is not of type loot`);
        return;
    }
    let newItem = await CONFIG.Item.entityClass.create({ "name": `${item.name} (Converted)`, type: "equipment" });
    await newItem.update({ "data.description": item.data.data.description, "data.weight": item.data.data.weight, "data.quantity": item.data.data.quanity, "data.price": item.data.data.price,
        "data.armor.type": "trinket", "img": item.data.img, "flags.itemcollection": item.data.flags.itemcollection, "flags.dynamicitems": item.data.flags.dynamicitems });
    console.log(`${item.name} converted`);
}
async function convertLootToEquipment(itemName) {
    let item = game.items.entities.find(i => i.name === itemName);
    if (!item) {
        ui.notifications.error(`Could not find ${itemName}`);
        return;
    }
    if (item.type !== "loot") {
        ui.notifications.error(`${itemName} is not of type loot`);
        return;
    }
    let newItem = await CONFIG.Item.entityClass.create({ "name": `${itemName} (Converted)`, type: "equipment" });
    await newItem.update({ "data.description": item.data.data.description, "data.weight": item.data.data.weight, "data.quantity": item.data.data.quanity,
        "data.price": item.data.data.price, "data.armor.type": "trinket", "img": item.data.img, "flags.itemcollection": item.data.flags.itemcollection, "flags.dynamicitems": item.data.flags.dynamicitems });
    console.log(`${itemName} converted`);
}
Hooks.on("getItemDirectoryEntryContext", (html, list) => {
    list.push({
        name: "Convert Loot to Trinket",
        icon: "<i class='fas fa-file-import'></i>",
        callback: html => {
            let item = game.items.get(html.attr("data-entity-id"));
            convertToTrinket(item);
        }
    });
});
export function mergeObjectAdd(original, other = {}, { insertKeys = true, insertValues = true, overwrite = true, inplace = true, enforceTypes = false, context = {}, debug = false } = {}, _d = 0) {
    other = other || {};
    if (!(original instanceof Object) || !(other instanceof Object)) {
        console.log("mergeadd", original, other);
        throw new Error("One of original or other are not Objects!");
    }
    let depth = _d + 1;
    // Maybe copy the original data at depth 0
    if (!inplace && (_d === 0))
        original = duplicate(original);
    // Enforce object expansion at depth 0
    if ((_d === 0) && Object.keys(original).some(k => /\./.test(k)))
        original = expandObject(original);
    if ((_d === 0) && Object.keys(other).some(k => /\./.test(k)))
        other = expandObject(other);
    if (debug)
        console.log("mergeadd", _d, duplicate(original), duplicate(other));
    // Iterate over the other object
    for (let [k, v] of Object.entries(other)) {
        if (debug)
            console.log("merge object loop doing ", duplicate(k), duplicate(v));
        if (typeof v === "string" && v.includes("@"))
            v = new Roll(`"${v}"`, context).roll().total;
        let tv = getType(v);
        // Prepare to delete
        let toDelete = false;
        if (k.startsWith("-=")) {
            k = k.slice(2);
            toDelete = (v === null);
        }
        let toAdd = false;
        if (k.startsWith("+")) {
            if (debug)
                console.log("Found adder", k, k.slice(2));
            k = k.slice(2);
            toAdd = true;
        }
        let lookupReplace = false;
        /* if (debug) console.log("Checking lookup ", k, k.startsWith("@="));
        if (k.startsWith("@=")) {
          if (debug) console.log("Found lookup replace", k, k.slice(2))
          k = k.slice(2);
          lookupReplace = true;
        }
        */
        /*
         if (debug) console.log("Checking lookup ", k, k.startsWith("@+"));
         if (k.startsWith("@+")) {
           if (debug) console.log("Found lookup add", k, k.slice(2))
           k = k.slice(2);
           lookupReplace = true;
           toAdd = true;
         }
         */
        // Get the existing object
        let x = original[k];
        let has = original.hasOwnProperty(k);
        let tx = getType(x);
        // Ensure that inner objects exist
        if (!has && (tv === "Object")) {
            x = original[k] = {};
            has = true;
            tx = "Object";
        }
        // Case 1 - Key exists
        if (has) {
            if (debug)
                console.log("Key exists ", duplicate(tv), duplicate(tx), Array.isArray(x));
            // 1.1 - Recursively merge an inner object
            if ((tv === "Object") && (tx === "Object") && !Array.isArray(x)) {
                if (debug)
                    console.log("doing recursive merge");
                mergeObjectAdd(x, v, {
                    insertKeys: insertValues,
                    insertValues: true,
                    overwrite: overwrite,
                    inplace: true,
                    enforceTypes: enforceTypes,
                    context: context
                }, depth);
            }
            // 1.2 - Remove an existing key
            else if (toDelete) {
                delete original[k];
            }
            // 1.3 - Overwrite existing value
            else if (overwrite && !toAdd && !lookupReplace) {
                if (debug)
                    console.log("Doing overwrite");
                if (tx && (tv !== tx) && enforceTypes) {
                    throw new Error(`Mismatched data types encountered during object merge.`);
                }
                original[k] = v;
            }
            // 1.4 - Insert new value
            else if ((x === undefined) && insertValues) {
                if (debug)
                    console.log("X undefined");
                original[k] = v;
            }
            else if ((toAdd && x !== undefined) || lookupReplace) { // append elements 
                if (Array.isArray(x)) {
                    if (debug)
                        console.log("Doing array concat", duplicate(x), duplicate(v));
                    original[k] = (toAdd ? original[k] : []).concat(v);
                }
                else if (typeof x === "string" && toAdd && !lookupReplace) {
                    if (debug)
                        console.log("Doing string", duplicate(x), duplicate(v));
                    original[k] = `${((toAdd && original[k]) ? original[k] : "")}+${v}`;
                }
                else if (typeof v === "number" && toAdd && !lookupReplace) { // number
                    if (debug)
                        console.log("Doing number", duplicate(x), duplicate(v));
                    original[k] = ((toAdd && original[k]) ? original[k] : 0) + v;
                }
                else { // string v
                    if (typeof x === "string") {
                        let formula = `"${v}"`;
                        if (debug)
                            console.log("setting string formula", formula);
                        original[k] = `${toAdd ? original[k] : ""} + ${new Roll(`"${v}"`, context).roll().total}`;
                    }
                    else {
                        let formula = toAdd ? `${x} + ${v}` : `${v}`;
                        original[k] = new Roll(formula, context).roll().total;
                        if (debug)
                            console.log("formul0e", formula);
                    }
                    if (debug)
                        console.log("Doing string value", duplicate(x), duplicate(v), duplicate(original[k]), context);
                }
            }
            // Case 2 - Key does not exist
            else if (!toDelete) {
                let canInsert = (depth === 1 && insertKeys) || (depth > 1 && insertValues);
                if (canInsert)
                    original[k] = v;
            }
        }
    }
    // Return the object for use
    return original;
}
