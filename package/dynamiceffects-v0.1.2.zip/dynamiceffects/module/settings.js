export const registerSettings = function () {
    game.settings.register("dynamiceffects", "EnableMod", {
        name: game.i18n.localize("Enable"),
        hint: game.i18n.localize("Enable"),
        scope: "world",
        default: true,
        type: Boolean,
        config: true,
        onChange: (value) => { window.location.reload(); }
    });
    game.settings.register("dynamiceffects", "AddToDefaultItemSheet", {
        name: "AddToDefaultItemSheet",
        hint: "AddToDefaultItemSheet",
        scope: "client",
        default: true,
        config: true,
        type: Boolean
    });
    game.settings.register("dynamiceffects", "ConsumeCharge", {
        name: "ConsumeCharge",
        hint: "ConsumeCharge",
        scope: "world",
        default: true,
        config: true,
        type: Boolean
    });
    game.settings.register("dynamiceffects", "EnableDebug", {
        name: "EnableDebug",
        hint: "EnableDebug",
        scope: "client",
        default: false,
        config: true,
        type: Boolean
    });
};
