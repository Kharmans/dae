import { activateItemEffectsForActor, activateItemEffectsForToken, activateItemEffectsForTargets, removeAllItemActiveEffectsTokenId, removeAllItemActiveEffectsActorId } from "./dynamiceffects.js";
export class GMActionMessage {
    constructor(action, sender, targetGM, data) {
        this.action = action;
        this.sender = sender;
        this.targetGM = targetGM;
        this.data = data;
    }
}
export let requestGMAction = async (action, data, debugLog = false) => {
    if (game.user.isGM) {
        return await GMAction.processAction(action, data);
    }
    //@ts-ignore
    let intendedGM = game.users.entities.find(u => u.isGM && u.active);
    if (!intendedGM) {
        ui.notifications.error(`${game.user.name} ${game.i18n.localize("dynamiceffects.noGM")}`);
        console.error("dynamiceffects | No GM user connected - cannot do request ", action, data);
        return;
    }
    let message = new GMActionMessage(action, game.user.name, intendedGM.id, data);
    if (debugLog)
        console.log("About to send message", this._moduleSocket, message);
    //@ts-ignore
    game.socket.emit(GMAction._moduleSocket, message, resp => {
        if (debugLog)
            console.log("message sent");
    });
};
export class GMAction {
    static _setupSocket() {
        console.log("Setting up ", this._moduleSocket);
        //@ts-ignore
        game.socket.on(this._moduleSocket, (message) => {
            if (game.user.id !== message.targetGM)
                return;
            if (!game.user.isGM)
                return;
            this.processAction(message.action, message.data);
        });
    }
    static initActions() {
    }
    static setupActions() {
    }
    static readyActions() {
        this._setupSocket();
        requestGMAction("testMessage", game.user.name);
    }
    static async processAction(action, data) {
        var actorId;
        var actor;
        switch (action) {
            case "testMessage":
                console.log("test message received", data);
                break;
            case "updateActor":
                //@ts-ignore
                actorId = data.actorId;
                //@ts-ignore
                let updateData = data.data;
                actor = game.actors.get(actorId);
                console.log("actor change ", actorId, updateData, actor);
                console.log(data);
                if (actor) {
                    await actor.update(updateData, {});
                }
                break;
            case "activateItemEffectsForTargets":
                //@ts-ignore
                await activateItemEffectsForTargets(data.targetList, data.itemData);
                break;
            case "activateItemEffectsForToken":
                //@ts-ignore
                await activateItemEffectsForToken(data.tokenId, data.itemData);
                break;
            case "activateItemEffectsForActor":
                //@ts-ignore
                await activateItemEffectsForActor(data.actorId, data.itemData);
                console.log(data);
                break;
            case "removeAllItemActiveEffectsTokenId":
                //@ts-ignore
                await removeAllItemActiveEffectsTokenId(data.tokenId, data.itemData);
                break;
            case "removeAllItemActiveEffectsActorId":
                //@ts-ignore
                await removeAllItemActiveEffectsActorId(data.actorId, data.itemData);
                break;
            default:
                console.warn("dynamiceffects invalid message received", action, data);
        }
    }
}
GMAction.actions = {
    test: "testMessage",
    actorUpdate: "updateActor",
    activateItemEffectsForActor: "activateItemEffectsForActor",
    activateItemEffectsForToken: "activateItemEffectsForToken",
    activateItemEffectsForTargets: "activateItemEffectsForTargets",
    removeAllItemActiveEffectsActorId: "removeAllItemActiveEffectsActorId",
    removeAllItemActiveEffectsTokenId: "removeAllItemActiveEffectsTokenId"
};
GMAction._moduleSocket = "module.dynamiceffects";
