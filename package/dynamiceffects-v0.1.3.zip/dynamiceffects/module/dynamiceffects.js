import { mergeObjectLookup } from "./utils.js";
import { requestGMAction, GMAction } from "./GMAction.js";
var basePreprateData;
export let _characterSpec = { data: {}, flags: {} };
export const EVALPASSES = {
    BASESET: 0,
    BASEADD: 1,
    PREPAREDATA: 2,
    DERIVEDSET: 4,
    DERIVEDADD: 5,
    FINALSET: 6,
    FINALADD: 7
};
let templates = {};
var secPerRound;
export var aboutTimeInstalled = false;
let validateDuration = (duration) => {
    if (!duration.units)
        duration.units = "minutes";
    if (duration.units.length > 0 && duration.units[duration.units.length - 1] !== "s")
        duration.units = `${duration.units}s`;
    if (!["hours", "minutes", "seconds", "years", "months", "days"].includes(duration.units))
        duration.units = "rounds";
    if (isNaN(duration.value) || duration.value < 0)
        duration.value = 1;
    return duration;
};
export var durationUnitsMap = {
    "inst": duration => { return { "seconds": 0 }; },
    "turn": duration => { return { "turn": (duration.value || 0) * secPerRound }; },
    "round": duration => { return { "seconds": (duration.value || 0) * secPerRound }; },
    "default": duration => { let val = {}; duration = validateDuration(duration); val[duration.units] = duration.value || 0; return val; }
};
let debugLog = false;
let acAffectingArmorTypes;
function debug(...args) {
    if (debugLog) {
        console.log(...args);
    }
}
export class ModSpec {
    constructor(field, label, pass, sampleValue = 0) {
        this.field = "";
        this.label = "";
        this.pass = 0;
        this.mode = ""; // "" -> overwrite no eval, += -> nmeric/string/array append add @= -> character lookup + eval
        this.sampleValue = 0;
        this.field = field;
        this.label = label;
        this.pass = pass;
        this.sampleValue = sampleValue;
    }
    static specFor(specId) { return this.allSpecsObj[specId]; }
    static createValidMods(characterSpec = game.system.model.Actor.character) {
        _characterSpec["data"] = duplicate(characterSpec);
        let baseValues = flattenObject(_characterSpec);
        if (game.system.id === "dnd5e") { // patch for missing fields
            // data.bonuses.spell.dc hoping will appear in 0.8.3
            baseValues["data.bonuses.spell.dc"] = 0;
            // dynamiceffects pseudo field
            baseValues["data.traits.languages.all"] = false;
            // dynamiceffects psuedo field 
            baseValues["data.bonuses.All-Attacks"] = false;
            baseValues["data.attributes.advantage"] = "none"; //TODO implement this in minor-qol
        }
        // baseSpecs are all those fields defined in template.json game.system.model and are things the user can directly change
        this.baseSpecs = Object.keys(baseValues).map(spec => new ModSpec(spec, spec, EVALPASSES.BASESET, baseValues[spec]));
        // Do the system specific part
        if (game.system.id == "dnd5e") {
            // 1. abilities add mod and save to each;
            Object.keys(_characterSpec.data.abilities).forEach(ablKey => {
                let abl = _characterSpec.data.abilities[ablKey];
                abl.mod = 0;
                abl.save = 0;
                abl.min = 0;
            });
            // adjust specs for bonuses - these are strings, @fields are looked up but dice are not rolled.
            this.baseSpecs = this.baseSpecs.map(spec => {
                if (spec.field.includes("data.bonuses.")) {
                    spec.pass = EVALPASSES.DERIVEDSET;
                }
                return spec;
            });
            // Skills add mod, passive and bonus fields
            Object.keys(_characterSpec.data.skills).forEach(sklKey => {
                let skl = _characterSpec.data.skills[sklKey];
                skl.mod = 0;
                skl.passive = 0;
                skl.bonus = 0;
            });
            // Add special fields
            // 1st group are flags that are absent in model
            // 2nd special fields check_all
            mergeObject(_characterSpec, {
                "flags.dnd5e.initiativeAdv": false,
                "flags.dnd5e.initiativeAlert": false,
                "flags.dnd5e.initiativeHalfProf": false,
                "flags.dnd5e.powerfulBuild": false,
                "flags.dnd5e.savageAttacks": false,
                "flags.dnd5e.elvenAccuracy": false,
                "flags.dnd5e.halflingLucky": false,
                "flags.dnd5e.check_all": 0,
                "flags.dnd5e.weaponCriticalThreshold": 20,
                "data.attributes.ac.value": 0,
                "data.attributes.ac.min": 0,
                "data.attributes.init.mod": 0,
                "data.attributes.init.total": 0,
                "data.attributes.init.prof": 0,
                "data.attributes.hd": 0,
                "data.attributes.prof": 0,
                "data.attributes.spelldc": 0,
                "data.attributes.spelllevel": 0,
            }, { inplace: true, insertKeys: true, insertValues: true, overwrite: false });
        }
        let allSpecsTemp = flattenObject(_characterSpec);
        this.derivedSpecs = Object.keys(allSpecsTemp)
            .filter(specName => { return undefined === this.baseSpecs.find(vs => vs.field === specName); })
            .map(spec => { return new ModSpec(spec, spec, EVALPASSES.DERIVEDSET, this.allSpecs[spec]); });
        this.allSpecs = this.baseSpecs.concat(this.derivedSpecs);
        // Special case for armor/hp which can depend on derived attributes - like dexterity mod or constituion mod
        this.allSpecs.forEach(m => { if (m.field === "data.attributes.ac.value")
            m.pass = EVALPASSES.FINALSET; });
        this.allSpecs.forEach(m => { if (m.field === "data.attributes.hp.max")
            m.pass = EVALPASSES.FINALSET; });
        this.baseSpecs = this.allSpecs.filter(spec => [EVALPASSES.BASEADD, EVALPASSES.BASESET].includes(spec.pass));
        this.derivedSpecs = this.allSpecs.filter(spec => [EVALPASSES.DERIVEDADD, EVALPASSES.DERIVEDSET].includes(spec.pass));
        this.allSpecs.forEach(ms => this.allSpecsObj[ms.field] = ms);
        this.baseSpecs.forEach(ms => this.baseSpecsObj[ms.field] = ms);
        this.derivedSpecs.forEach(ms => this.derivedSpecsObj[ms.field] = ms);
        if (debugLog)
            debug("Completed spec creation ", _characterSpec, Object.keys(flattenObject(_characterSpec)).length, ModSpec.allSpecsObj, ModSpec.baseSpecsObj, ModSpec.derivedSpecsObj);
    }
    static localizeSpecs() {
        this.allSpecs = this.allSpecs.map(m => {
            m.label = m.label.replace("data.", "").replace("dnd5e.", "").replace(".value", "").split(".").map(str => game.i18n.localize(`dynamiceffects.${str}`)).join(" ");
            return m;
        });
        // We redo this to make sure they are all pointing to the localised versions - may not be necessary
        this.baseSpecs = this.allSpecs.filter(spec => [EVALPASSES.BASEADD, EVALPASSES.BASESET].includes(spec.pass));
        this.derivedSpecs = this.allSpecs.filter(spec => [EVALPASSES.DERIVEDADD, EVALPASSES.DERIVEDSET].includes(spec.pass));
        this.allSpecs.forEach(ms => this.allSpecsObj[ms.field] = ms);
        this.baseSpecs.forEach(ms => this.baseSpecsObj[ms.field] = ms);
        this.derivedSpecs.forEach(ms => this.derivedSpecsObj[ms.field] = ms);
    }
}
ModSpec.allSpecs = [];
ModSpec.baseSpecs = [];
ModSpec.derivedSpecs = [];
ModSpec.allSpecsObj = {};
ModSpec.baseSpecsObj = {};
ModSpec.derivedSpecsObj = {};
export class EffectModifier {
    constructor(modSpecKey, mode, value) {
        this.modSpecKey = modSpecKey;
        this.value = value;
        this.mode = mode;
        return this;
    }
    get modSpec() { return ModSpec.specFor[this.modSpecKey]; }
}
export function asMergeItem(mod) {
    let modSpec = ModSpec.specFor(mod.modSpecKey);
    if (mod.mode === "=") {
        var pass = modSpec.pass;
        var spec = modSpec.field;
    }
    else {
        var pass = modSpec.pass + 1; // do additions after assignments
        let specParts = modSpec.field.split(".");
        specParts[specParts.length - 1] = `+${specParts[specParts.length - 1]}`;
        var spec = specParts.join(".");
    }
    let item = {};
    item[`${spec}`] = mod.value;
    return [pass, item];
}
export class ItemEffect extends EffectModifier {
    constructor(id, itemId = "", modSpecKey = ModSpec.allSpecs[0].field, mode = "=", value = "", active = false) {
        super(modSpecKey, mode, value);
        if (debugLog)
            console.warn("creating item effect with id", id, typeof id);
        this.id = Number(id);
        this.itemId = itemId;
        this.active = active;
    }
}
let uidForActor = (actor) => {
    let uid;
    if (!actor.isToken)
        uid = actor.id;
    else
        uid = `${actor.token.id}+${actor.id}`;
    return uid;
};
export class TimedItemEffectModifier extends ItemEffect {
    constructor(id, itemId, modSpecKey, mode, value, duration = { value: 0, units: "seconds" }) {
        super(id, itemId, modSpecKey, mode, value);
        this._duration = validateDuration(duration);
        //@ts-ignore
        if (Gametime) {
            //@ts-ignore
            this._startTime = Gametime.DTNow().toSeconds();
            console.log("settting start time to ", this._startTime);
            console.log("Date.now", Date.now());
        }
        else {
            this._startTime = Date.now();
        }
    }
    get durartion() { return this._duration; }
    set duration(duration) { this._duration = duration; }
}
class ActorDataCache {
    static getSavedData(actor, itemEffects) {
        let uid = uidForActor(actor);
        if (!ActorDataCache.actorDataCache[uid]) {
            if (debugLog)
                console.log(`Creating new saved data for ${actor.data.name}`, actor.data.data, actor.data.items);
            let savedActorData = { data: {}, flags: {}, itemEffects: [] };
            savedActorData.data = duplicate(actor.data.data);
            savedActorData.flags = duplicate(actor.data.flags);
            this.actorDataCache[uid] = savedActorData;
        }
        else {
            if (debugLog)
                console.log("restoring saved data for ", actor.name);
            let preparedData = this.preparedActorDataCache[uid];
            // See what has changed in the background since the last prepare data.
            // Chnages will only be things entered for the character not dynamiceffects chagnes so we need to record those
            //@ts-ignore
            let updatesData = diffObject(preparedData.data, actor.data.data);
            //@ts-ignore
            let updatesFlags = diffObject(preparedData.flags, actor.data.flags);
            if (debugLog) {
                console.log("updates since last save", duplicate(updatesData));
                console.log("update flags", updatesFlags);
            }
            // update the saved actor.data.data with the updates, then set the actor data to the saved data
            actor.data.data = duplicate(mergeObject(this.actorDataCache[uid].data, updatesData, { inplace: true, insertKeys: false, insertValues: false, overwrite: true }));
            // update flags with changes, then actor data flags
            mergeObject(this.actorDataCache[uid].flags, updatesFlags, { insertKeys: false, insertValues: false, inplace: true, overwrite: true });
            mergeObject(actor.data.flags, this.actorDataCache[uid].flags, { insertKeys: false, insertValues: false, inplace: true, overwrite: true });
        }
    }
    static postPrepareData(actor) {
        let uid = uidForActor(actor);
        // save a copy of all that we calculdated so we can check changes next time through.
        this.preparedActorDataCache[uid] = { data: duplicate(actor.data.data), flags: duplicate(actor.data.flags), itemEffects: [] };
    }
    static updateActorData(actor, data) {
        return;
        // we probably don't need this since changes will happen in the background
        let uid = uidForActor(actor);
        let currentData = this.actorDataCache[uid];
        if (!currentData) {
            console.error("No saved data for ", actor.name, uid);
            return;
        }
        actor.data.data = duplicate(this.actorDataCache[uid].data);
        mergeObject(currentData, data, { inplace: true, insertKeys: true, insertValues: true, overwrite: true });
        if (debugLog)
            console.log("After update changed data is ", currentData, data);
    }
    permanentChange(actor, change) {
    }
}
ActorDataCache.actorDataCache = {};
ActorDataCache.preparedActorDataCache = {};
let addArmorEffect = (itemData, effectList, actor) => {
    // Special case for armor
    if (itemData.data.hasOwnProperty("armor") && hasProperty(actor.data, "data.abilities.dex")
        && acAffectingArmorTypes.includes(itemData.data.armor.type)
        && (itemData.data.equipped || itemData.data.armor.type === "natural")) {
        let acValue = itemData.data.armor.value || 0;
        if (!["shield", "bonus"].includes(itemData.data.armor.type)) {
            let dexMod = itemData.data.armor.dex === 0 ? 0 : actor.data.data.abilities.dex.mod || 0;
            acValue = acValue + (itemData.data.armor.dex === null ? dexMod : Math.min(itemData.data.armor.dex, dexMod));
        }
        if (itemData.data.armor.value !== 0)
            effectList.push(new EffectModifier("data.attributes.ac.value", ["shield", "bonus"].includes(itemData.data.armor.type) ? "+" : "=", acValue));
    }
};
// active effects do not activate when the item is equipped/cursed - they must be applied
export let getItemActiveEffects = (itemData) => {
    // let itemData = item.data;
    // use the item specified duration to set the duration for the effect
    //let duration = itemData.data.duration.value ? {value: itemData.data.duration.value, units: itemData.data.duration.units} : {value: 1, units: "round"};
    // constructing TimedItemEffectModifier tags the start time as "now"
    let effects = (getProperty(itemData, "flags.dynamiceffects.effects") || []).filter(effect => { return effect.active; });
    if (game.system.id === "dnd5e") {
        effects = effects.reduce((effectList, effect) => effectList.concat(expandSpecial(effect)), []);
    }
    effects = effects.map(ed => new TimedItemEffectModifier(1, itemData._id, ed.modSpecKey, ed.mode, ed.value, itemData.data.duration));
    return effects;
};
// Get active or passive effects for an item.
export let getItemPassiveEffects = (itemData) => {
    return (getProperty(itemData.flags, "dynamiceffects.effects") || [])
        .filter(em => !em.active)
        .map(em => new EffectModifier(em.modSpecKey || "data.abilities.str.value", em.mode || "+", em.value || 0));
};
// get passive item effects for items that are active (equipped/always active etc)
let getAllItemPassiveEffects = (actor, active = false, itemId = "") => {
    var itemEffects = actor.data.items
        .filter(itemData => hasProperty(itemData, "flags.dynamiceffects.effects") || hasProperty(itemData, "data.armor"))
        .reduce((effectList, itemData) => {
        addArmorEffect(itemData, effectList, actor);
        if (hasProperty(itemData, "flags.dynamiceffects.effects") && isActive(itemData)) {
            effectList = effectList.concat(getItemPassiveEffects(itemData));
        }
        return effectList;
    }, []);
    // see if there are any special effects to process - these are dnd5e specific.
    if (game.system.id === "dnd5e") {
        itemEffects = itemEffects.reduce((effectList, effect) => effectList.concat(expandSpecial(effect)), []);
    }
    if (debugLog)
        console.log("For actor effects are ", actor.name, itemEffects);
    return itemEffects;
};
// get actor active effects i.e. active effects that have been applied to the actor
let getActiveActorEffects = (actor) => {
    return (getProperty(actor.data.flags, "dynamiceffects.activeEffects") || []).map(em => new EffectModifier(em.modSpecKey || "data.abilities.str.value", em.mode || "+", em.value || 0));
};
export let activateItemEffectsForTargets = async (targetIdList, itemData) => {
    return activateEffectsForTargets(targetIdList, getItemActiveEffects(itemData));
};
export let activateItemEffectsForToken = async (token, itemData) => {
    if (typeof token === "string")
        token = canvas.tokens.get(token);
    return activateEffectsForActor(token.actor, getItemActiveEffects(itemData));
};
export let activateItemEffectsForActor = async (actor, itemData) => {
    return activateEffectsForActor(actor, getItemActiveEffects(itemData));
};
export let activateEffectsForActor = async (actor, effectListData) => {
    if (typeof actor === "string") {
        actor = game.actors.get(actor);
    }
    if (actor) {
        let actorEffects = (getProperty(actor.data.flags, "dynamiceffects.activeEffects") || []).concat(effectListData);
        return actor.update({ "flags.dynamiceffects.activeEffects": actorEffects });
    }
    return null;
};
// add a list of active effects to the actor
export let activateEffectsForTargets = async (targetIdList, effectListData) => {
    let promises = [];
    (targetIdList || []).forEach((tId) => {
        let token = canvas.tokens.get(tId);
        if (token && token.actor) {
            let update = activateEffectsForActor(token.actor, effectListData);
            if (update)
                promises.push(update);
        }
    });
    Promise.all(promises);
    return promises;
};
// remove all actor effects from the given actor
export let removeAllActorEffects = async (actorId) => {
    let actor = game.actors.get(actorId);
    if (actor)
        return await actor.update({ "flags.dynamiceffects.activeEffects": [] }, {});
    return null;
};
export let removeAllTokenEffects = async (tokenId) => {
    let token = canvas.tokens.get(tokenId);
    if (token.actor)
        return await token.actor.update({ "flags.dynamiceffects.activeEffects": [] }, {});
    return null;
};
let checkExpiredActions = (combat) => {
    /* let token = canvas.tokens.get(combatDetails.previous.tokenId);
    if (!token) {
      console.warn("Dynamiceffects | Could not find token ", combatDetails.previous.tokenId);
      return;
    }
    let actorEffects = getActiveActorEffects(token.actor);
    console.log("Active effects for actor are");
    */
    console.log("check active combat is ", combat, combat.current, combat.previous);
};
export let removeAllItemActiveEffectsActorId = async (actorId, itemData) => {
    let actor = game.actors.get(actorId);
    return await removeAllItemActiveEffectsActor(actor, itemData);
};
export let removeAllItemActiveEffectsTargets = async (targetList, itemData) => {
    targetList.forEach(tokenId => removeAllItemActiveEffectsTokenId(tokenId, itemData));
};
export let removeAllItemActiveEffectsTokenId = async (tokenId, itemData) => {
    let token = canvas.tokens.get(tokenId);
    return await removeAllItemActiveEffectsActor(token.actor, itemData);
};
export let removeAllItemActiveEffectsActor = async (actor, itemData) => {
    let activeEffects = getProperty(actor.data, "flags.dynamiceffects.activeEffects") || [];
    //@ts-ignore
    activeEffects = activeEffects.filter(tem => tem.itemId !== itemData._id);
    return await actor.update({ "flags.dynamiceffects.activeEffects": activeEffects }, {});
};
// The workhorse that applies all passive and actor effects to the actor
class DynamicEffectsPatching extends Actor {
    prepareData() {
        let itemEffects = getAllItemPassiveEffects(this, false); // get passive effects for items that are active
        let allEffects = itemEffects.concat(getActiveActorEffects(this)); // get actor effects that are active
        ActorDataCache.getSavedData(this, allEffects);
        if (debugLog)
            console.log("effects are ", allEffects);
        let actorChanges = allEffects.map(effect => asMergeItem(effect));
        actorChanges.push([EVALPASSES.PREPAREDATA, {}]); // dummy item to make sure we call the original prepareData
        if (debugLog)
            console.log(actorChanges);
        Object.keys(EVALPASSES).forEach(k => {
            if (debugLog)
                console.log('Doing pass', k);
            actorChanges
                .filter(([pass, change]) => EVALPASSES[k] === pass)
                .forEach(([pass, change]) => {
                if (pass === EVALPASSES.PREPAREDATA)
                    basePreprateData.bind(this)();
                else {
                    mergeObjectLookup(this.data, change, { inplace: true, insertKeys: true, insertValues: true, context: this.data, debug: false });
                }
            });
        });
        ActorDataCache.postPrepareData(this); // record the current state of the actor after effects applied
    }
}
// Is the item active? i.e. armor, or equiped or always active
export let isActive = (itemData) => {
    // This test is to allow natural armor effects to be active even if no other flag set.
    if (itemData.data.hasOwnProperty("armor.type") && itemData.data.armor.type === "natural")
        return true;
    if (!itemData.flags.hasOwnProperty("dynamiceffects"))
        return false;
    if (getProperty(itemData, "flags.dynamiceffects.alwaysActive"))
        return true;
    if (hasProperty(itemData.data, "equipped") && !itemData.data.equipped)
        return false;
    if (getProperty(itemData.data, "attuned") || getProperty(itemData, "flags.dynamiceffects.equipActive"))
        return true;
    return false;
};
// a few dnd specific extensions
function expandSpecial(effect) {
    let checkList = [];
    switch (effect.modSpecKey) {
        case "data.traits.languages.all":
            return [new EffectModifier("data.traits.languages.value", "=", Object.keys(CONFIG.DND5E.languages))];
        // return [new ItemEffect(0, "All Languages", "data.traits.languages.value", "=", Object.keys(CONFIG.DND5E.languages), "Array", "baseEffect")];
        case "skills.all":
            return Object.keys(CONFIG.DND5E.skills).map(skillId => new EffectModifier(`data.skills.${skillId}.mod`, effect.mode, effect.value));
            return checkList;
        case "data.bonuses.All-Attacks":
            return ["data.bonuses.mwak.attack", "data.bonuses.rwak.attack", "data.bonuses.msak.attack", "data.bonuses.rsak.attack"].map(spec => new EffectModifier(spec, "+", effect.value));
        default:
            return [effect];
    }
}
export let validMods = [];
// replace the standard Actor.prepareData with our prepareData - for dnd5e this is Actor5e.prepareData
function setupProxy() {
    basePreprateData = CONFIG.Actor.entityClass.prototype.prepareData;
    let test = new Proxy(CONFIG.Actor.entityClass.prototype.prepareData, {
        apply: (target, thisvalue, args) => DynamicEffectsPatching.prototype.prepareData.bind(thisvalue)(...args)
    });
    CONFIG.Actor.entityClass.prototype.prepareData = test;
}
export function dynamiceffectsInitActions() {
    setupProxy();
    ModSpec.createValidMods();
    Hooks.on("preUpdateActor", (actor, data, other, id) => {
        ActorDataCache.updateActorData(actor, data);
        return true;
    });
}
export function dynamiceffectsSetupActions() {
    if (game.system.id === "dnd5e") {
        acAffectingArmorTypes = Object.keys(CONFIG.DND5E.armorTypes).filter(acType => !["trinket"].includes(acType));
    }
}
export function dynamiceffectsReadyActions() {
    ModSpec.localizeSpecs();
    //@ts-ignore
    aboutTimeInstalled = game.modules.get("about-time") && game.modules.get("about-time").active;
    secPerRound = game.settings.get("about-time", "seconds-per-round") || 6;
    Hooks.on("updateCombat", combatHandler);
    Hooks.on("deleteCombat", deleteCombatHandler);
}
let combats = {};
let combatHandler = (combat, updateData, otherData, userId) => {
    console.log("Update combat ", combat, updateData);
    combat[combat.id] = combat;
    combats[combat.id] = { current: combat.current, previous: combat.previous, turns: combat.turns };
    checkExpiredActions(combats[combat.id]);
};
let deleteCombatHandler = (combat, id, options) => {
    delete combats[combat.id];
};
export let doEffects = (item, activate, targets = undefined) => {
    let itemData = item.data;
    if (!item.hasTarget) {
        // cannot target anyone
        console.log("Not a target spell");
        return;
    }
    let targetIds = [];
    if ((itemData.data.range && itemData.data.range.units === "self")
        || (itemData.data.target && itemData.data.target.type === "self")) { // spell effects us
        if (canvas.tokens.controlledTokens.length <= 0) {
            console.log("can't work out who self is");
            return;
        }
        targetIds = [canvas.tokens.controlledTokens[0].id];
    }
    else { // we need to get the targets
        //@ts-ignore
        if (!targets)
            targets = game.user.targets;
        for (let target of targets) {
            targetIds.push(target.id);
        }
    }
    if (activate) {
        requestGMAction(GMAction.actions.activateItemEffectsForTargets, { targetList: targetIds, itemData: item.data });
    }
    else {
        requestGMAction(GMAction.actions.removeAllItemActiveEffectsTargets, { targetList: targetIds, itemData: item.data });
    }
    if (aboutTimeInstalled && activate) {
        let durationMap = durationUnitsMap[item.data.data.duration.units] || durationUnitsMap["default"];
        console.log("mapped duration is ", durationMap(item.data.data.duration));
        let duration = durationMap(item.data.data.duration);
        //@ts-ignore
        game.Gametime.doIn(duration, DynamicEffects.requestGMAction, GMAction.actions.removeAllItemActiveEffectsTargets, { targetList: targetIds, itemData: item.data });
    }
    console.log("Apply Effects", targetIds, item);
};
