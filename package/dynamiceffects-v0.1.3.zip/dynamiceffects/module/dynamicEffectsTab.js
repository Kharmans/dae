import { ItemEffectSelector } from "./apps/dynamiceffectsSelector.js";
import { ModSpec } from "./dynamiceffects.js";
let debugLog = false;
let selectEffects = false;
export function initSheetTab() {
    if (game.settings.get("dynamiceffects", "EnableMod")) {
        debugLog = game.settings.get("dynamiceffects", "EnableDebug");
        let itemSheets = {};
        Object.values(CONFIG.Item.sheetClasses).forEach(itemType => Object.keys(itemType).forEach(sheetName => itemSheets[sheetName] = 1));
        Object.keys(itemSheets).forEach(sheetName => Hooks.on(`render${sheetName.split(".")[1]}`, (app, html, data) => {
            if (game.settings.get("dynamiceffects", "AddToDefaultItemSheet"))
                addDynamicEffectsTab(app, html, data);
        }));
    }
}
async function addDynamicEffectsTab(app, html, data) {
    let item = app.object;
    // if (["spell", "backpack"].includes(item.type)) return;
    // if (!game.user.isGM && !(item.data.data.attuned || item.data.data.identified)) return;
    if (!hasProperty(item.data, "flags.dynamiceffects.equipActive"))
        setProperty(item.data, "flags.dynamiceffects.equipActive", false);
    if (!hasProperty(item.data, "flags.dynamiceffects.alwaysActive"))
        setProperty(item.data, "flags.dynamiceffects.alwaysActive", false);
    if (!hasProperty(item.data, "flags.dynamiceffects.effects"))
        setProperty(item.data, "flags.dynamiceffects.effects", []);
    // if (!hasProperty(item.data, "data.attuned")) setProperty(item.data, "data.attuned", {"type": "Boolean", "label": "Attuned", "value": false})
    //  let tabSelector = html.find(`.sheet-navigation`),
    let tabSelector = html.find(`.tabs`), settingsContainer = html.find(`.sheet-body`), dynamiceffectsTabString = `<a class="item" data-tab="dynamiceffects">${game.i18n.localize("dynamiceffects.Title")}</a>`, tab = tabSelector.append($(dynamiceffectsTabString));
    /*      <nav class="sheet-navigation tabs" data-group="primary">
            <a class="item active" data-tab="description">{{ localize "DND5E.Description" }}</a>
            <a class="item" data-tab="details">{{ localize "DND5E.Details" }}</a>
        </nav>
        */
    let dynamiceffectsTabTemplate = await renderTemplate("modules/dynamiceffects/templates/dynamiceffects-tab.html", {
        flags: item.data.flags,
        actives: item.data.flags.dynamiceffects.effects.filter(ie => ie.active).map(ie => { ie.label = ModSpec.allSpecsObj[ie.modSpecKey] ? ModSpec.allSpecsObj[ie.modSpecKey].label : "invalid"; return ie; }),
        passives: item.data.flags.dynamiceffects.effects.filter(ie => !ie.active).map(ie => { ie.label = ModSpec.allSpecsObj[ie.modSpecKey] ? ModSpec.allSpecsObj[ie.modSpecKey].label : ""; return ie; }),
        isGM: game.user.isGM,
        data: { attuned: getProperty(item.data, "data.attuned") },
        needsAttuned: ["tool", "consumable"].includes(item.type)
    });
    let extraTab = settingsContainer.append(dynamiceffectsTabTemplate);
    html.find('.dynamiceffects .effect-create').click(ev => {
        let effects = item.data.flags.dynamiceffects.effects || [];
        let newId = effects.length ? Math.max(...effects.map(i => Number(i.id))) + 1 : 1;
        new ItemEffectSelector(item, { id: `${newId}` }).render(true);
        selectEffects = true;
    });
    // Update Effect Item
    html.find('.dynamiceffects .effect-edit').click(ev => {
        let effectId = Number($(ev.currentTarget).parents(".effect").attr("effect-id"));
        //@ts-ignore
        new ItemEffectSelector(item, { id: effectId }).render(true);
        selectEffects = true;
    });
    // Delete Effect
    html.find('.dynamiceffects .effect-delete').click(async (ev) => {
        let li = $(ev.currentTarget).parents(".effect");
        let effectId = Number(li.attr("effect-id"));
        let effects = duplicate(item.data.flags.dynamiceffects.effects) || [];
        for (let i = 0; i < effects.length; i++) {
            if (effects[i].id === effectId) {
                effects.splice(i, 1);
            }
        }
        selectEffects = true;
        li.slideUp(200);
        if (item.isOwned) {
            await item.actor.updateOwnedItem({ "_id": item._id, "flags.dynamiceffects.effects": effects });
        }
        else
            await item.update({ "flags.dynamiceffects.effects": effects });
    });
    if (selectEffects) {
        item.data.flags["_sheetTab"] = "dynamiceffects";
        activateTab(html, "dynamiceffects");
        selectEffects = false;
    }
}
/**
 * Activate a tab by it's name.
 */
function activateTab(html, tab) {
    tab = html.find(`[data-tab="${tab}"]`);
    tab.siblings().removeClass('active');
    tab.addClass('active');
    tab.show();
}
