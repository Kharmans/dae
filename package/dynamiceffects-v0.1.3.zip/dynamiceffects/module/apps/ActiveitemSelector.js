import { getItemActiveEffects, doEffects } from "../dynamiceffects.js";
export class ActiveItemSelector extends FormApplication {
    constructor() {
        super(...arguments);
        this.activate = true;
        this.process = (event) => {
            this.activate = event.target.id === "active";
            console.log("Process activate  is ", this.activate);
        };
    }
    static get defaultOptions() {
        const options = super.defaultOptions;
        options.id = "active-item-selector";
        options.classes = ["dnd5e"];
        options.title = game.i18n.localize("dynamiceffects.ActiveItemSelect");
        options.template = "/modules/dynamiceffects/templates/activeItem-selector.html";
        options.height = 275;
        options.width = 275;
        console.log("inside default options");
        return options;
    }
    static initActions() { }
    static setupActions() { }
    getData() {
        console.log("inside get data");
        // created with an actor
        let data = super.getData();
        data.itemList = {};
        this.object.items.forEach(item => {
            if (getItemActiveEffects(item.data).length > 0)
                data.itemList[item.id] = ({ type: item.data.type, name: item.name });
            //            data.itemList[item.name] = item.name;
        });
        data.itemId = "";
        console.log("get data is ", data);
        data.submit = "";
        return data;
    }
    activateListeners(html) {
        super.activateListeners(html);
        html.find(".activatebutton").click(this.process);
    }
    async _updateObject(event, formData) {
        console.log("formdata is ", formData, event);
        let item = this.object.items.find(i => i.id === formData.itemId);
        console.log(" Item is ", item, this.activate);
        if (item) {
            doEffects(item, this.activate);
        }
    }
}
