export const registerSettings = function () {
    game.settings.register("dynamiceffects", "ConsumeCharge", {
        name: game.i18n.localize("dynamiceffects.ConsumeCharge.Name"),
        hint: game.i18n.localize("dynamiceffects.ConsumeCharge.Hint"),
        scope: "world",
        default: true,
        config: true,
        type: Boolean
    });
};
