export class EditOwnedItemEffects {
    static log(...args) {
        if (game.modules.get('_dev-mode')?.api?.getPackageDebugValue("midi-qol")) {
            console.log(this.MODULE_TITLE, '|', ...args);
        }
    }
}
EditOwnedItemEffects.MODULE_NAME = "midi-qol-edit-item-wffects";
EditOwnedItemEffects.MODULE_TITLE = "Edit Owned Item Effects";
Hooks.on('init', () => {
    console.log(`${EditOwnedItemEffects.MODULE_NAME} | Initializing ${EditOwnedItemEffects.MODULE_TITLE}`);
});
Hooks.on("ready", async () => {
    // initialize item sheet hooks
    // EditOwnedItemEffectsItemSheet.init();
});
Hooks.once('devModeReady', ({ registerPackageDebugFlag }) => {
    // registerPackageDebugFlag(EditOwnedItemEffects.MODULE_NAME);
});
