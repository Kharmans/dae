/**
 * This is your TypeScript entry file for Foundry VTT.
 * Register custom settings, sheets, and constants using the Foundry API.
 * Change this heading to be more descriptive to your module, or remove it.
 * Author: [your name]
 * Content License: [copyright and-or license] If using an existing system
 * 					you may want to put a (link to a) license or copyright
 * 					notice here (e.g. the OGL).
 * Software License: [your license] Put your desired license here, which
 * 					 determines how others may use and modify your module
 */
// Import TypeScript modules
import { registerSettings } from './module/settings.js';
import { preloadTemplates } from "./module/preloadTemplates.js";
import { dynamiceffectsInitActions, doEffects } from "./module/dynamiceffects.js";
import { dynamiceffectsSetupActions } from "./module/dynamiceffects.js";
import { dynamiceffectsReadyActions } from "./module/dynamiceffects.js";
import { dynamiceffectsShowEffects, activateItem, applyEffects, removeActiveEffectsToken } from "./module/dynamiceffectsMacros.js";
import { dynamiceffectsToggleEffect, teleportToToken } from "./module/dynamiceffectsMacros.js";
import { getItemActiveEffects } from "./module/dynamiceffects.js";
import { initSheetTab } from "./module/dynamicEffectsTab.js";
import { ModSpec } from "./module/dynamiceffects.js";
import { ItemEffectSelector } from "./module/apps/dynamiceffectsSelector.js";
import { migrateItems, migrateActors, migrateAll, migrateAllAts } from "./module/migration.js";
import { GMAction, requestGMAction, GMActionMessage } from "./module/GMAction.js";
/* ------------------------------------ */
/* Initialize module					*/
/* ------------------------------------ */
Hooks.once('init', async function () {
    // Register custom module settings
    registerSettings();
    console.log('dynamiceffects | Initializing dynamiceffects');
    dynamiceffectsInitActions();
    ItemEffectSelector.initActions();
    // Assign custom classes and constants here
    // Preload Handlebars templates
    await preloadTemplates();
    // Register custom sheets (if any)
});
/* ------------------------------------ */
/* Setup module							*/
/* ------------------------------------ */
Hooks.once('setup', function () {
    // Do anything after initialization but before
    // ready
    GMAction.initActions;
    dynamiceffectsSetupActions();
    ItemEffectSelector.setupActions();
    //@ts-ignore
    window.allSpecs = ModSpec.allSpecs;
    //@ts-ignore
    window.allSpecsObj = ModSpec.allSpecsObj;
    //@ts-ignore
    window.DynamicEffects = {
        effects: dynamiceffectsShowEffects,
        toggleEffect: dynamiceffectsToggleEffect,
        requestGMAction: requestGMAction,
        getItemActiveEffects: getItemActiveEffects,
        removeAllActiveffects: removeActiveEffectsToken,
        applyEffects: applyEffects,
        activateItem: activateItem,
        doEffects: doEffects,
        GMAction: GMAction,
        GMActionMessage: GMActionMessage,
        migrateItems: migrateItems,
        migrateActors: migrateActors,
        migrateAll: migrateAll,
        migrateAllAts: migrateAllAts,
        teleportToToken: teleportToToken
    };
});
/* ------------------------------------ */
/* When ready							*/
/* ------------------------------------ */
Hooks.once('ready', function () {
    initSheetTab();
    GMAction.readyActions();
    dynamiceffectsReadyActions();
    ItemEffectSelector.readyActions();
    //	let updates = activateEffectsForTargets(["JI7YiurBtBFYhxSB"], [{modSpecKey: "data.attributes.hp.value", mode: "+", value: 10, duration: {value: 1, units: "minutes"}}])
    /*
        Hooks.once("pseudoclockSet", () => {
            console.log("Updating actor effects...... ")
            let actor = game.actors.entities.find(a=>a.name==="Luthar");
            //@ts-ignore
            let item = actor.items.find(i=>i.name==="Javelin");
            console.log("Actor ", actor.id, actor, " item ", item.data);
            requestGMAction(GMAction.actions.activateItemEffectsForActor, {actorId: actor.id, itemData: item.data});
            // let updates = activateItemEffectsForActor(actor, item.data)
            game.Gametime.doIn({seconds: 20}, requestGMAction, GMAction.actions.removeAllItemActiveEffectsActorId, {actorId: actor.id, itemData: item.data})
    
            let tokens = canvas.tokens.placeables.filter(t=>t.name==="Orc 1").map(t=>t.id);
            console.log("token list is ", tokens)
    
            requestGMAction(GMAction.actions.activateItemEffectsForTargets, {targetList: tokens, itemData: item.data});
            tokens.forEach(tid => {
                console.log("token id is ", tid);
                game.Gametime.doIn({seconds: 20}, requestGMAction, GMAction.actions.removeAllItemActiveEffectsTokenId, {tokenId: duplicate(tid), itemData: item.data} )
            })
            
    
        // Do anything once the module is ready
    
        });
        */
});
// Add any additional hooks if necessary
